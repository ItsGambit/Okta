# OPA Secrets Wizard — Full Source Code

Consolidated for code review. Every real source file in the project, each
labeled with its path in the repo and a short note on what it does /
why it's included. Generated/vendored content is deliberately excluded —
see the note at the end of this section.

**Project:** CLI + local web dashboard for bulk-managing Okta Privileged
Access (OPA) secret folders, resource groups, projects, groups, and
security policies. Python stdlib backend (`create_secret_folders.py` is
both the CLI and the engine imported by the dashboard server), React 19 +
TypeScript + Vite + Tailwind v4 + Radix UI frontend.

## Table of Contents

**Backend**
1. `create_secret_folders.py` — CLI + shared engine (API clients, folder-tree logic, access-model resolution)
2. `launch.py` — cross-platform launcher (prereq checks, build, stale-server cleanup)
3. `server/serve.py` — local dashboard HTTP server (stdlib `http.server`, thin JSON API over the engine)
4. `requirements.txt` — Python dependencies

**Frontend config**
5. `frontend/package.json`
6. `frontend/vite.config.ts`
7. `frontend/tsconfig.json`, `tsconfig.app.json`, `tsconfig.node.json`
8. `frontend/.oxlintrc.json`
9. `frontend/index.html`

**Frontend source (`frontend/src/`)**
10. `types/index.ts` — every shared TS type
11. `api/client.ts`, `api/hooks.ts` — HTTP layer + TanStack Query hooks
12. `utils/*.ts` — tree, validate, policy, export, exportSections, folderAccess, format
13. `hooks/*.ts` — useToast, useAccessBootstrapJob, useLoadExistingFolders, useCreateGroup
14. `components/*.tsx` — every UI component
15. `main.tsx`, `App.tsx`, `index.css`

**Launchers**
16. `Start OPA Secrets Wizard.bat`
17. `start-wizard.sh`

---

**Excluded from this file** (not source code, or not appropriate to share):
- `environments.json` — real tenant identifiers (base_domain/team_name/key_id) for this machine's saved environments. Secrets themselves live only in the OS keychain, never in this file, but it's still local config, not code.
- `folders_template.csv` — a data/example file, not code.
- `server/serve_final.log` — a runtime log.
- `LICENSE`, `README.md` — docs, not source (the ask was specifically for source code).
- `.gitignore`, `.gitattributes` — repo meta, not code.
- `frontend/package-lock.json` — auto-generated, not hand-written/reviewable.
- `.env.example` — this sandbox's permission settings deny reading any `.env*` path outright (a safety guard, not a project issue), so it couldn't be included verbatim. Its shape is fully documented in `create_secret_folders.py`'s header comment anyway: `OPA_BASE_DOMAIN`, `OPA_TEAM_NAME`, `OPA_KEY_ID`, `OPA_KEY_SECRET`.
- `node_modules/`, `frontend/dist/`, `.git/`, `__pycache__/` — vendored/build/VCS-internal, not hand-written source.

---
## 1. `create_secret_folders.py`

The CLI entry point AND the shared engine imported directly by the dashboard
server (`server/serve.py` does `import create_secret_folders as engine`) —
zero logic duplication between the two. Contains: the two-step OPA auth
client, the encrypted multi-environment credential store (metadata in
`environments.json`, secrets in the OS keychain via `keyring`), the
recursive folder-tree walk (OPA's plain list endpoint is top-level only),
the whole-tenant "Access Explorer" model builder (resolves security-policy
selectors down to specific resources/projects), Okta System Log "last
accessed" lookups, and the CLI's own dry-run/execute pipeline. This is the
file with the most live-verified, non-obvious API behavior documented
inline (see its own header comment) — read that first.

```python
#!/usr/bin/env python3
# =============================================================================
# OPA Secret Folder Bulk Creator
# =============================================================================
# Description : Reads a CSV of vault folder paths (root/sub/sub-sub, any
#               depth) and creates the missing folders in Okta Privileged
#               Access under a given Resource Group + Project, using the
#               Secret Folders REST API.
#
# Model       : Resource Group -> Project -> Folder (Folder -> Folder for
#               nesting, via "parent_folder_id" on create). All endpoints and
#               field names below were LIVE-VERIFIED against a real OPA tenant
#               (not just inferred from docs) -- see the two confirmed facts
#               that matter most before you use this script:
#
#               1. Folder names must be unique PER PROJECT, not just per
#                  parent folder. Creating a folder whose name matches any
#                  other folder already in the same project -- even one
#                  nested elsewhere in the tree -- fails with:
#                    409 "secrets or folders that are in the same folder
#                         may not have the same name"
#                  Design your CSV so no two folders (at any depth) in the
#                  same project share a name. The script warns about this
#                  up front (see detect_name_collisions) but does not block.
#
#               2. The plain "list folders" endpoint only returns TOP-LEVEL
#                  folders, despite reading like it should return everything
#                  (its real name is ListTopLevelSecretFoldersForProject).
#                  Confirmed live 2026-08-14: a folder with 5 real
#                  sub-folders showed only itself in that list. Neither list
#                  nor get-single ever includes a parent_id field either way
#                  -- but there IS a per-folder children endpoint
#                  (.../secret_folders/{id}/items) that this script wasn't
#                  using before. fetch_all_folders() walks it recursively to
#                  see the whole tree; existing-folder detection
#                  (resolve_existing_folders) still matches by NAME ONLY,
#                  project-wide, which is safe given fact #1 (names are
#                  unique per project anyway) but means the script cannot
#                  verify a matched folder sits where the CSV intends; it
#                  can only confirm a folder with that name exists somewhere
#                  in the project.
#
#               3. Folder names may only contain letters, digits, hyphens,
#                  underscores, and periods -- NO SPACES or other characters.
#                  This is validated locally before any API call is made
#                  (see NAME_PATTERN / validate_names).
#
# Usage       : python create_secret_folders.py --csv folders.csv \
#                   --resource-group-id <rg_id> --project-id <proj_id>
#               (dry-run by default; add --execute to actually create)
#
# Auth        : Two-step service-user token exchange. Credentials are
#               resolved in this order: (1) OS environment variables
#               (OPA_BASE_DOMAIN / OPA_TEAM_NAME / OPA_KEY_ID /
#               OPA_KEY_SECRET), (2) a local .env file (legacy, plaintext,
#               opt-in -- only used if you create one yourself), (3) the
#               dashboard's encrypted environment store (environments.json
#               metadata + OS keychain secrets via `keyring`) -- whichever
#               environment is active in the dashboard. No secrets are ever
#               written to disk in plaintext by this script.
#
# Version     : 5.10.0
# =============================================================================

import argparse
import csv
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone

SCRIPT_VERSION = "5.10.0"
NAME_PATTERN = re.compile(r"^[A-Za-z0-9._-]+$")

# ---------------------------------------------------------------------------
# Live-verified API constants
# ---------------------------------------------------------------------------
TOKEN_PATH = "/v1/teams/{team}/service_token"
RESOURCE_GROUPS_PATH = "/v1/teams/{team}/resource_groups"
PROJECTS_PATH = "/v1/teams/{team}/resource_groups/{resource_group_id}/projects"
GROUPS_PATH = "/v1/teams/{team}/groups"
FOLDERS_COLLECTION_PATH = (
    "/v1/teams/{team}/resource_groups/{resource_group_id}/projects/{project_id}/secret_folders"
)
FOLDER_ITEM_PATH = FOLDERS_COLLECTION_PATH + "/{folder_id}"
FOLDER_ITEMS_PATH = FOLDER_ITEM_PATH + "/items"
SECURITY_POLICY_PATH = "/v1/teams/{team}/security_policy"
SECURITY_POLICY_ITEM_PATH = SECURITY_POLICY_PATH + "/{security_policy_id}"
WORKLOAD_ROLES_PATH = "/v1/teams/{team}/workload-roles"
USERS_PATH = "/v1/teams/{team}/users"
USER_GROUPS_PATH = USERS_PATH + "/{user_name}/groups"
PROJECT_SERVERS_PATH = PROJECTS_PATH + "/{project_id}/servers"
PROJECT_SAAS_APP_ACCOUNTS_PATH = PROJECTS_PATH + "/{project_id}/saas_app_accounts"
PROJECT_OKTA_UD_ACCOUNTS_PATH = PROJECTS_PATH + "/{project_id}/okta_universal_directory_accounts"

FIELD_TYPE = "type"
TYPE_FOLDER = "folder"

# Confirmed live (2026-08-14) against a real tenant: creating a resource
# group requires at least one group in delegated_resource_admin_groups
# ("at least one user group should be associated with the resource group");
# creating a project needs only a name (no group field on Project itself).
# OPA's own POST /groups (local RBAC groups) is intentionally NOT used here
# -- groups must come from Okta (core API) and be pushed into the OPA app
# via Okta's Group Push Mapping API, per this tool's design.
OPA_APP_CATALOG_NAME = "okta_privileged_access_sso"

SYSTEM_LOG_PATH = "/api/v1/logs"

def _target_ids(event):
    """Default id-extraction: every id in the event's target[] array. Right
    for eventTypes where the resource being accessed is a first-class
    target, e.g. pam.secret.reveal (target[] includes the secret's own
    id)."""
    return {t.get("id") for t in (event.get("target") or [])}


def _gateway_creds_server_ids(event):
    """id-extraction for pam.gateway_creds.issue: confirmed live 2026-08-14
    that this eventType's target[] NEVER includes the server (only
    Client/Gateway/Team) -- the server being connected to instead lives in
    debugContext.debugData.nextHopServerIds, a comma-separated string (the
    plural name suggests multi-hop is possible, even though every real
    sample seen so far had exactly one id)."""
    debug_data = (event.get("debugContext") or {}).get("debugData") or {}
    raw = debug_data.get("nextHopServerIds") or ""
    return {part.strip() for part in raw.split(",") if part.strip()}


# Each entry: eventType(s) to query for, and how to pull the matched
# resource id(s) back out of a returned event (defaults to target[] ids,
# since that's right for most PAM events -- only override extract_ids when
# an eventType puts the resource id somewhere else instead, as confirmed
# for individual_server_account below).
#
# Confirmed live 2026-08-14 against a real tenant's actual System Log data
# (not guessed from docs): "secret" resources have a working, ID-matchable
# access event -- pam.secret.reveal's target[] includes the secret's own
# id. "secret_folder" resources do NOT: browsing/listing a folder isn't
# logged as a distinct event, and secret-reveal events under a folder
# reference the SECRET's id in target[], never the folder's, so there's no
# way to attribute a reveal back to "this folder was accessed" (folder
# grants are instead expanded to their child secrets -- see
# _folder_descendant_secrets).
#
# Confirmed live 2026-08-14 against a SECOND, busier tenant with individual
# server/SaaS-app/Okta-account grants actually configured:
# - individual_server_account: pam.server.ssh_login's target[] DOES match
#   the server's own id directly, but its actor.id is the OS-level SSH
#   username (e.g. "rootadmin", or a per-user-provisioned name like
#   "a1jane.doe@example.com") -- NEVER the Okta identity id that
#   find_last_access_for_user filters by, so an actor-based query against
#   that eventType would silently match nothing for a real human user,
#   shared or individual account alike. pam.gateway_creds.issue is the
#   real fix: its actor.id IS a genuine Okta identity (same "00u..." id
#   confirmed used by pam.secret.reveal), and the server being connected to
#   is recoverable via nextHopServerIds (see _gateway_creds_server_ids) --
#   66 of 123 real events in the discovery sample matched one of 4 known
#   server grants this way.
# - individual_managed_saas_app_account, individual_unmanaged_saas_app_account,
#   and individual_okta_account: an initial 90-day System Log scan (both
#   unfiltered and filtered) found zero matches against the resolved
#   selector's own id -- but that id is the Okta-side identifier
#   (privileged_resource_id / okta_user_id, e.g. an AppUser id starting
#   "opr..."), and confirmed via a full-export CSV (65,972 rows, no
#   pagination/rate-limit gaps) that object type is NEVER logged as a
#   System Log target at all, for ANY account in the org -- not a
#   these-specific-4-accounts-were-unlucky situation, but a structural gap
#   in what Okta logs. The account's OWN OPA-internal id (a separate uuid,
#   fetched from list_project_saas_app_accounts/list_project_okta_ud_accounts
#   and stored as access_tracking_id -- see the indexing code below) DOES
#   show up as a "Service Account" target, on pam.service_account.password.reveal
#   (44 matches in the CSV, actor always genuine Okta "User") and
#   pam.resource.checkout (30 matches, same). pam.resource.checkin.start
#   duplicates checkout's counts exactly (same sessions, redundant) and
#   checkin.end's actor is almost always a SystemPrincipal/Server, not the
#   requesting human, so neither is included. individual_unmanaged_saas_app_account
#   shares the exact same indexing code path as individual_managed_saas_app_account
#   (both come from the same list_project_saas_app_accounts call, just a
#   different Okta OIN lifecycle-management category) -- included on that
#   basis even though this tenant only had "managed" ones configured to
#   test directly.
RESOURCE_ACCESS_EVENT_TYPES = {
    "secret": {"event_types": ["pam.secret.reveal"], "extract_ids": _target_ids},
    "individual_server_account": {"event_types": ["pam.gateway_creds.issue"], "extract_ids": _gateway_creds_server_ids},
    "individual_managed_saas_app_account": {
        "event_types": ["pam.service_account.password.reveal", "pam.resource.checkout"], "extract_ids": _target_ids,
    },
    "individual_unmanaged_saas_app_account": {
        "event_types": ["pam.service_account.password.reveal", "pam.resource.checkout"], "extract_ids": _target_ids,
    },
    "individual_okta_account": {
        "event_types": ["pam.service_account.password.reveal", "pam.resource.checkout"], "extract_ids": _target_ids,
    },
}

FIELD_NAME = "name"
FIELD_DESCRIPTION = "description"
# Confirmed live 2026-08-14 against the SecretFolderCreateRequest schema:
# the wire field is "parent_folder_id", NOT "parent_id" -- OPA silently
# ignores unknown body fields, so create_folder(..., parent_id=X) was
# never actually nesting anything; every folder the script created came
# out top-level regardless of the intended parent. Fixed here.
FIELD_PARENT_ID = "parent_folder_id"
FIELD_ID = "id"
LIST_ENVELOPE_KEY = "list"

# ---------------------------------------------------------------------------
# General config
# ---------------------------------------------------------------------------
ENV_BASE_DOMAIN = "OPA_BASE_DOMAIN"
ENV_TEAM_NAME = "OPA_TEAM_NAME"
ENV_KEY_ID = "OPA_KEY_ID"
ENV_KEY_SECRET = "OPA_KEY_SECRET"


def _load_dotenv():
    """If a .env file sits next to this script, load KEY=VALUE lines from it
    into os.environ (real environment variables always take priority --
    this only fills in values that aren't already set). Lets the CLI and
    the dashboard server both pick up credentials without the user having
    to fuss with OS-level environment variable settings. No external
    dependency -- this is intentionally a minimal parser, not python-dotenv."""
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if not os.path.isfile(env_path):
        return
    with open(env_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            os.environ.setdefault(key, value)


_load_dotenv()

# ---------------------------------------------------------------------------
# Encrypted multi-environment credential store
# ---------------------------------------------------------------------------
# Non-secret metadata (base_domain, team_name, key_id, okta_url) lives in
# environments.json next to this script. Secrets (key_secret,
# okta_api_token) are NEVER written there -- they go to the OS keychain via
# the `keyring` package (Windows Credential Locker / macOS Keychain / Linux
# Secret Service), keyed per environment name. This is the dashboard's
# storage for named environments (dev/uat/prod); the CLI also reads from it
# as a fallback (see main()) so "whichever environment is active in the
# dashboard" is automatically usable from the command line too, without
# ever touching a plaintext file.
try:
    import keyring
    KEYRING_AVAILABLE = True
except ImportError:
    KEYRING_AVAILABLE = False

KEYRING_SERVICE_PREFIX = "opa-secrets-wizard"
ENVIRONMENT_METADATA_FIELDS = ("base_domain", "team_name", "key_id", "okta_url")
ENVIRONMENT_SECRET_FIELDS = ("key_secret", "okta_api_token")


def _environments_file_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "environments.json")


def load_environments():
    path = _environments_file_path()
    if not os.path.isfile(path):
        return {"active": None, "environments": {}}
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    data.setdefault("active", None)
    data.setdefault("environments", {})
    return data


def save_environments(data):
    with open(_environments_file_path(), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _keyring_service(env_name):
    return f"{KEYRING_SERVICE_PREFIX}:{env_name}"


def _require_keyring():
    if not KEYRING_AVAILABLE:
        raise RuntimeError(
            "The 'keyring' package is required for encrypted credential storage. "
            "Install it with: pip install keyring"
        )


def keyring_set(env_name, field, value):
    _require_keyring()
    keyring.set_password(_keyring_service(env_name), field, value)


def keyring_get(env_name, field):
    if not KEYRING_AVAILABLE:
        return None
    try:
        return keyring.get_password(_keyring_service(env_name), field)
    except Exception:
        return None


def keyring_delete(env_name, field):
    if not KEYRING_AVAILABLE:
        return
    try:
        keyring.delete_password(_keyring_service(env_name), field)
    except Exception:
        pass


def upsert_environment(name, fields):
    """Saves non-secret metadata to environments.json and secret fields to
    the OS keychain. Blank secret fields on an update leave the previously
    stored secret untouched (so editing metadata doesn't force re-entering
    credentials). Raises ValueError if required fields end up missing."""
    if not name or not name.strip():
        raise ValueError("Environment name is required (e.g. dev, uat, prod).")
    name = name.strip()

    data = load_environments()
    meta = dict(data["environments"].get(name, {}))
    for field in ENVIRONMENT_SECRET_FIELDS:
        meta.pop(field, None)  # migrate away any pre-encryption plaintext secret left in metadata
    for field in ENVIRONMENT_METADATA_FIELDS:
        if field in fields:
            meta[field] = (fields.get(field) or "").strip()

    for field in ENVIRONMENT_SECRET_FIELDS:
        value = (fields.get(field) or "").strip()
        if value:
            keyring_set(name, field, value)
        # blank + already exists -> leave the previously stored secret alone

    missing = [f for f in ("base_domain", "team_name", "key_id") if not meta.get(f)]
    if missing:
        raise ValueError(f"Missing required field(s): {', '.join(missing)}")
    if not keyring_get(name, "key_secret"):
        raise ValueError("Missing required field: key_secret")

    data["environments"][name] = meta
    save_environments(data)
    return name


def delete_environment(name):
    """Removes an environment's metadata and both keychain secrets. Returns
    True if it was the active environment (caller should clear any live
    client). Raises KeyError if the name doesn't exist."""
    data = load_environments()
    if name not in data["environments"]:
        raise KeyError(f"No saved environment named '{name}'")
    del data["environments"][name]
    was_active = data.get("active") == name
    if was_active:
        data["active"] = None
    save_environments(data)
    for field in ENVIRONMENT_SECRET_FIELDS:
        keyring_delete(name, field)
    return was_active


def get_environment_credentials(name):
    """Returns the full merged credential dict (metadata + secrets from the
    keychain) for a saved environment. Raises KeyError if it doesn't exist."""
    data = load_environments()
    meta = data["environments"].get(name)
    if meta is None:
        raise KeyError(f"No saved environment named '{name}'")
    creds = dict(meta)
    for field in ENVIRONMENT_SECRET_FIELDS:
        creds[field] = keyring_get(name, field) or ""
    creds["name"] = name
    return creds


def get_active_environment_credentials():
    """Returns credentials for the currently-active saved environment, or
    None if none is set/active."""
    data = load_environments()
    name = data.get("active")
    if not name or name not in data.get("environments", {}):
        return None
    try:
        return get_environment_credentials(name)
    except KeyError:
        return None

REQUEST_TIMEOUT_SECS = 30
MAX_RETRIES = 3
RETRY_BACKOFF_SECS = 2
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}

# Okta/OPA APIs return standard rate-limit headers on every response
# (confirmed live 2026-08-14): x-ratelimit-limit, x-ratelimit-remaining,
# x-ratelimit-reset (unix seconds when the window resets). We track the
# latest known state per host and proactively wait out the window once
# few requests are left, rather than waiting to get hit with a 429.
RATE_LIMIT_MIN_REMAINING = 1
RATE_LIMIT_WAIT_BUFFER_SECS = 1
_rate_limit_lock = threading.Lock()
_rate_limit_state = {}  # host -> {"remaining": int, "reset": int}

COLOR = {
    "INFO": "\033[0m",
    "WARN": "\033[0;33m",
    "ERROR": "\033[0;31m",
    "SUCCESS": "\033[0;32m",
    "RESET": "\033[0m",
}


def log(level, message):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    color = COLOR.get(level, COLOR["INFO"])
    stream = sys.stderr if level in ("WARN", "ERROR") else sys.stdout
    print(f"{color}[{ts}] [{level}] {message}{COLOR['RESET']}", file=stream)


def die(message):
    log("ERROR", message)
    sys.exit(1)


# ---------------------------------------------------------------------------
# HTTP client
# ---------------------------------------------------------------------------
class OpaApiError(Exception):
    def __init__(self, status, url, body):
        self.status = status
        self.url = url
        self.body = body
        super().__init__(f"HTTP {status} calling {url}: {body}")


class OktaApiError(Exception):
    def __init__(self, status, url, body):
        self.status = status
        self.url = url
        self.body = body
        super().__init__(f"HTTP {status} calling {url}: {body}")


def _rate_limit_host(url):
    return urllib.parse.urlparse(url).netloc


def _record_rate_limit(url, headers):
    """Stash the latest x-ratelimit-* values for this host so the next
    request (possibly for a different endpoint on the same host) knows
    how much headroom is left before it needs to wait."""
    remaining = headers.get("x-ratelimit-remaining")
    reset = headers.get("x-ratelimit-reset")
    if remaining is None or reset is None:
        return
    try:
        remaining = int(remaining)
        reset = int(reset)
    except ValueError:
        return
    with _rate_limit_lock:
        _rate_limit_state[_rate_limit_host(url)] = {"remaining": remaining, "reset": reset}


def _wait_if_rate_limited(url):
    """Proactively sleep until the rate-limit window resets if the last
    response we saw for this host reported few requests left -- this is
    what keeps the recursive folder-tree walk (one API call per folder)
    from ever tripping a 429 in the first place."""
    with _rate_limit_lock:
        state = _rate_limit_state.get(_rate_limit_host(url))
    if not state or state["remaining"] > RATE_LIMIT_MIN_REMAINING:
        return
    wait_secs = state["reset"] - time.time() + RATE_LIMIT_WAIT_BUFFER_SECS
    if wait_secs > 0:
        log("WARN", f"Rate limit nearly exhausted for {_rate_limit_host(url)} "
                     f"({state['remaining']} request(s) left) -- waiting {wait_secs:.0f}s for the window to reset...")
        time.sleep(wait_secs)


def _retry_after_secs(headers):
    """On an actual 429, prefer an authoritative wait time over blind
    backoff: Retry-After (seconds) if present, else derive from
    x-ratelimit-reset (unix timestamp). Falls back to the fixed backoff
    only if neither header is present."""
    retry_after = headers.get("Retry-After")
    if retry_after is not None:
        try:
            return float(retry_after) + RATE_LIMIT_WAIT_BUFFER_SECS
        except ValueError:
            pass
    reset = headers.get("x-ratelimit-reset")
    if reset is not None:
        try:
            return max(0.0, int(reset) - time.time()) + RATE_LIMIT_WAIT_BUFFER_SECS
        except ValueError:
            pass
    return RETRY_BACKOFF_SECS * MAX_RETRIES


_LINK_HEADER_ENTRY_RE = re.compile(r'<([^>]+)>\s*;\s*rel="?([\w-]+)"?')


def _parse_next_link(headers):
    """Extract the rel="next" URL from the response's Link header(s), or
    None if there isn't one.

    Takes the response headers object (not a pre-extracted string):
    confirmed live against this org's System Log API that a server can send
    Link as multiple separate header lines (one per rel) rather than one
    RFC 8288 comma-joined value -- headers.get("Link") only returns the
    first line, silently dropping "next" whenever it wasn't first. Using
    get_all("Link") (falling back to get() for header objects that don't
    have it) and joining every line found is a strict superset of the old
    single-value behavior, so it's safe even against servers that do send
    one joined value."""
    lines = headers.get_all("Link") if hasattr(headers, "get_all") else [headers.get("Link")]
    combined = ", ".join(line for line in (lines or []) if line)
    if not combined:
        return None
    for url, rel in _LINK_HEADER_ENTRY_RE.findall(combined):
        if rel == "next":
            return url
    return None


def http_json_request(method, url, headers=None, body=None, error_cls=OpaApiError, return_headers=False):
    """Shared retrying HTTP-JSON helper used by both OpaClient and
    OktaClient, so the retry/backoff logic lives in exactly one place.
    Tracks x-ratelimit-* response headers per host and proactively waits
    out the window when few requests remain, so callers doing many
    sequential requests (e.g. the recursive folder-tree walk) shouldn't
    ever see a 429 in normal operation.

    With return_headers=True, returns (parsed_body, response_headers)
    instead of just parsed_body -- used for Link-header pagination."""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    headers = dict(headers or {})
    headers.setdefault("Accept", "application/json")
    if data is not None:
        headers["Content-Type"] = "application/json"

    for attempt in range(1, MAX_RETRIES + 1):
        _wait_if_rate_limited(url)
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT_SECS) as resp:
                _record_rate_limit(url, resp.headers)
                resp_headers = resp.headers
                raw = resp.read()
                parsed = json.loads(raw.decode("utf-8")) if raw else None
                return (parsed, resp_headers) if return_headers else parsed
        except urllib.error.HTTPError as e:
            _record_rate_limit(url, e.headers)
            raw_body = e.read().decode("utf-8", errors="replace")
            if e.code == 429 and attempt < MAX_RETRIES:
                wait_secs = _retry_after_secs(e.headers)
                log("WARN", f"{method} {url} -> HTTP 429 (rate limited); "
                            f"waiting {wait_secs:.0f}s before retry ({attempt}/{MAX_RETRIES})...")
                time.sleep(wait_secs)
                continue
            if e.code in RETRYABLE_STATUS_CODES and attempt < MAX_RETRIES:
                log("WARN", f"{method} {url} -> HTTP {e.code}, retrying ({attempt}/{MAX_RETRIES})...")
                time.sleep(RETRY_BACKOFF_SECS * attempt)
                continue
            raise error_cls(e.code, url, raw_body) from None
        except urllib.error.URLError as e:
            if attempt < MAX_RETRIES:
                log("WARN", f"{method} {url} -> network error ({e}), retrying ({attempt}/{MAX_RETRIES})...")
                time.sleep(RETRY_BACKOFF_SECS * attempt)
                continue
            raise


class OpaClient:
    def __init__(self, base_domain, team_name, key_id, key_secret):
        self.base_url = f"https://{base_domain}"
        self.team_name = team_name
        self.key_id = key_id
        self.key_secret = key_secret
        self.bearer_token = None
        self._fetch_token()

    def _fetch_token(self):
        path = TOKEN_PATH.format(team=self.team_name)
        body = {"key_id": self.key_id, "key_secret": self.key_secret}
        resp = self._raw_request("POST", path, body=body, authed=False)
        token = (resp or {}).get("bearer_token")
        if not token:
            raise OpaApiError("n/a", path, f"No 'bearer_token' in token response: {resp!r}")
        self.bearer_token = token

    def request(self, method, path, body=None, return_headers=False, _retried_auth=False):
        try:
            return self._raw_request(method, path, body=body, authed=True, return_headers=return_headers)
        except OpaApiError as e:
            if e.status == 401 and not _retried_auth:
                log("WARN", "Bearer token rejected (401); refreshing and retrying once...")
                self._fetch_token()
                return self.request(method, path, body=body, return_headers=return_headers, _retried_auth=True)
            raise

    def _raw_request(self, method, path, body=None, authed=True, return_headers=False):
        url = path if path.startswith("http://") or path.startswith("https://") else self.base_url + path
        headers = {"Authorization": f"Bearer {self.bearer_token}"} if authed else {}
        return http_json_request(method, url, headers=headers, body=body, error_cls=OpaApiError,
                                  return_headers=return_headers)

    def _list(self, path):
        """Fetches every page of a "list" envelope response, following the
        Link: rel="next" response header until exhausted -- no endpoint in
        this codebase ever wants only page 1, so pagination lives here
        once rather than being opted into per call site."""
        items = []
        next_path = path
        while next_path:
            resp, headers = self.request("GET", next_path, return_headers=True)
            if isinstance(resp, dict) and isinstance(resp.get(LIST_ENVELOPE_KEY), list):
                items.extend(resp[LIST_ENVELOPE_KEY])
            else:
                log("WARN", f"Unexpected list response shape, treating as empty: {resp!r}")
            next_path = _parse_next_link(headers)
        return items

    def list_resource_groups(self):
        path = RESOURCE_GROUPS_PATH.format(team=self.team_name)
        return self._list(path)

    def create_resource_group(self, name, description="", delegated_resource_admin_group_ids=None):
        """Confirmed live: OPA requires at least one group in
        delegated_resource_admin_groups to create a resource group."""
        path = RESOURCE_GROUPS_PATH.format(team=self.team_name)
        body = {FIELD_NAME: name}
        if description:
            body[FIELD_DESCRIPTION] = description
        if delegated_resource_admin_group_ids:
            body["delegated_resource_admin_groups"] = [
                {"id": gid} for gid in delegated_resource_admin_group_ids
            ]
        return self.request("POST", path, body=body)

    def list_projects(self, resource_group_id):
        path = PROJECTS_PATH.format(team=self.team_name, resource_group_id=resource_group_id)
        return self._list(path)

    def create_project(self, resource_group_id, name):
        path = PROJECTS_PATH.format(team=self.team_name, resource_group_id=resource_group_id)
        return self.request("POST", path, body={FIELD_NAME: name})

    def list_groups(self, contains=None):
        path = GROUPS_PATH.format(team=self.team_name)
        if contains:
            path += "?contains=" + urllib.parse.quote(contains)
        return self._list(path)

    def list_users(self):
        path = USERS_PATH.format(team=self.team_name)
        return self._list(path)

    def list_user_groups(self, user_name):
        path = USER_GROUPS_PATH.format(team=self.team_name, user_name=urllib.parse.quote(user_name, safe=""))
        return self._list(path)

    def list_security_policies(self):
        """Team-wide, not resource-group-scoped -- there's no server-side
        filter for resource group, so callers that need a subset filter
        this list themselves (see build_access_model)."""
        path = SECURITY_POLICY_PATH.format(team=self.team_name)
        return self._list(path)

    def get_security_policy(self, security_policy_id):
        path = SECURITY_POLICY_ITEM_PATH.format(team=self.team_name, security_policy_id=security_policy_id)
        return self.request("GET", path)

    def create_security_policy(self, policy_body):
        path = SECURITY_POLICY_PATH.format(team=self.team_name)
        return self.request("POST", path, body=policy_body)

    def update_security_policy(self, security_policy_id, policy_body):
        """PUT is a full replace, not a patch -- confirmed live 2026-08-14
        (returns 204, no body). Callers must GET the current policy first
        and submit the complete modified object; see
        upsert_folder_rule_in_policy for the one place that matters here."""
        path = SECURITY_POLICY_ITEM_PATH.format(team=self.team_name, security_policy_id=security_policy_id)
        return self.request("PUT", path, body=policy_body)

    def delete_security_policy(self, security_policy_id):
        path = SECURITY_POLICY_ITEM_PATH.format(team=self.team_name, security_policy_id=security_policy_id)
        return self.request("DELETE", path)

    def list_workload_roles(self, contains=None):
        path = WORKLOAD_ROLES_PATH.format(team=self.team_name)
        if contains:
            path += "?contains=" + urllib.parse.quote(contains)
        return self._list(path)

    def list_project_servers(self, resource_group_id, project_id):
        path = PROJECT_SERVERS_PATH.format(
            team=self.team_name, resource_group_id=resource_group_id, project_id=project_id
        )
        return self._list(path)

    def list_project_saas_app_accounts(self, resource_group_id, project_id):
        path = PROJECT_SAAS_APP_ACCOUNTS_PATH.format(
            team=self.team_name, resource_group_id=resource_group_id, project_id=project_id
        )
        return self._list(path)

    def list_project_okta_ud_accounts(self, resource_group_id, project_id):
        path = PROJECT_OKTA_UD_ACCOUNTS_PATH.format(
            team=self.team_name, resource_group_id=resource_group_id, project_id=project_id
        )
        return self._list(path)

    def list_folders(self, resource_group_id, project_id):
        """TOP-LEVEL (root) folders only -- despite its name, this endpoint
        (ListTopLevelSecretFoldersForProject) does not include nested
        folders. Confirmed live 2026-08-14: a folder with 5 real
        sub-folders showed only itself here; the sub-folders were entirely
        absent. Use fetch_all_folders() for the full tree -- see module
        docstring fact #2."""
        path = FOLDERS_COLLECTION_PATH.format(
            team=self.team_name, resource_group_id=resource_group_id, project_id=project_id
        )
        return self._list(path)

    def list_folder_items(self, resource_group_id, project_id, folder_id):
        """Direct children of one folder -- both sub-folders and secrets,
        distinguished by their "type" field (TYPE_FOLDER vs
        "key_value_secret"). This is the only way to discover nesting;
        there's no parent_id on any read response (see fetch_all_folders)."""
        path = FOLDER_ITEMS_PATH.format(
            team=self.team_name, resource_group_id=resource_group_id,
            project_id=project_id, folder_id=folder_id,
        )
        return self._list(path)

    def create_folder(self, resource_group_id, project_id, name, description, parent_id=None):
        path = FOLDERS_COLLECTION_PATH.format(
            team=self.team_name, resource_group_id=resource_group_id, project_id=project_id
        )
        body = {FIELD_NAME: name}
        if description:
            body[FIELD_DESCRIPTION] = description
        if parent_id:
            body[FIELD_PARENT_ID] = parent_id
        return self.request("POST", path, body=body)

    def delete_folder(self, resource_group_id, project_id, folder_id):
        """The API gives no cascade guarantee for a folder that still has
        children, and CreateSecretFolder's docs confirm nested creation is
        gated by a `folder_create` security-policy privilege separate from
        top-level creation -- there's no reason to assume delete is any
        less strict, and no safe way to find out by experiment (a wrong
        guess either orphans real data or mass-deletes it). Callers MUST
        check list_folder_items() first and refuse to delete a non-empty
        folder; see the server route."""
        path = FOLDER_ITEM_PATH.format(
            team=self.team_name, resource_group_id=resource_group_id, project_id=project_id, folder_id=folder_id
        )
        return self.request("DELETE", path)


class OktaClient:
    """Core Okta Identity Engine API (NOT OPA/PAM) -- used only to create a
    group in Okta and push it into the OPA app's Group Push mapping, per
    this tool's explicit design (groups must originate in Okta, not OPA's
    own local-group endpoint)."""

    def __init__(self, org_url, api_token):
        self.base_url = org_url.rstrip("/")
        self.api_token = api_token

    def request(self, method, path, body=None, return_headers=False):
        url = self.base_url + path
        headers = {"Authorization": f"SSWS {self.api_token}"}
        return http_json_request(method, url, headers=headers, body=body, error_cls=OktaApiError,
                                  return_headers=return_headers)

    def create_group(self, name, description=""):
        body = {"profile": {"name": name, "description": description or ""}}
        return self.request("POST", "/api/v1/groups", body=body)

    def find_apps_by_catalog_name(self, catalog_name):
        query = urllib.parse.quote(f'name eq "{catalog_name}"')
        return self.request("GET", f"/api/v1/apps?filter={query}") or []

    def find_privileged_access_app(self):
        """Confirmed live: the Okta Privileged Access app integration has a
        stable catalog name (OPA_APP_CATALOG_NAME) regardless of its
        user-visible label, and its `features` list includes GROUP_PUSH
        when that feature is enabled."""
        apps = self.find_apps_by_catalog_name(OPA_APP_CATALOG_NAME)
        if not apps:
            raise OktaApiError(
                "n/a", "find_privileged_access_app",
                f"No Okta app found with catalog name '{OPA_APP_CATALOG_NAME}'. "
                "Is Okta Privileged Access installed in this org?",
            )
        if len(apps) > 1:
            raise OktaApiError(
                "n/a", "find_privileged_access_app",
                f"Found {len(apps)} apps matching '{OPA_APP_CATALOG_NAME}'; expected exactly one.",
            )
        app = apps[0]
        if "GROUP_PUSH" not in (app.get("features") or []):
            raise OktaApiError(
                "n/a", "find_privileged_access_app",
                "The Okta Privileged Access app does not have Group Push enabled.",
            )
        return app

    def create_group_push_mapping(self, app_id, source_group_id, target_group_name):
        path = f"/api/v1/apps/{app_id}/group-push/mappings"
        body = {"sourceGroupId": source_group_id, "status": "ACTIVE", "targetGroupName": target_group_name}
        return self.request("POST", path, body=body)

    def find_user_by_login_or_email(self, identifier):
        """GET /api/v1/users/{id|login|email} -- Okta's Users API resolves
        the path segment against id, login, or email interchangeably.
        Needed because an OPA (PAM) user's own id is an OPA-internal UUID
        with no relationship to Okta's identity id, but PAM is built on
        top of Okta, so the same person's Okta identity can be found by
        their login/email -- and System Log's actor.id is that Okta
        identity id, not the PAM one."""
        return self.request("GET", f"/api/v1/users/{urllib.parse.quote(identifier, safe='')}")

    def get_system_log(self, filter_expr=None, since=None, limit=1000, sort_order="DESCENDING", max_pages=50):
        """GET /api/v1/logs, following the Link: rel="next" header until
        exhausted (or max_pages, as a runaway-query backstop -- logged, not
        silent, if actually hit). Confirmed live 2026-08-14: this org's
        retention is exactly 90 days (earliest available event was
        published 90 days before "today" when queried with an older
        `since`) -- matches Okta's documented System Log retention, not
        assumed. `filter` uses the same SCIM-ish expression syntax as other
        Okta management APIs (e.g. 'actor.id eq "..." and eventType eq
        "..."').

        Single-page (limit<=1000) was fine against a low-volume tenant, but
        a busier one (e.g. high service-account rotation traffic) can
        exceed 1000 matching events inside a 90-day window even after
        actor+eventType filtering -- silently returning only page 1 would
        make find_last_access_for_user miss real, more-recent-than-shown
        events for no visible reason. Found via live testing against a
        second, busier tenant, not anticipated up front."""
        params = {"limit": str(limit), "sortOrder": sort_order}
        if filter_expr:
            params["filter"] = filter_expr
        if since:
            params["since"] = since
        query = urllib.parse.urlencode(params)
        events = []
        next_path = f"{SYSTEM_LOG_PATH}?{query}"
        pages = 0
        while next_path and pages < max_pages:
            resp, headers = self.request("GET", next_path, return_headers=True)
            events.extend(resp or [])
            next_path = _parse_next_link(headers)
            # Link URLs from Okta are absolute (https://org...) -- request()
            # always prefixes self.base_url, so strip it back down to a path.
            if next_path and next_path.startswith(self.base_url):
                next_path = next_path[len(self.base_url):]
            pages += 1
        if next_path:
            log("WARN", f"get_system_log hit max_pages={max_pages} with more pages remaining; "
                         f"results are truncated to the first {len(events)} events.")
        return events


# ---------------------------------------------------------------------------
# Row parsing -> ordered folder tree
# ---------------------------------------------------------------------------
def parse_rows(rows, warn=True):
    """Shared core used by both the CLI (rows read from a CSV file) and the
    dashboard server (rows built interactively and submitted as JSON). Each
    row is a dict with 'path' (required, '/'-delimited) and optional
    'description'.

    Returns an ordered list of path tuples (parents before children) and a
    dict mapping path tuple -> description (only set where a row gave one
    explicitly; implied ancestor folders default to "")."""
    descriptions = {}
    seen_paths = set()

    for row_num, row in enumerate(rows, start=1):
        raw_path = (row.get("path") or "").strip()
        if not raw_path:
            if warn:
                log("WARN", f"Row {row_num}: empty path, skipping.")
            continue
        segments = tuple(seg.strip() for seg in raw_path.split("/") if seg.strip())
        if not segments:
            if warn:
                log("WARN", f"Row {row_num}: path '{raw_path}' has no usable segments, skipping.")
            continue

        description = (row.get("description") or "").strip()
        if segments in seen_paths and description and warn:
            log("WARN", f"Row {row_num}: duplicate path '{'/'.join(segments)}', keeping first description.")
        seen_paths.add(segments)
        if description and segments not in descriptions:
            descriptions[segments] = description

        # Register every ancestor too, so intermediate folders always get created.
        for depth in range(1, len(segments)):
            seen_paths.add(segments[:depth])

    ordered = sorted(seen_paths, key=lambda p: (len(p), p))
    return ordered, descriptions


def parse_csv(csv_path):
    """Reads a CSV file (columns: path, description) and delegates to
    parse_rows for the actual tree-building logic."""
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or "path" not in [c.strip() for c in reader.fieldnames]:
            die(f"CSV must have a 'path' column header. Found: {reader.fieldnames}")
        rows = list(reader)
    return parse_rows(rows)


def rows_from_tree(ordered_paths, descriptions):
    """Inverse of parse_rows: flattens the tree back into CSV-shaped rows,
    used when the dashboard saves an interactively-built tree to disk."""
    return [
        {"path": "/".join(path), "description": descriptions.get(path, "")}
        for path in ordered_paths
    ]


def validate_names(ordered_paths):
    """OPA rejects folder names containing anything but letters, digits,
    '-', '_', '.' (see module docstring fact #3). Check locally so a bad
    name fails fast with every offender listed, instead of a mid-run 400
    that aborts whatever hasn't been created yet."""
    invalid = [path for path in ordered_paths if not NAME_PATTERN.match(path[-1])]
    if invalid:
        log("ERROR", "These folder names contain characters OPA will reject (only A-Z a-z 0-9 . _ - are allowed):")
        for path in invalid:
            log("ERROR", f"  '{path[-1]}' (from path '{'/'.join(path)}')")
        die("Fix the CSV and re-run.")


def detect_name_collisions(ordered_paths):
    """OPA enforces folder-name uniqueness per PROJECT, not per parent (see
    module docstring fact #1). Warn if the CSV implies two different tree
    positions sharing the same folder name -- the second create will 409."""
    name_to_paths = {}
    for path in ordered_paths:
        name_to_paths.setdefault(path[-1], []).append(path)
    return {name: paths for name, paths in name_to_paths.items() if len(paths) > 1}


# ---------------------------------------------------------------------------
# Full folder tree (recursive -- see module docstring fact #2)
# ---------------------------------------------------------------------------
TYPE_SECRET = "key_value_secret"


def _walk_folder_tree(client, resource_group_id, project_id):
    """Shared BFS core for fetch_all_folders() and
    fetch_all_folders_and_secrets(): list_folders() alone only sees
    top-level folders, so this walks list_folder_items() breadth-first
    from each root to see the whole tree (any depth), tracking parent_id
    from the traversal itself since no read response ever includes it.
    One API call per folder discovered -- http_json_request's rate-limit
    handling keeps this safe for reasonably large trees.

    Returns (folders, secrets), each a flat list of dicts with
    {"id", "name", "description", "parent_id"}.
    """
    folders, secrets = [], []
    roots = client.list_folders(resource_group_id, project_id)
    queue = deque((folder, None) for folder in roots)
    while queue:
        folder, parent_id = queue.popleft()
        fid = folder.get(FIELD_ID)
        folders.append({
            "id": fid,
            "name": folder.get(FIELD_NAME),
            "description": folder.get(FIELD_DESCRIPTION, ""),
            "parent_id": parent_id,
        })
        if not fid:
            continue
        for child in client.list_folder_items(resource_group_id, project_id, fid):
            if child.get(FIELD_TYPE) == TYPE_FOLDER:
                queue.append((child, fid))
            elif child.get(FIELD_TYPE) == TYPE_SECRET:
                secrets.append({
                    "id": child.get(FIELD_ID),
                    "name": child.get(FIELD_NAME),
                    "description": child.get(FIELD_DESCRIPTION, ""),
                    "parent_id": fid,
                })
    return folders, secrets


def fetch_all_folders(client, resource_group_id, project_id):
    """Every folder in the project, any depth -- see _walk_folder_tree."""
    folders, _secrets = _walk_folder_tree(client, resource_group_id, project_id)
    return folders


def fetch_all_folders_and_secrets(client, resource_group_id, project_id):
    """Every folder AND secret in the project, any depth -- see
    _walk_folder_tree. Used by build_access_model to resolve
    secret_based_resource policy selectors down to a specific project."""
    return _walk_folder_tree(client, resource_group_id, project_id)


def _folder_descendant_secrets(folders, secrets):
    """{folder_id: [{"id", "name"}, ...]} mapping each folder (from one
    project's flat folder/secret lists) to every secret nested anywhere
    beneath it, at any depth -- not just its direct children.

    Needed because a secret_folder policy grant applies to the whole
    subtree, but System Log access events are only attributable to
    individual secrets (see RESOURCE_ACCESS_EVENT_TYPES) -- so "last
    accessed" for a folder-level grant has to walk down to the secrets
    actually inside it."""
    children_folders = defaultdict(list)
    direct_secrets = defaultdict(list)
    for f in folders:
        if f.get("parent_id"):
            children_folders[f["parent_id"]].append(f["id"])
    for s in secrets:
        direct_secrets[s.get("parent_id")].append({"id": s.get("id"), "name": s.get("name")})

    result = {}
    for f in folders:
        root_id = f["id"]
        stack, seen, collected = [root_id], set(), []
        while stack:
            cur = stack.pop()
            if cur in seen:
                continue
            seen.add(cur)
            collected.extend(direct_secrets.get(cur, []))
            stack.extend(children_folders.get(cur, []))
        result[root_id] = collected
    return result


# ---------------------------------------------------------------------------
# Access model (Resource Groups / Projects / Policies / Users / Groups)
# ---------------------------------------------------------------------------
# Security policies are scoped to a Resource Group, never a Project -- there
# is no "what does this project have access to" endpoint. Attribution to a
# specific project has to be derived by resolving each rule's resource
# selector:
#
#   RESOLVABLE (the selector names one specific resource; matched below
#   against an index built by listing each project's own resources):
#     secret_folder / secret          -> matched by id directly
#     individual_server(_account)     -> matched by id directly
#     individual_*_saas_app_account   -> selector id is an Okta/SaaS ID, NOT
#                                         the OPA account's own id -- matched
#                                         against that account's
#                                         privileged_resource_id field
#                                         (live-confirmed 2026-08-14: the ids
#                                         differ, the names matched, and
#                                         privileged_resource_id was the key
#                                         that actually lined up)
#     individual_okta_account         -> same indirection, via okta_user_id
#
#   NOT RESOLVABLE (the selector is a dynamic pattern match, not a specific
#   resource -- live-confirmed against this tenant, not assumed):
#     server_label                    -> matches servers by label, live
#     active_directory                -> "name CONTAINS X" / "domain IN [Y]",
#                                         never a specific account
#     database                        -> same condition shape as AD
#   These are described as plain-English text instead (describe_dynamic_selector)
#   and surface at the resource-group level, not attributed to one project.
RESOURCE_TYPE_LABELS = {
    "secret_based_resource": "Secrets",
    "server_based_resource": "Servers",
    "managed_saas_app_based_resource": "Managed SaaS app accounts",
    "unmanaged_saas_app_based_resource": "Unmanaged SaaS app accounts",
    "okta_app_based_resource": "Okta app accounts",
    "active_directory_based_resource": "Active Directory accounts",
    "database_based_resource": "Database accounts",
}

_CONDITION_WORDS = {"CONTAINS": "contains", "STARTS_WITH": "starts with", "ENDS_WITH": "ends with", "EQUALS": "equals"}


def _condition_phrase(fmt, value):
    word = _CONDITION_WORDS.get(fmt, (fmt or "?").lower())
    return f"name {word} '{value}'"


def describe_dynamic_selector(resource_type, selector_type, selector):
    """Best-effort human-readable description of a selector that can't be
    resolved to a specific project (label/pattern-based, or a shape this
    script doesn't recognize -- never raises, since live selector shapes
    have already diverged from the downloaded OpenAPI spec more than once
    on this project; an unrecognized shape should degrade to a generic
    label, not break the whole access model)."""
    try:
        if selector_type == "server_label":
            labels = ((selector.get("server_selector") or {}).get("labels")) or {}
            label_text = ", ".join(f"{k}={v}" for k, v in labels.items()) or "(no labels)"
            return f"Servers labeled {label_text}"
        if selector_type == "active_directory":
            accounts = selector.get("individual_accounts") or {}
            by_condition = accounts.get("by_condition")
            by_domain = accounts.get("by_domain")
            if by_condition:
                return f"AD accounts where {_condition_phrase(by_condition.get('account_name_format'), by_condition.get('value'))}"
            if by_domain:
                return f"AD accounts in domain(s): {', '.join(by_domain)}"

            # "Shared" AD accounts (live-confirmed 2026-08-14): a distinct
            # sub-shape from individual_accounts above -- names specific
            # accounts by SID/domain rather than a name pattern. The
            # optional "servers" field scoping which servers the shared
            # account applies to is a SIBLING of shared_accounts on the
            # selector itself, not nested inside it.
            shared = selector.get("shared_accounts") or {}
            specific = shared.get("specific_accounts")
            if specific:
                names = ", ".join(a.get("account_name", "?") for a in specific)
                scope = ((selector.get("servers") or {}).get("selectors") or [{}])[0].get("selector") or {}
                scope_labels = scope.get("labels") or {}
                scope_text = f", on servers labeled {', '.join(f'{k}={v}' for k, v in scope_labels.items())}" if scope_labels else ""
                return f"Shared AD account(s): {names}{scope_text}"
            if shared.get("by_domain"):
                return f"Shared AD accounts in domain(s): {', '.join(shared['by_domain'])}"
            if shared.get("by_matching_names"):
                return "Shared AD accounts matching configured name rules"
        if selector_type == "database":
            conns = selector.get("database_connections") or []
            conn_names = ", ".join(c.get("name", "?") for c in conns) or "(any connection)"
            accts = selector.get("database_accounts") or []
            conds = "; ".join(_condition_phrase(a.get("account_name_format"), a.get("value")) for a in accts)
            return f"Database accounts in {conn_names}" + (f" where {conds}" if conds else "")
    except Exception:
        pass
    return f"{RESOURCE_TYPE_LABELS.get(resource_type, resource_type)} ({selector_type})"


def _privilege_flags(privilege_value):
    """Extract the granted permission flags from a privilege_value object,
    e.g. {"_type":"secret","list":true,"secret_reveal":true,"secret_update":false}
    -> ["list","secret_reveal"]. Works uniformly across every privilege
    type -- most have a single boolean, "secret" has eight."""
    if not isinstance(privilege_value, dict):
        return []
    return [k for k, v in privilege_value.items() if k != "_type" and v is True]


# ---------------------------------------------------------------------------
# Folder Builder policy assignment (display + create/attach a secret_folder
# rule) -- a lighter sibling of the Access Explorer machinery above. This
# context already knows which resource group/project it's in, so it never
# needs the cross-project resolution indexes build_access_model builds;
# it only needs the raw target name/id (or a condition description for
# dynamic selectors, reusing describe_dynamic_selector for consistency).
# ---------------------------------------------------------------------------
SECRET_PRIVILEGE_FIELDS = (
    "list", "secret_create", "secret_update", "secret_delete", "secret_reveal",
    "folder_create", "folder_update", "folder_delete",
)


def build_secret_privilege(flags):
    """flags is a dict of {field: bool}, possibly partial -- any of the 8
    required SecurityPolicySecretPrivilege fields not present default to
    False (the API requires all 8 present on every write)."""
    value = {f: bool((flags or {}).get(f)) for f in SECRET_PRIVILEGE_FIELDS}
    value["_type"] = "secret"
    return value


def build_secret_folder_selector(folder_id, folder_name):
    return {
        "_type": "secret_based_resource",
        "selectors": [
            {
                "selector_type": "secret_folder",
                "selector": {"_type": "secret_folder", "secret_folder": {"id": folder_id, "name": folder_name}},
            }
        ],
    }


def build_mfa_condition(reauth_seconds, acr_values):
    return {
        "condition_type": "mfa",
        "condition_value": {
            "_type": "mfa",
            "re_auth_frequency_in_seconds": reauth_seconds,
            "acr_values": acr_values,
        },
    }


def _rule_targets_folder(rule, folder_id):
    for entry in (rule.get("resource_selector") or {}).get("selectors") or []:
        if entry.get("selector_type") == "secret_folder":
            ref = (entry.get("selector") or {}).get("secret_folder") or {}
            if ref.get("id") == folder_id:
                return True
    return False


def upsert_folder_rule_in_policy(policy, folder_id, folder_name, rule_name, privilege_flags, mfa=None):
    """Mutates and returns policy["rules"]: replaces the rule that already
    targets this exact folder (by secret_folder id), or appends a new one.
    `policy` must be the full object from get_security_policy -- PUT is a
    full replace (see OpaClient.update_security_policy), never a patch."""
    new_rule = {
        "name": rule_name,
        "resource_type": "secret_based_resource",
        "resource_selector": build_secret_folder_selector(folder_id, folder_name),
        "privileges": [{"privilege_type": "secret", "privilege_value": build_secret_privilege(privilege_flags)}],
        "conditions": [build_mfa_condition(**mfa)] if mfa else [],
    }
    rules = policy.setdefault("rules", [])
    for i, rule in enumerate(rules):
        if _rule_targets_folder(rule, folder_id):
            rules[i] = new_rule
            return policy
    rules.append(new_rule)
    return policy


def merge_principals(principals, group_refs, workload_role_refs):
    """Dedups by id, adding any of group_refs/workload_role_refs
    ({"id","name"} dicts, already resolved by the caller) not already
    present. Principals apply to the WHOLE policy, not per-rule -- adding
    a group here grants it every other rule already in the policy too."""
    principals = principals or {}
    user_groups = list(principals.get("user_groups") or [])
    seen_group_ids = {g["id"] for g in user_groups}
    for ref in group_refs or []:
        if ref["id"] not in seen_group_ids:
            user_groups.append(ref)
            seen_group_ids.add(ref["id"])

    workload_roles = list(principals.get("workload_roles") or [])
    seen_role_ids = {r["id"] for r in workload_roles}
    for ref in workload_role_refs or []:
        if ref["id"] not in seen_role_ids:
            workload_roles.append(ref)
            seen_role_ids.add(ref["id"])

    return {"user_groups": user_groups, "workload_roles": workload_roles}


def _summarize_rule_targets(rule):
    """Like build_access_model's rule resolution, but without the
    cross-project indexes -- just the raw target name/id for individual-
    resource selectors, or a condition description for dynamic ones."""
    resource_type = rule.get("resource_type")
    entries = (rule.get("resource_selector") or {}).get("selectors") or []
    targets = []
    for entry in entries:
        selector_type = entry.get("selector_type")
        selector = entry.get("selector") or {}
        ref = None
        try:
            if selector_type == "secret_folder":
                ref = selector.get("secret_folder")
            elif selector_type == "secret":
                ref = selector.get("secret")
            elif selector_type in ("individual_server", "individual_server_account"):
                ref = selector.get("server")
            elif selector_type in (
                "individual_managed_saas_app_account", "individual_unmanaged_saas_app_account", "individual_okta_account",
            ):
                ref = selector.get("service_account")
        except Exception:
            ref = None
        if ref:
            targets.append({"kind": "resolved", "id": ref.get("id"), "name": ref.get("name")})
        else:
            targets.append({"kind": "condition", "description": describe_dynamic_selector(resource_type, selector_type, selector)})
    return targets or [{"kind": "condition", "description": RESOURCE_TYPE_LABELS.get(resource_type, resource_type)}]


def summarize_security_policy(policy):
    """Presentation-friendly shape for Folder Builder's policy picker/
    badge -- same field names as build_access_model's policies for
    familiarity, but "targets" (not "resolutions") since there's no
    project attribution here, and no dedicated TS type shares this with
    Access Explorer's (kept deliberately separate, see module notes)."""
    return {
        "id": policy.get("id"),
        "name": policy.get("name"),
        "description": policy.get("description", ""),
        "active": policy.get("active", False),
        "type": policy.get("type"),
        "resource_group": policy.get("resource_group"),
        "principals": policy.get("principals", {"user_groups": [], "workload_roles": []}),
        "rules": [
            {
                "name": rule.get("name"),
                "resource_type": rule.get("resource_type"),
                "resource_type_label": RESOURCE_TYPE_LABELS.get(rule.get("resource_type"), rule.get("resource_type")),
                "privileges": [
                    {"privilege_type": p.get("privilege_type"), "flags": _privilege_flags(p.get("privilege_value"))}
                    for p in rule.get("privileges", [])
                ],
                "conditions": rule.get("conditions", []),
                "targets": _summarize_rule_targets(rule),
            }
            for rule in policy.get("rules", [])
        ],
    }


def _resolve_selector_entry(resource_type, selector_type, selector, indexes):
    """Resolve one selector entry to a concrete project-attributed resource
    (kind="resolved") when its type names an individual resource, else
    describe it as a condition (kind="condition"). Never raises -- a
    resolvable type whose fields aren't where expected falls back to a
    condition description rather than breaking the whole model."""
    try:
        ref, hit = None, None
        if selector_type == "secret_folder":
            ref = selector.get("secret_folder") or {}
            hit = indexes["secret_folders"].get(ref.get("id"))
        elif selector_type == "secret":
            ref = selector.get("secret") or {}
            hit = indexes["secrets"].get(ref.get("id"))
        elif selector_type in ("individual_server", "individual_server_account"):
            ref = selector.get("server") or {}
            hit = indexes["servers"].get(ref.get("id"))
        elif selector_type in ("individual_managed_saas_app_account", "individual_unmanaged_saas_app_account"):
            ref = selector.get("service_account") or {}
            hit = indexes["saas_accounts"].get(ref.get("id"))
        elif selector_type == "individual_okta_account":
            ref = selector.get("service_account") or {}
            hit = indexes["okta_accounts"].get(ref.get("id"))

        if ref is not None:
            # resource_kind is the raw selector_type (e.g. "secret" vs.
            # "secret_folder") -- resource_type alone can't distinguish these
            # (both fall under "secret_based_resource"), but System Log
            # access-tracking only works for one of them (see
            # find_last_access_for_user), so the frontend needs this.
            resolved = {"kind": "resolved", "id": ref.get("id"), "name": ref.get("name"),
                        "resource_kind": selector_type,
                        "project_id": None, "project_name": None, "resource_group_id": None}
            if hit:
                resolved.update(hit)
            if selector_type == "secret_folder":
                # A folder grant covers every secret in its subtree, but
                # System Log events only attribute to individual secrets --
                # attach the folder's descendant secrets so the frontend can
                # look up (and roll up) per-secret access under this grant.
                resolved["child_secrets"] = indexes.get("secret_folder_children", {}).get(ref.get("id"), [])
            return resolved
    except Exception:
        pass
    return {"kind": "condition", "description": describe_dynamic_selector(resource_type, selector_type, selector)}


def _resolve_rule(rule, indexes):
    resource_type = rule.get("resource_type")
    entries = (rule.get("resource_selector") or {}).get("selectors") or []
    resolutions = [
        _resolve_selector_entry(resource_type, entry.get("selector_type"), entry.get("selector") or {}, indexes)
        for entry in entries
    ]
    return resolutions or [{"kind": "condition",
                             "description": RESOURCE_TYPE_LABELS.get(resource_type, resource_type)}]


def _extract_request_id(event):
    """Per Okta support's own guidance (how-to-find-x-okta-request-id):
    the x-okta-request-id header value is looked up in System Log as
    debugContext.debugData.requestId OR transaction.id -- both are treated
    as equally valid "the request ID" for a given event, and either can
    be used to search for the other. Falls back to the event's own uuid
    (always present) only if neither of those is."""
    debug_data = (event.get("debugContext") or {}).get("debugData") or {}
    return debug_data.get("requestId") or (event.get("transaction") or {}).get("id") or event.get("uuid")


def resolve_okta_actor_id(okta_client, email):
    """Translates an OPA (PAM) user into the Okta identity id that System
    Log's actor.id actually refers to -- see OktaClient.find_user_by_login_or_email
    for why the PAM user's own id can't be used directly. Raises
    OktaApiError if no matching Okta user exists (e.g. a PAM-only service
    account with no Okta identity behind it)."""
    if not email:
        raise OktaApiError("n/a", "resolve_okta_actor_id", "This PAM user has no email on file to resolve against Okta.")
    return okta_client.find_user_by_login_or_email(email)["id"]


def find_last_access_for_user(okta_client, actor_user_id, resources, limit_per_resource=5, since_days=90):
    """For each {resource_kind, resource_id} in `resources`, finds up to
    `limit_per_resource` most-recent System Log events (within the last
    `since_days`) where `actor_user_id` accessed that specific resource.

    One System Log call per distinct resource_kind present in `resources`
    (not one per resource) -- events are fetched filtered by actor+eventType
    only, then bucketed client-side by matching each event's target[] ids
    against the requested resource ids. This is the only viable approach:
    Okta's log `filter` doesn't support querying by target.id, so per-
    resource server-side filtering isn't possible; filtering by actor+
    eventType first keeps each query's result set small instead of scanning
    the org's entire log.

    Returns a dict keyed by resource_id:
        {"resource_kind": ..., "supported": bool, "events": [
            {"published": ..., "request_id": ..., "outcome": ...}, ...
        ]}
    `supported=False` (empty events, no query made) for any resource_kind
    not in RESOURCE_ACCESS_EVENT_TYPES -- see that constant's comment for
    why those are intentionally left unmapped rather than guessed."""
    results = {}
    by_kind = {}
    for r in resources:
        by_kind.setdefault(r["resource_kind"], []).append(r["resource_id"])

    since = (datetime.now(timezone.utc) - timedelta(days=since_days)).strftime("%Y-%m-%dT%H:%M:%S.000Z")

    for resource_kind, resource_ids in by_kind.items():
        mapping = RESOURCE_ACCESS_EVENT_TYPES.get(resource_kind)
        if not mapping:
            for rid in resource_ids:
                results[rid] = {"resource_kind": resource_kind, "supported": False, "events": []}
            continue

        type_filter = " or ".join(f'eventType eq "{t}"' for t in mapping["event_types"])
        filter_expr = f'actor.id eq "{actor_user_id}" and ({type_filter})'
        events = okta_client.get_system_log(filter_expr=filter_expr, since=since, limit=1000)

        wanted = set(resource_ids)
        buckets = {rid: [] for rid in resource_ids}
        for event in events:  # already DESCENDING (most-recent-first) by default
            hit_ids = mapping["extract_ids"](event) & wanted
            for rid in hit_ids:
                if len(buckets[rid]) < limit_per_resource:
                    buckets[rid].append({
                        "published": event.get("published"),
                        "request_id": _extract_request_id(event),
                        "outcome": (event.get("outcome") or {}).get("result"),
                    })

        for rid in resource_ids:
            results[rid] = {"resource_kind": resource_kind, "supported": True, "events": buckets[rid]}

    return results


# Canonical step sequence for progress reporting -- shared with the
# server's job runner so the frontend can render "step N of len(STEPS)"
# and know which label goes with which key. Steps with per-item detail
# (index_resources, user_groups) also emit "progress" events between
# their "start" and "done".
ACCESS_MODEL_STEPS = [
    ("resource_groups", "Fetching resource groups"),
    ("groups", "Fetching groups"),
    ("users", "Fetching users"),
    ("projects", "Fetching projects"),
    ("index_resources", "Indexing project resources (folders, secrets, servers, accounts)"),
    ("user_groups", "Fetching user group memberships"),
    ("policies", "Fetching security policies"),
    ("resolve", "Resolving policy access"),
]


def _report(on_progress, key, status, detail=None):
    """Progress reporting must never break the actual job -- a broken
    callback (e.g. a dropped websocket) shouldn't take down the fetch
    it's just supposed to be narrating."""
    if on_progress is None:
        return
    try:
        on_progress(key, status, detail)
    except Exception:
        pass


def build_access_model(client, on_progress=None):
    """Fetches resource groups, projects, groups, users (+ their groups),
    and every security policy, then resolves each policy rule's selectors
    down to a specific project where possible (see module notes above).

    Returns one JSON-able dict: {resource_groups, projects, groups, users,
    policies}. This is the whole payload behind the dashboard's Access
    Explorer -- one bootstrap call, meant to be cached client-side and
    refreshed on demand. Not cheap: roughly one API call per folder/secret
    discovered, per project's server/SaaS/Okta-UD list, and per user's
    group membership -- http_json_request's rate-limit handling is what
    keeps this safe on a tenant with real data volume.

    on_progress(key, status, detail), if given, is called as
    ("start"|"progress"|"done") events matching ACCESS_MODEL_STEPS above --
    see the server's job runner for how this drives a pollable status
    endpoint. If this function raises, the last step reported "start"
    without a matching "done" is the one that failed.
    """
    _report(on_progress, "resource_groups", "start")
    resource_groups = client.list_resource_groups()
    _report(on_progress, "resource_groups", "done", f"{len(resource_groups)} resource group(s)")

    _report(on_progress, "groups", "start")
    groups = client.list_groups()
    _report(on_progress, "groups", "done", f"{len(groups)} group(s)")

    _report(on_progress, "users", "start")
    users = client.list_users()
    _report(on_progress, "users", "done", f"{len(users)} user(s)")

    _report(on_progress, "projects", "start")
    projects_by_rg = [(rg, client.list_projects(rg["id"])) for rg in resource_groups]
    total_projects = sum(len(ps) for _rg, ps in projects_by_rg)
    _report(on_progress, "projects", "done",
            f"{total_projects} project(s) across {len(resource_groups)} resource group(s)")

    indexes = {"secret_folders": {}, "secrets": {}, "servers": {}, "saas_accounts": {}, "okta_accounts": {},
               "secret_folder_children": {}}
    projects = []

    _report(on_progress, "index_resources", "start")
    indexed_count = 0
    for rg, rg_projects in projects_by_rg:
        for project in rg_projects:
            project = dict(project)
            project["resource_group_id"] = rg["id"]
            projects.append(project)
            proj_ref = {"project_id": project["id"], "project_name": project["name"], "resource_group_id": rg["id"]}

            folders, secrets = fetch_all_folders_and_secrets(client, rg["id"], project["id"])
            for f in folders:
                if f.get("id"):
                    indexes["secret_folders"][f["id"]] = proj_ref
            for s in secrets:
                if s.get("id"):
                    indexes["secrets"][s["id"]] = proj_ref
            indexes["secret_folder_children"].update(_folder_descendant_secrets(folders, secrets))

            for server in client.list_project_servers(rg["id"], project["id"]):
                if server.get("id"):
                    indexes["servers"][server["id"]] = proj_ref

            for acct in client.list_project_saas_app_accounts(rg["id"], project["id"]):
                key = acct.get("privileged_resource_id")
                if key:
                    # access_tracking_id: confirmed live 2026-08-15 -- the
                    # account's own OPA-internal id (distinct from
                    # privileged_resource_id, the Okta-side AppUser id used
                    # to key this index and shown as the resolved "id") is
                    # what actually shows up as a "Service Account" target
                    # in pam.service_account.password.reveal /
                    # pam.resource.checkout events. The Okta-side id is
                    # never logged as a System Log target at all -- see
                    # RESOURCE_ACCESS_EVENT_TYPES.
                    indexes["saas_accounts"][key] = {**proj_ref, "access_tracking_id": acct.get("id")}

            for acct in client.list_project_okta_ud_accounts(rg["id"], project["id"]):
                key = acct.get("okta_user_id")
                if key:
                    indexes["okta_accounts"][key] = {**proj_ref, "access_tracking_id": acct.get("id")}

            indexed_count += 1
            _report(on_progress, "index_resources", "progress",
                    f"{indexed_count}/{total_projects} projects ({project['name']})")
    _report(on_progress, "index_resources", "done", f"{indexed_count} project(s) indexed")

    _report(on_progress, "user_groups", "start")
    users_with_groups = []
    for i, user in enumerate(users):
        user = dict(user)
        try:
            user["groups"] = client.list_user_groups(user.get("name"))
        except OpaApiError as exc:
            user["groups"] = []
            log("WARN", f"Could not fetch groups for user '{user.get('name')}': {exc}")
        users_with_groups.append(user)
        _report(on_progress, "user_groups", "progress", f"{i + 1}/{len(users)} users ({user.get('name')})")
    _report(on_progress, "user_groups", "done", f"{len(users)} user(s)")

    _report(on_progress, "policies", "start")
    all_policies = client.list_security_policies()
    _report(on_progress, "policies", "done", f"{len(all_policies)} polic(ies)")

    _report(on_progress, "resolve", "start")
    policies_out = []
    for policy in all_policies:
        rules_out = []
        for rule in policy.get("rules", []):
            rules_out.append({
                "name": rule.get("name"),
                "resource_type": rule.get("resource_type"),
                "resource_type_label": RESOURCE_TYPE_LABELS.get(rule.get("resource_type"), rule.get("resource_type")),
                "privileges": [
                    {"privilege_type": p.get("privilege_type"), "flags": _privilege_flags(p.get("privilege_value"))}
                    for p in rule.get("privileges", [])
                ],
                "conditions": rule.get("conditions", []),
                "resolutions": _resolve_rule(rule, indexes),
            })
        policies_out.append({
            "id": policy.get("id"),
            "name": policy.get("name"),
            "description": policy.get("description", ""),
            "active": policy.get("active", False),
            "type": policy.get("type"),
            "resource_group": policy.get("resource_group"),
            "principals": policy.get("principals", {}),
            "rules": rules_out,
        })
    _report(on_progress, "resolve", "done", f"{len(policies_out)} polic(ies) resolved")

    return {
        "resource_groups": resource_groups,
        "projects": projects,
        "groups": groups,
        "users": users_with_groups,
        "policies": policies_out,
    }


# ---------------------------------------------------------------------------
# Existing-folder resolution
# ---------------------------------------------------------------------------
def resolve_existing_folders(client, resource_group_id, project_id, ordered_paths):
    """Returns dict: path tuple -> folder_id, for folders that already exist.

    Matches by NAME ONLY (project-wide), which is safe as long as fact #1
    (per-project name uniqueness) holds in your tenant -- but the folders
    themselves now come from fetch_all_folders() so nested existing folders
    are found too, not just top-level ones (see module docstring fact #2).
    """
    folders = fetch_all_folders(client, resource_group_id, project_id)
    log("INFO", f"Scanned {len(folders)} existing folder(s) in project (recursive, all depths).")
    name_to_id = {}
    for f in folders:
        name = f.get(FIELD_NAME)
        fid = f.get(FIELD_ID)
        if not name or not fid:
            continue
        if name in name_to_id:
            log("WARN", f"Tenant already has more than one folder named '{name}' in this project; using the first one found.")
            continue
        name_to_id[name] = fid

    existing = {}
    for path in ordered_paths:
        fid = name_to_id.get(path[-1])
        if fid:
            existing[path] = fid
    return existing


# ---------------------------------------------------------------------------
# Plan / execute
# ---------------------------------------------------------------------------
def print_plan(ordered_paths, existing, collisions):
    if collisions:
        log("WARN", "Name collisions detected -- OPA requires folder names to be unique per project:")
        for name, paths in collisions.items():
            where = ", ".join("/".join(p) for p in paths)
            log("WARN", f"  '{name}' is used at multiple positions: {where}")
        log("WARN", "Only the first folder created with each name will succeed; the rest will error with 409.")

    log("INFO", "Planned folder tree:")
    for path in ordered_paths:
        indent = "  " * (len(path) - 1)
        marker = "[exists]     " if path in existing else "[will create]"
        log("INFO", f"  {indent}{marker} {path[-1]}  (full path: {'/'.join(path)})")


def execute_plan(client, resource_group_id, project_id, ordered_paths, descriptions, existing):
    results = []
    folder_ids = dict(existing)

    for path in ordered_paths:
        if path in folder_ids:
            results.append((path, folder_ids[path], "skipped_exists", ""))
            continue

        parent_id = folder_ids.get(path[:-1]) if len(path) > 1 else None
        if len(path) > 1 and not parent_id:
            msg = f"Parent path '{'/'.join(path[:-1])}' was not created successfully; skipping."
            log("ERROR", msg)
            results.append((path, "", "error", msg))
            continue

        name = path[-1]
        description = descriptions.get(path, "")
        try:
            created = client.create_folder(
                resource_group_id, project_id, name, description, parent_id=parent_id
            )
            new_id = (created or {}).get(FIELD_ID, "")
            if not new_id:
                raise OpaApiError("n/a", "create_folder", f"No '{FIELD_ID}' in response: {created!r}")
            folder_ids[path] = new_id
            results.append((path, new_id, "created", ""))
            log("SUCCESS", f"Created '{'/'.join(path)}' (id={new_id})")
        except OpaApiError as e:
            log("ERROR", f"Failed to create '{'/'.join(path)}': {e}")
            results.append((path, "", "error", str(e)))

    return results


def write_results_csv(output_path, results):
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["path", "folder_id", "status", "error_message"])
        for path, folder_id, status, error_message in results:
            writer.writerow(["/".join(path), folder_id, status, error_message])
    log("INFO", f"Results written to {output_path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Bulk-create Okta Privileged Access secret folders from a CSV of paths."
    )
    parser.add_argument("--csv", required=True, help="Path to input CSV (columns: path, description)")
    parser.add_argument("--resource-group-id", required=True)
    parser.add_argument("--project-id", required=True)
    parser.add_argument(
        "--execute",
        action="store_true",
        help="Actually create folders. Without this flag, only a dry-run preview is shown.",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Output results CSV path (default: folders_result_<timestamp>.csv)",
    )
    args = parser.parse_args()

    if not os.path.isfile(args.csv):
        die(f"CSV file not found: {args.csv}")

    base_domain = os.environ.get(ENV_BASE_DOMAIN, "").strip()
    team_name = os.environ.get(ENV_TEAM_NAME, "").strip()
    key_id = os.environ.get(ENV_KEY_ID, "").strip()
    key_secret = os.environ.get(ENV_KEY_SECRET, "").strip()

    if not all([base_domain, team_name, key_id, key_secret]):
        active = get_active_environment_credentials()
        if active:
            base_domain = base_domain or active.get("base_domain", "")
            team_name = team_name or active.get("team_name", "")
            key_id = key_id or active.get("key_id", "")
            key_secret = key_secret or active.get("key_secret", "")
            log("INFO", f"Using credentials from the dashboard's active environment ('{active.get('name')}').")

    missing = [name for name, val in [
        (ENV_BASE_DOMAIN, base_domain), (ENV_TEAM_NAME, team_name),
        (ENV_KEY_ID, key_id), (ENV_KEY_SECRET, key_secret),
    ] if not val]
    if missing:
        die(
            f"Missing required credential(s): {', '.join(missing)}. "
            "Set them as environment variables, in a local .env file, or activate an "
            "environment in the dashboard."
        )

    log("INFO", f"OPA Secret Folder Bulk Creator v{SCRIPT_VERSION}")
    log("INFO", f"Mode: {'EXECUTE' if args.execute else 'DRY-RUN (no changes will be made)'}")

    ordered_paths, descriptions = parse_csv(args.csv)
    if not ordered_paths:
        die("No usable paths found in CSV.")

    validate_names(ordered_paths)
    collisions = detect_name_collisions(ordered_paths)

    try:
        client = OpaClient(base_domain, team_name, key_id, key_secret)
        existing = resolve_existing_folders(client, args.resource_group_id, args.project_id, ordered_paths)
    except OpaApiError as e:
        die(f"Failed during setup/lookup: {e}")

    print_plan(ordered_paths, existing, collisions)

    if not args.execute:
        log("INFO", "Dry-run complete. Re-run with --execute to actually create the folders above.")
        return

    results = execute_plan(client, args.resource_group_id, args.project_id, ordered_paths, descriptions, existing)

    output_path = args.output or f"folders_result_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.csv"
    write_results_csv(output_path, results)

    created = sum(1 for r in results if r[2] == "created")
    skipped = sum(1 for r in results if r[2] == "skipped_exists")
    errors = sum(1 for r in results if r[2] == "error")
    log("SUCCESS", f"Done. Created={created} Skipped(existing)={skipped} Errors={errors}")
    if errors:
        sys.exit(1)


if __name__ == "__main__":
    main()
```

---
## 2. `launch.py`

Cross-platform launcher — the ONLY place build/launch logic lives. The
Windows `.bat` and Mac/Linux `.sh` wrappers (sections 16–17 below) are
one-line calls into this; nothing OS-specific is duplicated between them.
Checks Python/Node versions, offers guided installs via whatever native
package manager exists, builds the React frontend, detects and stops a
leftover server instance still bound to the target port, then starts
`server/serve.py`.

```python
#!/usr/bin/env python3
"""
Cross-platform launcher for the OPA Secrets Wizard dashboard.

Checks prerequisites (Python, Node.js/npm, the `keyring` Python package,
frontend deps), offering to install/upgrade anything missing or too old via
whatever package manager the OS already has -- then builds the React
frontend (best-effort -- falls back to whatever is already in
frontend/dist/ if the build fails) and starts server/serve.py. This is the
ONLY place build/launch logic lives; the Windows .bat and Mac/Linux .sh
wrappers just call `python(3) launch.py` so there's nothing OS-specific to
keep in sync between them.

Before starting the server, also checks whether a server from a previous
run is still bound to the target port (serve.py's StrictBindHTTPServer
refuses to share a port, so a leftover process -- e.g. one left running by
a prior session, or a window that got closed without Ctrl+C -- makes every
fresh launch fail to bind before the dashboard ever opens). If one is
found, it's stopped automatically and a fresh server is started in its
place.

Usage:
    python launch.py [--port 8766] [--no-browser] [--skip-checks]
    (args other than --skip-checks are passed straight through to server/serve.py)
"""

import argparse
import platform
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
FRONTEND_DIR = PROJECT_ROOT / "frontend"
SERVER_SCRIPT = PROJECT_ROOT / "server" / "serve.py"
REQUIREMENTS_FILE = PROJECT_ROOT / "requirements.txt"

MIN_PYTHON = (3, 9)  # driven by the `keyring` dependency's own requires-python


# =============================================================================
# Prerequisite checking / guided install
# =============================================================================

def _confirm(prompt):
    try:
        answer = input(f"{prompt} [y/N]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    return answer in ("y", "yes")


def _detect_package_manager():
    """First OS-native package manager found on PATH, or None. Only ever
    used after the user has explicitly confirmed an install -- this
    function just narrows down which command to show them."""
    system = platform.system()
    if system == "Windows":
        return "winget" if shutil.which("winget") else None
    if system == "Darwin":
        return "brew" if shutil.which("brew") else None
    for mgr in ("apt-get", "dnf", "pacman", "zypper"):
        if shutil.which(mgr):
            return mgr
    return None


# component -> manager -> list of argv lists to run in order
_INSTALL_COMMANDS = {
    "node": {
        "winget": [["winget", "install", "-e", "--id", "OpenJS.NodeJS.LTS"]],
        "brew": [["brew", "install", "node"]],
        "apt-get": [["sudo", "apt-get", "update"], ["sudo", "apt-get", "install", "-y", "nodejs", "npm"]],
        "dnf": [["sudo", "dnf", "install", "-y", "nodejs", "npm"]],
        "pacman": [["sudo", "pacman", "-Sy", "--noconfirm", "nodejs", "npm"]],
        "zypper": [["sudo", "zypper", "install", "-y", "nodejs", "npm"]],
    },
    "python": {
        "winget": [["winget", "install", "-e", "--id", "Python.Python.3.13"]],
        "brew": [["brew", "install", "python@3.13"]],
        "apt-get": [["sudo", "apt-get", "update"], ["sudo", "apt-get", "install", "-y", "python3"]],
        "dnf": [["sudo", "dnf", "install", "-y", "python3"]],
        "pacman": [["sudo", "pacman", "-Sy", "--noconfirm", "python"]],
        "zypper": [["sudo", "zypper", "install", "-y", "python3"]],
    },
}

_MANUAL_INSTALL_URL = {
    "node": "https://nodejs.org/ (LTS release)",
    "python": "https://www.python.org/downloads/",
}


def _offer_install_or_upgrade(display_name, component_key):
    """Shows the exact command(s) for the OS's own package manager and asks
    before running anything. Returns True only if something was actually
    run (not whether it worked -- callers re-check the real version/
    presence afterward, since that's the only reliable signal)."""
    manager = _detect_package_manager()
    if not manager:
        print(f"Could not find a supported package manager (winget/brew/apt-get/dnf/pacman/zypper) "
              f"to install {display_name} automatically.")
        print(f"Please install it manually from {_MANUAL_INSTALL_URL[component_key]}, then run this launcher again.")
        return False

    commands = _INSTALL_COMMANDS[component_key].get(manager)
    if not commands:
        print(f"No known install command for {display_name} via {manager}.")
        print(f"Please install it manually from {_MANUAL_INSTALL_URL[component_key]}, then run this launcher again.")
        return False

    print(f"\nDetected package manager: {manager}. This would run:")
    for cmd in commands:
        print("  " + " ".join(cmd))
    if not _confirm(f"Install/upgrade {display_name} now?"):
        print(f"Skipping {display_name} -- the dashboard likely won't start correctly without it.")
        return False

    for cmd in commands:
        result = subprocess.run(cmd)
        if result.returncode != 0:
            print(f"'{' '.join(cmd)}' exited with code {result.returncode} -- installation may not have completed.")
            return True  # still "ran something" -- caller re-checks the real state
    return True


def _get_node_version():
    """Returns (path, (major, minor, patch)) or (path, None) if found but
    unparseable, or (None, None) if not found at all."""
    node = shutil.which("node")
    if not node:
        return None, None
    try:
        out = subprocess.run([node, "--version"], capture_output=True, text=True, timeout=10)
        parts = tuple(int(p) for p in out.stdout.strip().lstrip("v").split(".")[:3])
        return node, parts
    except Exception:
        return node, None


def _node_version_ok(version):
    # Mirrors Vite 8's own engines field: "^20.19.0 || >=22.12.0"
    if version is None:
        return False
    return (20, 19, 0) <= version < (21, 0, 0) or version >= (22, 12, 0)


def check_python():
    """We can't upgrade the interpreter we're already running under, so a
    successful install here still requires the user to relaunch -- there's
    no safe, portable way to re-exec into a not-yet-verified interpreter
    path across Windows/Mac/Linux package managers."""
    if sys.version_info[:2] >= MIN_PYTHON:
        return True
    current = ".".join(map(str, sys.version_info[:3]))
    needed = ".".join(map(str, MIN_PYTHON))
    print(f"Python {current} is below the minimum this dashboard needs ({needed}+, for the "
          f"`keyring` encrypted-credential-storage dependency).")
    if _offer_install_or_upgrade("Python", "python"):
        print(f"Python {needed}+ may now be installed, but this session is still running under the "
              f"old interpreter (Python {current}). Close this window/terminal and run the launcher "
              f"again so it picks up the new version.")
    return False


def check_node():
    node_path, version = _get_node_version()
    if node_path and _node_version_ok(version):
        return True

    shown = f"v{'.'.join(map(str, version))}" if version else ("found, but version could not be determined" if node_path else "not found")
    print(f"Node.js is {'outdated' if node_path else 'missing'} ({shown}; this frontend's build tool needs "
          f"^20.19.0 or >=22.12.0).")
    if not _offer_install_or_upgrade("Node.js", "node"):
        return False

    node_path, version = _get_node_version()
    if node_path and _node_version_ok(version):
        print("Node.js is now available.")
        return True
    print("Node.js was installed/updated, but isn't visible in this session yet (common right after a "
          "fresh install, especially on Windows, since PATH changes need a new terminal to take effect).")
    print("Close this window/terminal and run the launcher again.")
    return False


def ensure_python_deps():
    """Non-fatal: missing `keyring` only breaks credential *saving*, not
    booting the dashboard (it's imported lazily, not at module load), so
    this warns and continues rather than blocking the whole launch."""
    try:
        import keyring  # noqa: F401
        return
    except ImportError:
        pass
    print("\nThe Python package 'keyring' (encrypted credential storage) isn't installed yet.")
    if _confirm(f"Install it now via 'pip install -r {REQUIREMENTS_FILE.name}'?"):
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(REQUIREMENTS_FILE)])
    else:
        print("Skipping -- saving new environments/credentials will fail until this is installed.")


def check_prerequisites():
    print("Checking prerequisites...", flush=True)
    if not check_python():
        return False
    if not check_node():
        return False
    ensure_python_deps()
    return True


# =============================================================================
# Build / launch
# =============================================================================

def build_frontend():
    npm = shutil.which("npm")
    if not npm:
        print("npm not found on PATH -- skipping frontend build, using whatever is in frontend/dist/ already.")
        return
    print("Building React frontend...", flush=True)
    result = subprocess.run([npm, "run", "build"], cwd=str(FRONTEND_DIR))
    if result.returncode != 0:
        node_modules = FRONTEND_DIR / "node_modules"
        deps_missing = not node_modules.is_dir() or not any(node_modules.iterdir())
        if deps_missing and _confirm("Frontend dependencies aren't installed yet. Install them now with 'npm install'?"):
            subprocess.run([npm, "install"], cwd=str(FRONTEND_DIR))
            result = subprocess.run([npm, "run", "build"], cwd=str(FRONTEND_DIR))
        if result.returncode != 0:
            print("WARNING: Frontend build failed. Will use existing build if available.")


def _port_is_bound(port, host="127.0.0.1"):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.5)
        return sock.connect_ex((host, port)) == 0


def _find_stale_server_pids():
    """PIDs of processes whose command line looks like this project's own
    serve.py (matched on the script's own filename, not just any process
    using the target port, so we don't touch some unrelated process that
    happens to be on the same port). Best-effort: returns [] on any
    failure rather than raising, since this is a convenience, not the
    launcher's critical path."""
    try:
        if sys.platform == "win32":
            ps_cmd = (
                "Get-CimInstance Win32_Process | "
                f"Where-Object {{ $_.CommandLine -like '*{SERVER_SCRIPT.name}*' }} | "
                "Select-Object -ExpandProperty ProcessId"
            )
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_cmd],
                capture_output=True, text=True, timeout=10,
            )
        else:
            result = subprocess.run(
                ["pgrep", "-f", SERVER_SCRIPT.name],
                capture_output=True, text=True, timeout=10,
            )
    except Exception:
        return []
    return [int(tok) for tok in result.stdout.split() if tok.strip().isdigit()]


def _kill_pid(pid):
    try:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True, timeout=10)
        else:
            import os
            import signal
            os.kill(pid, signal.SIGKILL)
        return True
    except Exception as exc:
        print(f"  could not stop PID {pid}: {exc}")
        return False


def stop_stale_server(port):
    """If something is already listening on `port`, try to identify it as
    a leftover instance of this project's own server and stop it so the
    fresh launch below can bind cleanly. If the port is occupied by
    something we can't identify as ours, leave it alone and let serve.py's
    own bind-failure message explain the conflict -- safer than killing an
    unrelated process by port number alone."""
    if not _port_is_bound(port):
        return

    pids = _find_stale_server_pids()
    if not pids:
        print(f"Port {port} is already in use by something we couldn't identify as this dashboard's "
              f"own server -- leaving it alone. If the launch below fails to bind, close whatever's "
              f"using port {port} manually, or run with --port <other_port>.")
        return

    print(f"Found {len(pids)} leftover dashboard server process(es) still bound to port {port} "
          f"-- stopping before starting a fresh one...")
    for pid in pids:
        if _kill_pid(pid):
            print(f"  stopped PID {pid}")

    for _ in range(10):
        if not _port_is_bound(port):
            return
        time.sleep(0.3)
    print(f"WARNING: port {port} still appears bound after stopping the old process(es) -- "
          f"the fresh launch below may fail; a manual retry usually clears it.")


def start_server(extra_args):
    print("Starting OPA Secrets Wizard server...", flush=True)
    print("No credentials required to start -- if none are configured yet, the dashboard")
    print("itself will prompt you to set up an environment on first load.")
    print("Press Ctrl+C to stop.\n")
    try:
        subprocess.run([sys.executable, str(SERVER_SCRIPT)] + extra_args)
    except KeyboardInterrupt:
        pass


def main():
    # Line-buffer stdout even when redirected to a file/pipe (not a TTY) --
    # otherwise our own print()s can sit in Python's block buffer while
    # subprocess calls (npm, winget, etc.) write directly to the same fd,
    # making the interleaved output appear out of chronological order.
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(line_buffering=True)

    # --skip-checks is consumed here; everything else is still forwarded to
    # serve.py unchanged (including --port, which we also peek at below to
    # know which port to pre-check).
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--port", type=int, default=8766)
    parser.add_argument("--skip-checks", action="store_true")
    known, _ = parser.parse_known_args(sys.argv[1:])
    forwarded_args = [a for a in sys.argv[1:] if a != "--skip-checks"]

    if not known.skip_checks and not check_prerequisites():
        sys.exit(1)

    build_frontend()
    stop_stale_server(known.port)
    start_server(forwarded_args)


if __name__ == "__main__":
    main()
```

---
## 3. `server/serve.py`

Local-only dashboard server (stdlib `http.server`, no web framework). Imports
`create_secret_folders.py` as `engine` so every route is a thin JSON wrapper
around the shared engine — no business logic lives here that isn't also
usable from the CLI. Binds to `127.0.0.1` only.

```python
"""
Local-only server for the OPA Secrets Wizard dashboard.

Serves frontend/dist/ as static files and exposes a small JSON API the React
app uses to: manage named environments (dev/uat/prod, credentials stored
encrypted -- see create_secret_folders.py's environments.json + keyring
helpers, all imported as `engine` so nothing is duplicated), list/create
resource groups, projects, and groups (the group-creation path goes through
Okta's core API + Group Push, never OPA's own local-group endpoint, by
design), load/save the folder-tree CSV, and run preview (dry-run) / execute
against the real OPA Secrets API.

Usage:
    python serve.py [--port 8766] [--no-browser]

Binds to 127.0.0.1 only - never reachable from other machines on the network.
No credentials are required to START this server -- if no environment is
configured yet (first boot), the dashboard UI itself prompts for one and
saves it via POST /api/environments.
"""

import argparse
import csv as _csv
import json
import os
import sys
import threading
import time
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
import create_secret_folders as engine  # noqa: E402

FRONTEND_DIST = PROJECT_ROOT / "frontend" / "dist"

GROUP_PUSH_PROPAGATION_RETRIES = 5
GROUP_PUSH_PROPAGATION_DELAY_SECS = 1.5

client = None  # OpaClient, set once an environment is successfully activated
okta_client = None  # OktaClient, set only if the active environment has okta_url + okta_api_token
active_env_name = None

# Access Explorer bootstrap job -- build_access_model takes real time
# (~30s+ on a tenant with data), so it runs in a background thread and the
# frontend polls _access_job's status instead of holding one HTTP request
# open the whole time. Single global job: a second start while one is
# already running is a no-op (see /api/access/bootstrap/start), so there's
# never more than one in flight.
_access_job_lock = threading.Lock()
_access_job = {"status": "idle", "steps": [], "error": None}
_access_job_result = None  # kept out of _access_job so status polls stay small


def _access_job_progress(key, status, detail=None):
    with _access_job_lock:
        _access_job["steps"].append({"key": key, "status": status, "detail": detail})


def _run_access_job(job_client):
    global _access_job, _access_job_result
    try:
        result = engine.build_access_model(job_client, on_progress=_access_job_progress)
        with _access_job_lock:
            _access_job["status"] = "done"
            _access_job_result = result
    except Exception as exc:
        with _access_job_lock:
            _access_job["status"] = "error"
            _access_job["error"] = str(exc)


class StrictBindHTTPServer(ThreadingHTTPServer):
    # http.server.HTTPServer sets allow_reuse_address=True, which on Windows
    # (unlike POSIX) lets a second process silently bind to a port that
    # another process is already actively listening on, instead of raising
    # "address already in use". Disabling it makes the OSError-on-bind check
    # in main() actually fire consistently on Windows, Mac, and Linux.
    allow_reuse_address = False


def _public_entry(name, meta):
    """Non-secret fields only -- key_secret/okta_api_token never leave the
    keychain, let alone reach the browser."""
    return {
        "name": name,
        "base_domain": meta.get("base_domain", ""),
        "team_name": meta.get("team_name", ""),
        "key_id": meta.get("key_id", ""),
        "okta_url": meta.get("okta_url", ""),
        "has_okta_token": bool(engine.keyring_get(name, "okta_api_token")),
    }


def activate_environment(name):
    """Loads `name` from the encrypted store, authenticates to OPA, and (if
    Okta credentials are present) to Okta too. On success sets the
    module-level client/okta_client/active_env_name. Raises KeyError
    (unknown name) or engine.OpaApiError (OPA auth failed)."""
    global client, okta_client, active_env_name

    creds = engine.get_environment_credentials(name)  # raises KeyError if unknown
    new_client = engine.OpaClient(creds["base_domain"], creds["team_name"], creds["key_id"], creds["key_secret"])

    new_okta_client = None
    if creds.get("okta_url") and creds.get("okta_api_token"):
        new_okta_client = engine.OktaClient(creds["okta_url"], creds["okta_api_token"])

    client = new_client
    okta_client = new_okta_client
    active_env_name = name

    data = engine.load_environments()
    data["active"] = name
    engine.save_environments(data)
    print(f"Activated environment '{name}' ({creds['base_domain']}).")


# ---------------------------------------------------------------------------
# Folder-tree helpers
# ---------------------------------------------------------------------------
def _row_dict(path, folder_id, status, error_message):
    return {"path": "/".join(path), "folder_id": folder_id, "status": status, "error_message": error_message}


def _plan_dict(ordered_paths, existing, collisions):
    return {
        "tree": [
            {"path": "/".join(p), "depth": len(p) - 1, "exists": p in existing, "folder_id": existing.get(p, "")}
            for p in ordered_paths
        ],
        "collisions": {name: ["/".join(p) for p in paths] for name, paths in collisions.items()},
    }


def _safe_csv_path(filename):
    """Only allow a bare filename ending in .csv, resolved inside PROJECT_ROOT
    (no path traversal via '..' or absolute paths)."""
    name = os.path.basename((filename or "").strip())
    if not name or not name.lower().endswith(".csv"):
        raise ValueError("filename must be a bare name ending in .csv")
    return PROJECT_ROOT / name


def _run_pipeline(rows, resource_group_id, project_id):
    """Shared by /api/preview and /api/execute: parse -> validate -> collision
    check -> existing-folder lookup. Returns (ordered_paths, descriptions,
    existing, collisions, invalid_names)."""
    ordered_paths, descriptions = engine.parse_rows(rows, warn=False)
    invalid_names = [
        {"path": "/".join(p), "name": p[-1]}
        for p in ordered_paths
        if not engine.NAME_PATTERN.match(p[-1])
    ]
    collisions = engine.detect_name_collisions(ordered_paths)
    existing = engine.resolve_existing_folders(client, resource_group_id, project_id, ordered_paths)
    return ordered_paths, descriptions, existing, collisions, invalid_names


def _require_client(send_json):
    if client is None:
        send_json(409, {"error": "No active environment configured. Use the gear menu to set one up."})
        return False
    return True


def _require_okta_client(send_json):
    if okta_client is None:
        send_json(
            409,
            {"error": "This environment has no Okta URL/API token configured. Add them via the gear menu to create groups."},
        )
        return False
    return True


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(FRONTEND_DIST), **kwargs)

    def log_message(self, fmt, *args):
        pass  # keep console output to our own explicit prints

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "http://localhost:5173")
        super().end_headers()

    def _send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b""
        return json.loads(raw.decode("utf-8")) if raw else {}

    # -----------------------------------------------------------------
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)

        try:
            if path == "/api/environments":
                data = engine.load_environments()
                envs = [_public_entry(n, e) for n, e in data["environments"].items()]
                return self._send_json(200, {"environments": envs, "active": data.get("active")})

            if path == "/api/resource_groups":
                if not _require_client(self._send_json):
                    return
                return self._send_json(200, {"resource_groups": client.list_resource_groups()})

            if path.startswith("/api/resource_groups/") and path.endswith("/projects"):
                if not _require_client(self._send_json):
                    return
                rg_id = path[len("/api/resource_groups/"):-len("/projects")]
                if not rg_id:
                    return self._send_json(400, {"error": "missing resource_group_id"})
                return self._send_json(200, {"projects": client.list_projects(rg_id)})

            if path == "/api/groups":
                if not _require_client(self._send_json):
                    return
                contains = (qs.get("contains") or [None])[0]
                return self._send_json(200, {"groups": client.list_groups(contains=contains)})

            if (path.startswith("/api/resource_groups/") and path.endswith("/folders")
                    and "/projects/" in path):
                if not _require_client(self._send_json):
                    return
                inner = path[len("/api/resource_groups/"):-len("/folders")]
                rg_id, _, proj_id = inner.partition("/projects/")
                if not rg_id or not proj_id:
                    return self._send_json(400, {"error": "missing resource_group_id or project_id"})
                # The plain folders list is top-level only (see engine docstring
                # fact #2) -- walk the full tree via fetch_all_folders() and
                # rebuild each folder's "Root/Child/.../Leaf" path from its
                # parent chain, same convention the CSV `path` column already
                # uses. treeFromRows() on the frontend needs no changes for
                # this -- it already parses slash-delimited paths.
                folders = engine.fetch_all_folders(client, rg_id, proj_id)
                by_id = {f["id"]: f for f in folders if f.get("id")}

                def _full_path(folder):
                    names = []
                    current = folder
                    while current is not None:
                        names.append(current["name"])
                        parent_id = current.get("parent_id")
                        current = by_id.get(parent_id) if parent_id else None
                    return "/".join(reversed(names))

                rows = [
                    {"path": _full_path(f), "description": f.get("description", ""), "folder_id": f.get("id")}
                    for f in folders
                ]
                return self._send_json(200, {"rows": rows})

            if path.startswith("/api/resource_groups/") and path.endswith("/security_policies"):
                if not _require_client(self._send_json):
                    return
                rg_id = path[len("/api/resource_groups/"):-len("/security_policies")]
                if not rg_id:
                    return self._send_json(400, {"error": "missing resource_group_id"})
                policies = [
                    engine.summarize_security_policy(p)
                    for p in client.list_security_policies()
                    if (p.get("resource_group") or {}).get("id") == rg_id
                ]
                return self._send_json(200, {"policies": policies})

            if path == "/api/workload_roles":
                if not _require_client(self._send_json):
                    return
                contains = (qs.get("contains") or [None])[0]
                return self._send_json(200, {"workload_roles": client.list_workload_roles(contains=contains)})

            if path == "/api/access/bootstrap/status":
                with _access_job_lock:
                    return self._send_json(200, {
                        "status": _access_job["status"],
                        "steps": _access_job["steps"],
                        "error": _access_job["error"],
                    })

            if path == "/api/access/bootstrap/result":
                with _access_job_lock:
                    if _access_job["status"] != "done" or _access_job_result is None:
                        return self._send_json(409, {"error": "Job is not done yet."})
                    return self._send_json(200, _access_job_result)

            if path == "/api/csv_files":
                files = sorted(p.name for p in PROJECT_ROOT.glob("*.csv"))
                return self._send_json(200, {"files": files})

            if path == "/api/csv":
                filename = (qs.get("file") or [""])[0]
                csv_path = _safe_csv_path(filename)
                if not csv_path.is_file():
                    return self._send_json(404, {"error": f"{filename} not found"})
                with open(csv_path, newline="", encoding="utf-8-sig") as f:
                    rows = list(_csv.DictReader(f))
                return self._send_json(200, {"rows": rows})
        except ValueError as exc:
            return self._send_json(400, {"error": str(exc)})
        except (engine.OpaApiError, engine.OktaApiError) as exc:
            return self._send_json(502, {"error": str(exc)})
        except Exception as exc:
            return self._send_json(500, {"error": str(exc)})

        super().do_GET()

    # -----------------------------------------------------------------
    def do_POST(self):
        path = urlparse(self.path).path
        try:
            payload = self._read_json_body()

            if path == "/api/environments":
                name = engine.upsert_environment(payload.get("name"), payload)
                try:
                    activate_environment(name)
                except engine.OpaApiError as exc:
                    return self._send_json(502, {"error": f"Saved, but could not connect: {exc}", "saved": True})
                return self._send_json(200, {"activated": True, "active": name})

            if path.startswith("/api/environments/") and path.endswith("/activate"):
                name = path[len("/api/environments/"):-len("/activate")]
                try:
                    activate_environment(name)
                except KeyError as exc:
                    return self._send_json(404, {"error": str(exc)})
                except engine.OpaApiError as exc:
                    return self._send_json(502, {"error": str(exc)})
                return self._send_json(200, {"activated": True, "active": name})

            if path == "/api/access/bootstrap/start":
                if not _require_client(self._send_json):
                    return
                global _access_job
                with _access_job_lock:
                    if _access_job["status"] == "running":
                        return self._send_json(200, {"started": False, "already_running": True})
                    _access_job = {"status": "running", "steps": [], "error": None}
                threading.Thread(target=_run_access_job, args=(client,), daemon=True).start()
                return self._send_json(200, {"started": True, "steps": engine.ACCESS_MODEL_STEPS})

            if path == "/api/resource_groups":
                if not _require_client(self._send_json):
                    return
                name = (payload.get("name") or "").strip()
                if not name:
                    return self._send_json(400, {"error": "name is required"})
                group_ids = payload.get("group_ids") or []
                if not group_ids:
                    return self._send_json(
                        400, {"error": "At least one group is required to create a resource group in OPA."}
                    )
                created = client.create_resource_group(
                    name, payload.get("description", ""), delegated_resource_admin_group_ids=group_ids
                )
                return self._send_json(201, {"resource_group": created})

            if path.startswith("/api/resource_groups/") and path.endswith("/projects"):
                if not _require_client(self._send_json):
                    return
                rg_id = path[len("/api/resource_groups/"):-len("/projects")]
                name = (payload.get("name") or "").strip()
                if not rg_id or not name:
                    return self._send_json(400, {"error": "resource_group_id (in URL) and name are required"})
                created = client.create_project(rg_id, name)
                return self._send_json(201, {"project": created})

            if (path.startswith("/api/resource_groups/") and path.endswith("/policy")
                    and "/projects/" in path and "/folders/" in path):
                if not _require_client(self._send_json):
                    return
                inner = path[len("/api/resource_groups/"):-len("/policy")]
                rg_id, _, rest = inner.partition("/projects/")
                proj_id, _, folder_part = rest.partition("/folders/")
                folder_id = folder_part.rstrip("/")
                if not rg_id or not proj_id or not folder_id:
                    return self._send_json(400, {"error": "missing resource_group_id, project_id, or folder_id"})

                mode = payload.get("mode")
                folder_name = payload.get("folder_name", "")
                rule_name = payload.get("rule_name") or f"{folder_name}-access"
                privileges = payload.get("privileges") or {}
                mfa = payload.get("mfa")
                group_refs = payload.get("group_refs") or []
                workload_role_refs = payload.get("workload_role_refs") or []

                if mode == "new":
                    name = (payload.get("name") or "").strip()
                    if not name:
                        return self._send_json(400, {"error": "name is required to create a new policy"})
                    policy_body = {
                        "name": name,
                        "description": payload.get("description", ""),
                        "active": True,
                        "type": "default",
                        "resource_group": {"id": rg_id},
                        "principals": engine.merge_principals(None, group_refs, workload_role_refs),
                        "rules": [],
                    }
                    engine.upsert_folder_rule_in_policy(policy_body, folder_id, folder_name, rule_name, privileges, mfa=mfa)
                    created = client.create_security_policy(policy_body)
                    return self._send_json(201, {"policy": engine.summarize_security_policy(created)})

                if mode == "existing":
                    policy_id = payload.get("policy_id")
                    if not policy_id:
                        return self._send_json(400, {"error": "policy_id is required to attach to an existing policy"})
                    current = client.get_security_policy(policy_id)
                    current["principals"] = engine.merge_principals(current.get("principals"), group_refs, workload_role_refs)
                    engine.upsert_folder_rule_in_policy(current, folder_id, folder_name, rule_name, privileges, mfa=mfa)
                    client.update_security_policy(policy_id, current)
                    updated = client.get_security_policy(policy_id)
                    return self._send_json(200, {"policy": engine.summarize_security_policy(updated)})

                return self._send_json(400, {"error": "mode must be 'new' or 'existing'"})

            if path == "/api/groups":
                if not _require_client(self._send_json):
                    return
                if not _require_okta_client(self._send_json):
                    return
                name = (payload.get("name") or "").strip()
                if not name:
                    return self._send_json(400, {"error": "name is required"})

                app = okta_client.find_privileged_access_app()
                okta_group = okta_client.create_group(name, payload.get("description", ""))
                okta_client.create_group_push_mapping(app["id"], okta_group["id"], name)

                opa_group = None
                for _attempt in range(GROUP_PUSH_PROPAGATION_RETRIES):
                    matches = client.list_groups(contains=name)
                    opa_group = next((g for g in matches if g.get("name") == name), None)
                    if opa_group:
                        break
                    time.sleep(GROUP_PUSH_PROPAGATION_DELAY_SECS)

                if not opa_group:
                    return self._send_json(202, {
                        "created_in_okta": True,
                        "pushed": True,
                        "visible_in_opa": False,
                        "message": f"Group '{name}' was created in Okta and pushed, but hasn't appeared in "
                                   "OPA yet. Try refreshing the group list in a few seconds.",
                    })
                return self._send_json(201, {"created_in_okta": True, "pushed": True, "visible_in_opa": True, "group": opa_group})

            if path == "/api/csv":
                csv_path = _safe_csv_path(payload.get("file"))
                rows = payload.get("rows") or []
                with open(csv_path, "w", newline="", encoding="utf-8") as f:
                    writer = _csv.DictWriter(f, fieldnames=["path", "description"])
                    writer.writeheader()
                    for row in rows:
                        writer.writerow({"path": row.get("path", ""), "description": row.get("description", "")})
                print(f"Saved {len(rows)} row(s) to {csv_path.name}")
                return self._send_json(200, {"saved": True, "file": csv_path.name, "row_count": len(rows)})

            if path == "/api/preview":
                if not _require_client(self._send_json):
                    return
                rg_id = payload.get("resource_group_id")
                proj_id = payload.get("project_id")
                if not rg_id or not proj_id:
                    return self._send_json(400, {"error": "resource_group_id and project_id are required"})
                ordered_paths, _descriptions, existing, collisions, invalid_names = _run_pipeline(
                    payload.get("rows") or [], rg_id, proj_id
                )
                result = _plan_dict(ordered_paths, existing, collisions)
                result["invalid_names"] = invalid_names
                return self._send_json(200, result)

            if path == "/api/execute":
                if not _require_client(self._send_json):
                    return
                rg_id = payload.get("resource_group_id")
                proj_id = payload.get("project_id")
                if not rg_id or not proj_id:
                    return self._send_json(400, {"error": "resource_group_id and project_id are required"})
                ordered_paths, descriptions, existing, collisions, invalid_names = _run_pipeline(
                    payload.get("rows") or [], rg_id, proj_id
                )
                if invalid_names:
                    return self._send_json(
                        400, {"error": "Invalid folder name(s); fix and retry.", "invalid_names": invalid_names}
                    )
                results = engine.execute_plan(client, rg_id, proj_id, ordered_paths, descriptions, existing)
                output_path = PROJECT_ROOT / f"folders_result_{engine.datetime.now(engine.timezone.utc).strftime('%Y%m%d_%H%M%S')}.csv"
                engine.write_results_csv(output_path, results)
                print(f"Execute complete: results written to {output_path.name}")
                return self._send_json(200, {
                    "results": [_row_dict(*r) for r in results],
                    "collisions": {name: ["/".join(p) for p in paths] for name, paths in collisions.items()},
                    "output_file": output_path.name,
                })

            if path.startswith("/api/access/users/") and path.endswith("/resource_access"):
                if not _require_okta_client(self._send_json):
                    return
                user_id = path[len("/api/access/users/"):-len("/resource_access")]
                if not user_id:
                    return self._send_json(400, {"error": "missing user_id"})
                resources = payload.get("resources") or []
                if not resources:
                    return self._send_json(200, {"results": {}})
                if _access_job_result is None:
                    return self._send_json(409, {"error": "Access model not loaded yet -- run the Access Explorer bootstrap first."})
                opa_user = next((u for u in _access_job_result["users"] if u.get("id") == user_id), None)
                if not opa_user:
                    return self._send_json(404, {"error": f"Unknown user id '{user_id}'"})
                # System Log's actor.id is the Okta identity id, not this PAM
                # user's own (OPA-internal) id -- see resolve_okta_actor_id.
                actor_id = engine.resolve_okta_actor_id(okta_client, (opa_user.get("details") or {}).get("email"))
                results = engine.find_last_access_for_user(okta_client, actor_id, resources)
                return self._send_json(200, {"results": results})

            return self._send_json(404, {"error": "not found"})
        except ValueError as exc:
            return self._send_json(400, {"error": str(exc)})
        except (engine.OpaApiError, engine.OktaApiError) as exc:
            return self._send_json(502, {"error": str(exc)})
        except Exception as exc:
            return self._send_json(500, {"error": str(exc)})

    # -----------------------------------------------------------------
    def do_DELETE(self):
        global client, okta_client, active_env_name
        path = urlparse(self.path).path
        try:
            if path.startswith("/api/environments/"):
                name = path[len("/api/environments/"):]
                was_active = engine.delete_environment(name)
                if was_active:
                    client = None
                    okta_client = None
                    active_env_name = None
                return self._send_json(200, {"deleted": name})

            if (path.startswith("/api/resource_groups/") and "/projects/" in path
                    and "/folders/" in path):
                if not _require_client(self._send_json):
                    return
                inner = path[len("/api/resource_groups/"):]
                rg_id, _, rest = inner.partition("/projects/")
                proj_id, _, folder_id = rest.partition("/folders/")
                folder_id = folder_id.rstrip("/")
                if not rg_id or not proj_id or not folder_id:
                    return self._send_json(400, {"error": "missing resource_group_id, project_id, or folder_id"})
                # The raw API gives no cascade guarantee for a non-empty
                # folder (see engine delete_folder docstring), so this
                # dashboard refuses to delete one rather than risk
                # orphaning or mass-deleting its contents.
                items = client.list_folder_items(rg_id, proj_id, folder_id)
                if items:
                    return self._send_json(409, {
                        "error": f"Folder is not empty ({len(items)} item(s) inside) -- "
                                 "remove or move its contents first, then delete it."
                    })
                client.delete_folder(rg_id, proj_id, folder_id)
                return self._send_json(200, {"deleted": folder_id})

            return self._send_json(404, {"error": "not found"})
        except KeyError as exc:
            return self._send_json(404, {"error": str(exc)})
        except (engine.OpaApiError, engine.OktaApiError) as exc:
            return self._send_json(502, {"error": str(exc)})
        except Exception as exc:
            return self._send_json(500, {"error": str(exc)})


def _try_activate_saved_environment():
    """On startup, if the encrypted store already has an active environment
    (e.g. from a previous run), try to reconnect automatically. Failure here
    is NOT fatal -- the server still starts, and the dashboard UI will show
    the setup screen since `client` stays None."""
    data = engine.load_environments()
    name = data.get("active")
    if not name or name not in data.get("environments", {}):
        return
    try:
        activate_environment(name)
    except Exception as exc:
        print(f"Could not auto-activate saved environment '{name}': {exc}")
        print("The dashboard will start anyway -- fix or re-select an environment from the gear menu.")


def main():
    parser = argparse.ArgumentParser(description="Local server for the OPA Secrets Wizard dashboard.")
    parser.add_argument("--port", type=int, default=8766)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    _try_activate_saved_environment()

    if not FRONTEND_DIST.exists():
        print(f"Warning: {FRONTEND_DIST} does not exist yet -- run 'npm run build' in frontend/ first.")

    try:
        server = StrictBindHTTPServer(("127.0.0.1", args.port), Handler)
    except OSError as exc:
        print(f"Could not bind 127.0.0.1:{args.port} ({exc}).")
        print("Likely an existing server is already running on this port -- stop it (Ctrl+C in its")
        print(f"window, or close it) and try again, or run with --port <other_port>.")
        sys.exit(1)

    url = f"http://127.0.0.1:{args.port}/"
    print(f"Serving OPA Secrets Wizard at {url}")
    if client is None:
        print("No environment configured yet -- the dashboard will prompt you to set one up.")
    print("Press Ctrl+C to stop.")

    if not args.no_browser:
        webbrowser.open(url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
```

---
## 4. `requirements.txt`

```
keyring>=25.0
```

---

## 5. `frontend/package.json`

```json
{
  "name": "opa-secrets-folders-frontend",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc -b && vite build",
    "lint": "oxlint",
    "preview": "vite preview"
  },
  "dependencies": {
    "@radix-ui/react-alert-dialog": "^1.1.15",
    "@radix-ui/react-dialog": "^1.1.15",
    "@radix-ui/react-select": "^2.3.2",
    "@radix-ui/react-toast": "^1.2.18",
    "@radix-ui/react-tooltip": "^1.2.11",
    "@tanstack/react-query": "^5.101.2",
    "lucide-react": "^1.23.0",
    "react": "^19.2.7",
    "react-dom": "^19.2.7"
  },
  "devDependencies": {
    "@tailwindcss/vite": "^4.3.2",
    "@types/node": "^24.13.2",
    "@types/react": "^19.2.17",
    "@types/react-dom": "^19.2.3",
    "@vitejs/plugin-react": "^6.0.3",
    "oxlint": "^1.71.0",
    "tailwindcss": "^4.3.2",
    "typescript": "~6.0.2",
    "vite": "^8.1.1"
  }
}
```

---

## 6. `frontend/vite.config.ts`

```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [tailwindcss(), react()],
  server: {
    proxy: {
      '/api': 'http://localhost:8766',
    },
  },
})
```

---

## 7. `frontend/tsconfig.json`

```json
{
  "files": [],
  "references": [
    { "path": "./tsconfig.app.json" },
    { "path": "./tsconfig.node.json" }
  ]
}
```

### `frontend/tsconfig.app.json`

```json
{
  "compilerOptions": {
    "tsBuildInfoFile": "./node_modules/.tmp/tsconfig.app.tsbuildinfo",
    "target": "es2023",
    "lib": ["ES2023", "DOM"],
    "module": "esnext",
    "types": ["vite/client"],
    "allowArbitraryExtensions": true,
    "skipLibCheck": true,

    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "verbatimModuleSyntax": true,
    "moduleDetection": "force",
    "noEmit": true,
    "jsx": "react-jsx",

    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "erasableSyntaxOnly": true,
    "noFallthroughCasesInSwitch": true
  },
  "include": ["src"]
}
```

### `frontend/tsconfig.node.json`

```json
{
  "compilerOptions": {
    "tsBuildInfoFile": "./node_modules/.tmp/tsconfig.node.tsbuildinfo",
    "target": "es2023",
    "lib": ["ES2023"],
    "types": ["node"],
    "skipLibCheck": true,

    "module": "nodenext",
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "verbatimModuleSyntax": true,
    "moduleDetection": "force",
    "noEmit": true,

    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "erasableSyntaxOnly": true,
    "noFallthroughCasesInSwitch": true
  },
  "include": ["vite.config.ts"]
}
```

---

## 8. `frontend/.oxlintrc.json`

```json
{
  "$schema": "./node_modules/oxlint/configuration_schema.json",
  "plugins": ["react", "typescript", "oxc"],
  "rules": {
    "react/rules-of-hooks": "error",
    "react/only-export-components": ["warn", { "allowConstantExport": true }]
  }
}
```

---

## 9. `frontend/index.html`

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>OPA Secrets Wizard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

---
## 10. `frontend/src/types/index.ts`

Every shared TypeScript type — the Access Explorer types and the Folder
Builder policy types are deliberately kept separate (see the comment in the
file) even though they overlap, since the two features evolved and get
tested independently.

```typescript
export interface Environment {
  name: string
  base_domain: string
  team_name: string
  key_id: string
  okta_url: string
  has_okta_token: boolean
}

export interface EnvironmentsResponse {
  environments: Environment[]
  active: string | null
}

export interface EnvironmentFormValues {
  name: string
  base_domain: string
  team_name: string
  key_id: string
  key_secret: string
  okta_url: string
  okta_api_token: string
}

export interface ResourceGroup {
  id: string
  name: string
  description?: string
}

export interface Project {
  id: string
  name: string
}

export interface OpaGroup {
  id: string
  name: string
  roles: string[]
}

export interface CreateGroupResponse {
  created_in_okta: boolean
  pushed: boolean
  visible_in_opa: boolean
  group?: OpaGroup
  message?: string
}

export interface FolderNode {
  id: string // client-only, for React keys / stable identity during edits
  name: string
  description: string
  children: FolderNode[]
}

export interface CsvRow {
  path: string
  description: string
  /** Only present when rows came from "Load Current Structure" (real OPA
   * folders), never from an actual CSV file on disk -- CSV load/save
   * only ever reads/writes path+description. */
  folder_id?: string
}

export interface PreviewTreeItem {
  path: string
  depth: number
  exists: boolean
  folder_id: string
}

export interface InvalidName {
  path: string
  name: string
}

export interface PreviewResponse {
  tree: PreviewTreeItem[]
  collisions: Record<string, string[]>
  invalid_names: InvalidName[]
}

export type ExecuteStatus = 'created' | 'skipped_exists' | 'error'

export interface ExecuteResultRow {
  path: string
  folder_id: string
  status: ExecuteStatus
  error_message: string
}

export interface ExecuteResponse {
  results: ExecuteResultRow[]
  collisions: Record<string, string[]>
  output_file: string
}

export interface ApiErrorBody {
  error: string
  invalid_names?: InvalidName[]
  saved?: boolean
}

// ── Access Explorer ──────────────────────────────────────────────────────

export interface NamedRef {
  id: string
  name: string
  type?: string
}

export interface AccessResourceGroup {
  id: string
  name: string
  description?: string
  team_id?: string
  delegated_resource_admin_groups?: NamedRef[]
}

/** Every field the Project API returns (settings, counts, etc.) plus
 * resource_group_id, which build_access_model adds during the walk since
 * the Project object itself doesn't carry it. Kept as an open record
 * (rather than listing every field) so a "show everything" grid renders
 * new fields automatically if OPA's API grows more. */
export interface AccessProject extends Record<string, unknown> {
  id: string
  name: string
  resource_group_id: string
}

export interface AccessGroup {
  id: string
  name: string
  roles: string[]
  deleted_at?: string | null
}

export interface AccessUser {
  id: string
  name: string
  status?: string
  details?: { email?: string | null; first_name?: string | null; last_name?: string | null; full_name?: string | null }
  groups: NamedRef[]
}

export interface PolicyPrincipals {
  user_groups: NamedRef[]
  workload_roles: NamedRef[]
}

export type PolicyRuleResolution =
  | {
      kind: 'resolved'
      id: string
      name: string
      /** Raw selector_type (e.g. "secret" vs "secret_folder") -- resource_type
       * alone can't distinguish these, but System Log access-tracking only
       * works for one of them. See useUserResourceAccess. */
      resource_kind: string
      project_id: string | null
      project_name: string | null
      resource_group_id: string | null
      /** Only present for resource_kind "secret_folder" -- every secret
       * nested anywhere in this folder's subtree (any depth). A folder grant
       * covers all of these, but System Log access is only attributable per
       * secret, so the UI expands this list to query/report access. */
      child_secrets?: { id: string; name: string }[]
      /** Only present for SaaS/Okta account kinds -- their displayed `id`
       * is the Okta-side identifier (AppUser id / Okta user id), but System
       * Log access events reference the account's separate OPA-internal id
       * instead (that Okta-side id is never logged as a target at all).
       * Query/look up access info by this id when present, falling back
       * to `id` otherwise. */
      access_tracking_id?: string
    }
  | { kind: 'condition'; description: string }

export interface PolicyRulePrivilege {
  privilege_type: string
  flags: string[]
}

export interface PolicyRuleCondition {
  condition_type: string
  condition_value: Record<string, unknown>
}

export interface PolicyRule {
  name: string
  resource_type: string
  resource_type_label: string
  privileges: PolicyRulePrivilege[]
  conditions: PolicyRuleCondition[]
  resolutions: PolicyRuleResolution[]
}

export interface AccessPolicy {
  id: string
  name: string
  description: string
  active: boolean
  type?: string
  resource_group: NamedRef | null
  principals: PolicyPrincipals
  rules: PolicyRule[]
}

export interface AccessModel {
  resource_groups: AccessResourceGroup[]
  projects: AccessProject[]
  groups: AccessGroup[]
  users: AccessUser[]
  policies: AccessPolicy[]
}

// ── Access Explorer: System Log last-accessed lookup ─────────────────────
// On-demand only (see UsersTab) -- querying this for every user/resource up
// front would be slow and could hit Okta rate limits for no benefit, since
// nobody looks at most of it.

export interface ResourceAccessEvent {
  published: string
  request_id: string | null
  outcome: string | null
}

export interface ResourceAccessInfo {
  resource_kind: string
  /** False for any resource_kind with no verified, ID-matchable System Log
   * event (see create_secret_folders.py's RESOURCE_ACCESS_EVENT_TYPES
   * comment) -- distinct from "supported but zero events found", which
   * means genuinely not accessed (or not within the last 90 days). */
  supported: boolean
  events: ResourceAccessEvent[]
}

// ── Folder Builder: policy assignment ────────────────────────────────────
// Deliberately separate from the Access Explorer types above (NamedRef,
// PolicyPrincipals, PolicyRuleCondition are shared/reused) since this
// context already knows which project it's in and never needs project
// attribution — see create_secret_folders.py's summarize_security_policy.

export type FolderPolicyTarget = { kind: 'resolved'; id: string; name: string } | { kind: 'condition'; description: string }

export interface FolderPolicyRulePrivilege {
  privilege_type: string
  flags: string[]
}

export interface FolderPolicyRule {
  name: string
  resource_type: string
  resource_type_label: string
  privileges: FolderPolicyRulePrivilege[]
  conditions: PolicyRuleCondition[]
  targets: FolderPolicyTarget[]
}

export interface FolderSecurityPolicy {
  id: string
  name: string
  description: string
  active: boolean
  type?: string
  resource_group: NamedRef | null
  principals: PolicyPrincipals
  rules: FolderPolicyRule[]
}

export interface WorkloadRole {
  id: string
  name: string
}

export interface FolderAccessEntry {
  policyId: string
  policyName: string
  policyActive: boolean
  ruleName: string
  groups: NamedRef[]
  workloadRoles: NamedRef[]
  privileges: FolderPolicyRulePrivilege[]
}
```

---

## 11. `frontend/src/api/client.ts`

Thin `fetch` wrapper (`apiFetch<T>`) plus one function per backend route.
No client library (axios, etc.) — the API surface is small enough that
stdlib `fetch` plus typed return values was simpler.

```typescript
import type {
  AccessModel,
  ApiErrorBody,
  CreateGroupResponse,
  CsvRow,
  EnvironmentFormValues,
  EnvironmentsResponse,
  ExecuteResponse,
  FolderSecurityPolicy,
  NamedRef,
  OpaGroup,
  PreviewResponse,
  Project,
  ResourceAccessInfo,
  ResourceGroup,
  WorkloadRole,
} from '../types'

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...init?.headers },
  })
  if (!res.ok) {
    let body: ApiErrorBody | null = null
    try {
      body = await res.json()
    } catch {
      // ignore — fall through to generic message
    }
    const err = new Error(body?.error || `Request failed with status ${res.status}`) as Error & { body?: ApiErrorBody }
    err.body = body ?? undefined
    throw err
  }
  return res.json() as Promise<T>
}

export function fetchEnvironments(): Promise<EnvironmentsResponse> {
  return apiFetch('/api/environments')
}

export function saveEnvironment(values: EnvironmentFormValues): Promise<{ activated: boolean; active: string }> {
  return apiFetch('/api/environments', { method: 'POST', body: JSON.stringify(values) })
}

export function activateEnvironment(name: string): Promise<{ activated: boolean; active: string }> {
  return apiFetch(`/api/environments/${encodeURIComponent(name)}/activate`, { method: 'POST' })
}

export function deleteEnvironment(name: string): Promise<{ deleted: string }> {
  return apiFetch(`/api/environments/${encodeURIComponent(name)}`, { method: 'DELETE' })
}

export function fetchResourceGroups(): Promise<{ resource_groups: ResourceGroup[] }> {
  return apiFetch('/api/resource_groups')
}

export function fetchProjects(resourceGroupId: string): Promise<{ projects: Project[] }> {
  return apiFetch(`/api/resource_groups/${encodeURIComponent(resourceGroupId)}/projects`)
}

export function createResourceGroup(name: string, description: string, groupIds: string[]): Promise<{ resource_group: ResourceGroup }> {
  return apiFetch('/api/resource_groups', {
    method: 'POST',
    body: JSON.stringify({ name, description, group_ids: groupIds }),
  })
}

export function createProject(resourceGroupId: string, name: string): Promise<{ project: Project }> {
  return apiFetch(`/api/resource_groups/${encodeURIComponent(resourceGroupId)}/projects`, {
    method: 'POST',
    body: JSON.stringify({ name }),
  })
}

export function fetchExistingFolders(resourceGroupId: string, projectId: string): Promise<{ rows: CsvRow[] }> {
  return apiFetch(
    `/api/resource_groups/${encodeURIComponent(resourceGroupId)}/projects/${encodeURIComponent(projectId)}/folders`
  )
}

export function deleteFolder(
  resourceGroupId: string,
  projectId: string,
  folderId: string
): Promise<{ deleted: string }> {
  return apiFetch(
    `/api/resource_groups/${encodeURIComponent(resourceGroupId)}/projects/${encodeURIComponent(projectId)}/folders/${encodeURIComponent(folderId)}`,
    { method: 'DELETE' }
  )
}

export function fetchGroups(contains?: string): Promise<{ groups: OpaGroup[] }> {
  const qs = contains ? `?contains=${encodeURIComponent(contains)}` : ''
  return apiFetch(`/api/groups${qs}`)
}

export function createGroup(name: string, description: string): Promise<CreateGroupResponse> {
  return apiFetch('/api/groups', { method: 'POST', body: JSON.stringify({ name, description }) })
}

export function fetchCsvFiles(): Promise<{ files: string[] }> {
  return apiFetch('/api/csv_files')
}

export function fetchCsv(file: string): Promise<{ rows: CsvRow[] }> {
  return apiFetch(`/api/csv?file=${encodeURIComponent(file)}`)
}

export function saveCsv(file: string, rows: CsvRow[]): Promise<{ saved: boolean; file: string; row_count: number }> {
  return apiFetch('/api/csv', { method: 'POST', body: JSON.stringify({ file, rows }) })
}

export function preview(resourceGroupId: string, projectId: string, rows: CsvRow[]): Promise<PreviewResponse> {
  return apiFetch('/api/preview', {
    method: 'POST',
    body: JSON.stringify({ resource_group_id: resourceGroupId, project_id: projectId, rows }),
  })
}

export function execute(resourceGroupId: string, projectId: string, rows: CsvRow[]): Promise<ExecuteResponse> {
  return apiFetch('/api/execute', {
    method: 'POST',
    body: JSON.stringify({ resource_group_id: resourceGroupId, project_id: projectId, rows }),
  })
}

/** The Access Explorer bootstrap runs as a background job (it's not
 * cheap — see build_access_model's docstring) rather than one blocking
 * request, so the UI can show real step-by-step progress instead of a
 * bare spinner. See useAccessBootstrapJob for the polling loop. */
export interface BootstrapStepEvent {
  key: string
  status: 'start' | 'progress' | 'done'
  detail: string | null
}
export interface BootstrapStartResponse {
  started: boolean
  already_running?: boolean
  steps?: [string, string][]
}
export interface BootstrapStatusResponse {
  status: 'idle' | 'running' | 'done' | 'error'
  steps: BootstrapStepEvent[]
  error: string | null
}

export function startAccessBootstrap(): Promise<BootstrapStartResponse> {
  return apiFetch('/api/access/bootstrap/start', { method: 'POST' })
}

export function fetchAccessBootstrapStatus(): Promise<BootstrapStatusResponse> {
  return apiFetch('/api/access/bootstrap/status')
}

export function fetchAccessBootstrapResult(): Promise<AccessModel> {
  return apiFetch('/api/access/bootstrap/result')
}

// ── Folder Builder: policy assignment ────────────────────────────────────

export function fetchResourceGroupSecurityPolicies(resourceGroupId: string): Promise<{ policies: FolderSecurityPolicy[] }> {
  return apiFetch(`/api/resource_groups/${encodeURIComponent(resourceGroupId)}/security_policies`)
}

export function fetchWorkloadRoles(contains?: string): Promise<{ workload_roles: WorkloadRole[] }> {
  const qs = contains ? `?contains=${encodeURIComponent(contains)}` : ''
  return apiFetch(`/api/workload_roles${qs}`)
}

export interface AssignFolderPolicyPayload {
  mode: 'new' | 'existing'
  policy_id?: string
  name?: string
  description?: string
  folder_name: string
  rule_name?: string
  group_refs: NamedRef[]
  workload_role_refs: NamedRef[]
  privileges: Record<string, boolean>
  mfa: { reauth_seconds: number; acr_values: string } | null
}

export function assignFolderPolicy(
  resourceGroupId: string,
  projectId: string,
  folderId: string,
  payload: AssignFolderPolicyPayload
): Promise<{ policy: FolderSecurityPolicy }> {
  return apiFetch(
    `/api/resource_groups/${encodeURIComponent(resourceGroupId)}/projects/${encodeURIComponent(projectId)}/folders/${encodeURIComponent(folderId)}/policy`,
    { method: 'POST', body: JSON.stringify(payload) }
  )
}

export function fetchUserResourceAccess(
  userId: string,
  resources: { resource_kind: string; resource_id: string }[]
): Promise<{ results: Record<string, ResourceAccessInfo> }> {
  return apiFetch(`/api/access/users/${encodeURIComponent(userId)}/resource_access`, {
    method: 'POST',
    body: JSON.stringify({ resources }),
  })
}
```

---

## 12. `frontend/src/api/hooks.ts`

TanStack Query wrappers over `client.ts`.

```typescript
import { useQuery } from '@tanstack/react-query'
import {
  fetchCsvFiles,
  fetchEnvironments,
  fetchGroups,
  fetchProjects,
  fetchResourceGroupSecurityPolicies,
  fetchResourceGroups,
  fetchUserResourceAccess,
  fetchWorkloadRoles,
} from './client'

export function useEnvironments() {
  return useQuery({
    queryKey: ['environments'],
    queryFn: fetchEnvironments,
  })
}

export function useResourceGroups(enabled = true) {
  return useQuery({
    queryKey: ['resource_groups'],
    queryFn: async () => (await fetchResourceGroups()).resource_groups,
    enabled,
  })
}

export function useProjects(resourceGroupId: string | undefined, enabled = true) {
  return useQuery({
    queryKey: ['projects', resourceGroupId],
    queryFn: async () => (await fetchProjects(resourceGroupId!)).projects,
    enabled: enabled && !!resourceGroupId,
  })
}

export function useCsvFiles() {
  return useQuery({
    queryKey: ['csv_files'],
    queryFn: async () => (await fetchCsvFiles()).files,
  })
}

export function useGroups(enabled = true) {
  return useQuery({
    queryKey: ['groups'],
    queryFn: async () => (await fetchGroups()).groups,
    enabled,
  })
}

export function useResourceGroupSecurityPolicies(resourceGroupId: string | undefined, enabled = true) {
  return useQuery({
    queryKey: ['security_policies', resourceGroupId],
    queryFn: async () => (await fetchResourceGroupSecurityPolicies(resourceGroupId!)).policies,
    enabled: enabled && !!resourceGroupId,
  })
}

export function useWorkloadRoles(enabled = true) {
  return useQuery({
    queryKey: ['workload_roles'],
    queryFn: async () => (await fetchWorkloadRoles()).workload_roles,
    enabled,
  })
}

/** Fires automatically once `userId` and `resources` are both non-empty
 * (e.g. right after selecting a user in UsersTab) -- not a manual
 * "check access" button. Kept on-demand per-user rather than folded into
 * the big Access Explorer bootstrap: fetching this for every user's every
 * resource up front would be slow and mostly wasted, since nobody looks
 * at most of it. */
export function useUserResourceAccess(
  userId: string | undefined,
  resources: { resource_kind: string; resource_id: string }[]
) {
  const resourceKey = resources.map(r => `${r.resource_kind}:${r.resource_id}`).sort().join(',')
  return useQuery({
    queryKey: ['user_resource_access', userId, resourceKey],
    queryFn: async () => (await fetchUserResourceAccess(userId!, resources)).results,
    enabled: !!userId && resources.length > 0,
  })
}
```

---
## 13. `frontend/src/utils/*.ts`

### `utils/tree.ts` — folder-tree data structure helpers (client-side mirror of `parse_rows`/`rows_from_tree`)

```typescript
import type { CsvRow, FolderNode } from '../types'

function newId(): string {
  return (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : Math.random().toString(36).slice(2)
}

export function newNode(name = '', description = ''): FolderNode {
  return { id: newId(), name, description, children: [] }
}

/** Recursively flattens the tree into CSV-shaped rows (one row per node, any depth). */
export function flattenTree(nodes: FolderNode[], parentPath: string[] = []): CsvRow[] {
  const rows: CsvRow[] = []
  for (const node of nodes) {
    const path = [...parentPath, node.name]
    rows.push({ path: path.join('/'), description: node.description })
    rows.push(...flattenTree(node.children, path))
  }
  return rows
}

/** Inverse of flattenTree: builds a nested tree from flat '/'-delimited rows. */
export function treeFromRows(rows: CsvRow[]): FolderNode[] {
  const root: FolderNode[] = []

  for (const row of rows) {
    const segments = row.path.split('/').map(s => s.trim()).filter(Boolean)
    if (segments.length === 0) continue

    let level = root
    let builtPath: string[] = []
    segments.forEach((segment, depth) => {
      builtPath = [...builtPath, segment]
      let existing = level.find(n => n.name === segment)
      if (!existing) {
        existing = newNode(segment)
        level.push(existing)
      }
      if (depth === segments.length - 1 && row.description) {
        existing.description = row.description
      }
      level = existing.children
    })
  }

  return root
}

export function findNode(nodes: FolderNode[], id: string): FolderNode | null {
  for (const node of nodes) {
    if (node.id === id) return node
    const found = findNode(node.children, id)
    if (found) return found
  }
  return null
}

export function addChild(nodes: FolderNode[], parentId: string | null, child: FolderNode): FolderNode[] {
  if (parentId === null) return [...nodes, child]
  return nodes.map(node => {
    if (node.id === parentId) return { ...node, children: [...node.children, child] }
    return { ...node, children: addChild(node.children, parentId, child) }
  })
}

export function removeNode(nodes: FolderNode[], id: string): FolderNode[] {
  return nodes
    .filter(node => node.id !== id)
    .map(node => ({ ...node, children: removeNode(node.children, id) }))
}

export function updateNode(nodes: FolderNode[], id: string, patch: Partial<Pick<FolderNode, 'name' | 'description'>>): FolderNode[] {
  return nodes.map(node => {
    if (node.id === id) return { ...node, ...patch }
    return { ...node, children: updateNode(node.children, id, patch) }
  })
}

export function countNodes(nodes: FolderNode[]): number {
  return nodes.reduce((sum, n) => sum + 1 + countNodes(n.children), 0)
}
```

### `utils/validate.ts` — mirrors `NAME_PATTERN` in `create_secret_folders.py`

```typescript
// Mirrors NAME_PATTERN in create_secret_folders.py -- OPA rejects anything
// else, so we validate client-side for instant feedback before the user
// ever clicks Preview/Create.
export const NAME_PATTERN = /^[A-Za-z0-9._-]+$/

export function isValidName(name: string): boolean {
  return name.length > 0 && NAME_PATTERN.test(name)
}
```

### `utils/policy.ts` — policy/rule join helpers shared by Access Explorer's tabs

```typescript
import type { AccessPolicy, PolicyRule, PolicyRuleCondition } from '../types'

/** Human-readable description of a rule-level condition (MFA / gateway /
 * access request) — these shapes are simple and stable, unlike the
 * dynamic resource selectors the backend already describes for us. */
export function describeCondition(condition: PolicyRuleCondition): string {
  const v = condition.condition_value ?? {}
  switch (condition.condition_type) {
    case 'mfa': {
      const freq = v.re_auth_frequency_in_seconds
      const freqText = typeof freq === 'number' && freq > 0 ? `every ${freq}s` : 'once per session'
      return `MFA required (${freqText}${v.acr_values ? `, ${v.acr_values}` : ''})`
    }
    case 'gateway': {
      const parts: string[] = []
      if (v.traffic_forwarding) parts.push('traffic forwarding')
      if (v.session_recording) parts.push('session recording')
      return `Gateway: ${parts.length ? parts.join(', ') : 'required'}`
    }
    case 'access_request': {
      const name = typeof v.request_type_name === 'string' ? v.request_type_name : 'request'
      const expires = v.expires_after_seconds
      return `Access request "${name}"${typeof expires === 'number' ? ` — expires after ${expires}s` : ''}`
    }
    default:
      return condition.condition_type
  }
}

export interface GrantedRule {
  policy: AccessPolicy
  rule: PolicyRule
}

/** Every (policy, rule) pair whose policy's principals.user_groups
 * includes any of the given group IDs — the shared "what does this
 * group/user have access to" join used by the Users and Groups tabs.
 * A rule appears once per matching policy, even if the policy grants
 * access via more than one of the given groups. */
export function rulesGrantedToGroupIds(policies: AccessPolicy[], groupIds: Set<string>): GrantedRule[] {
  const out: GrantedRule[] = []
  for (const policy of policies) {
    const grants = policy.principals.user_groups.some(g => groupIds.has(g.id))
    if (!grants) continue
    for (const rule of policy.rules) {
      out.push({ policy, rule })
    }
  }
  return out
}

/** Every (policy, rule) pair whose rule resolves to the given project. */
export function rulesGrantedForProject(policies: AccessPolicy[], projectId: string): GrantedRule[] {
  const out: GrantedRule[] = []
  for (const policy of policies) {
    for (const rule of policy.rules) {
      if (rule.resolutions.some(r => r.kind === 'resolved' && r.project_id === projectId)) {
        out.push({ policy, rule })
      }
    }
  }
  return out
}

/** Every policy scoped to the given resource group (policy.resource_group.id
 * match) — policies with no resource_group at all ("team-wide") never match. */
export function policiesForResourceGroup(policies: AccessPolicy[], resourceGroupId: string): AccessPolicy[] {
  return policies.filter(p => p.resource_group?.id === resourceGroupId)
}
```

### `utils/export.ts` — generic CSV/Markdown serializers + client-side download

```typescript
export interface ExportSection {
  title: string
  rows: Record<string, string>[]
}

function csvEscape(value: string): string {
  return /[",\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value
}

/** Multiple sections in one CSV file, separated by a blank line, each
 * preceded by its own title line — opens fine as one sheet in Excel/
 * Sheets (distinct visual blocks) without needing a multi-file export. */
export function toCsv(sections: ExportSection[]): string {
  const blocks = sections
    .filter(s => s.rows.length > 0)
    .map(section => {
      const columns = Object.keys(section.rows[0])
      const lines = [csvEscape(section.title), columns.map(csvEscape).join(',')]
      for (const row of section.rows) {
        lines.push(columns.map(c => csvEscape(row[c] ?? '')).join(','))
      }
      return lines.join('\n')
    })
  return blocks.join('\n\n')
}

export function toMarkdown(sections: ExportSection[]): string {
  const blocks = sections
    .filter(s => s.rows.length > 0)
    .map(section => {
      const columns = Object.keys(section.rows[0])
      const lines = [
        `## ${section.title}`,
        '',
        `| ${columns.join(' | ')} |`,
        `| ${columns.map(() => '---').join(' | ')} |`,
        ...section.rows.map(row => `| ${columns.map(c => (row[c] ?? '').replace(/\|/g, '\\|')).join(' | ')} |`),
      ]
      return lines.join('\n')
    })
  return blocks.join('\n\n')
}

export function downloadTextFile(filename: string, content: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

export function exportSections(sections: ExportSection[], format: 'csv' | 'md', filenameBase: string): void {
  if (format === 'csv') {
    downloadTextFile(`${filenameBase}.csv`, toCsv(sections), 'text/csv')
  } else {
    downloadTextFile(`${filenameBase}.md`, toMarkdown(sections), 'text/markdown')
  }
}
```

### `utils/exportSections.ts` — row-shape builders per entity type (reused by per-tab and global export)

```typescript
import type { AccessModel, AccessPolicy, AccessProject, PolicyRule } from '../types'
import type { ExportSection } from './export'
import { cellValue, labelize } from './format'
import type { GrantedRule } from './policy'
import { describeCondition } from './policy'

function grantRow(policy: AccessPolicy, rule: PolicyRule): Record<string, string> {
  return {
    Policy: policy.name,
    'Policy Active': policy.active ? 'Yes' : 'No',
    'Resource Group': policy.resource_group?.name ?? 'Team-wide',
    Rule: rule.name,
    'Resource Type': rule.resource_type_label,
    'Applies To': rule.resolutions
      .map(r =>
        r.kind === 'resolved'
          ? `${r.name}${r.project_name ? ` — ${r.project_name}` : ' (project unknown)'}`
          : r.description
      )
      .join('; '),
    Privileges: rule.privileges
      .map(p => (p.flags.length ? `${p.privilege_type}: ${p.flags.join(',')}` : p.privilege_type))
      .join('; '),
    Conditions: rule.conditions.map(c => describeCondition(c)).join('; '),
  }
}

export function grantRows(grants: GrantedRule[]): Record<string, string>[] {
  return grants.map(({ policy, rule }) => grantRow(policy, rule))
}

/** One row per field — for exporting a single project's detail (matches
 * the Projects tab's KeyValueGrid). */
export function projectFieldRows(project: AccessProject): Record<string, string>[] {
  return Object.entries(project).map(([key, value]) => ({ Field: labelize(key), Value: cellValue(value) }))
}

/** One row per project, columns = union of fields across all of them —
 * for the global export, where a wide table reads better than melting
 * every field into its own row per project. */
export function projectSummaryRows(projects: AccessProject[]): Record<string, string>[] {
  const columns: string[] = []
  for (const p of projects) {
    for (const key of Object.keys(p)) if (!columns.includes(key)) columns.push(key)
  }
  return projects.map(p => {
    const row: Record<string, string> = {}
    for (const key of columns) row[labelize(key)] = cellValue(p[key])
    return row
  })
}

export function policySummaryRows(policies: AccessPolicy[]): Record<string, string>[] {
  return policies.map(p => ({
    Policy: p.name,
    Active: p.active ? 'Yes' : 'No',
    'Resource Group': p.resource_group?.name ?? 'Team-wide',
    'Rule Count': String(p.rules.length),
    'Principal Groups': p.principals.user_groups.map(g => g.name).join(', '),
  }))
}

/** The "export everything" report — one section per category, covering
 * the whole access model regardless of what's currently selected on
 * screen. */
export function accessModelExportSections(model: AccessModel): ExportSection[] {
  return [
    {
      title: 'Resource Groups',
      rows: model.resource_groups.map(rg => ({
        'Resource Group': rg.name,
        Description: rg.description ?? '',
        'Delegated Admin Groups': (rg.delegated_resource_admin_groups ?? []).map(g => g.name).join(', '),
      })),
    },
    { title: 'Projects', rows: projectSummaryRows(model.projects) },
    { title: 'Policies', rows: policySummaryRows(model.policies) },
    { title: 'Policy Rules', rows: model.policies.flatMap(p => p.rules.map(r => grantRow(p, r))) },
    {
      title: 'Users',
      rows: model.users.map(u => ({
        User: u.details?.full_name || u.name,
        Email: u.details?.email ?? '',
        Status: u.status ?? '',
        Groups: u.groups.map(g => g.name).join(', '),
      })),
    },
    {
      title: 'Groups',
      rows: model.groups.map(g => ({ Group: g.name, Roles: g.roles.join(', ') })),
    },
  ]
}
```

### `utils/folderAccess.ts` — matches Folder Builder policy targets against real OPA folder IDs

```typescript
import type { FolderAccessEntry, FolderSecurityPolicy } from '../types'

/** For every folder whose real OPA ID is known (folderIdByPath), find
 * every policy rule that targets it directly — matches by ID against
 * each rule's "resolved" targets (secret_folder selectors only matter
 * here; dynamic/condition targets never name a specific folder). */
export function resolveFolderAccess(
  policies: FolderSecurityPolicy[],
  folderIdByPath: Map<string, string>
): Map<string, FolderAccessEntry[]> {
  const result = new Map<string, FolderAccessEntry[]>()
  for (const [path, folderId] of folderIdByPath) {
    const entries: FolderAccessEntry[] = []
    for (const policy of policies) {
      for (const rule of policy.rules) {
        const hit = rule.targets.some(t => t.kind === 'resolved' && t.id === folderId)
        if (!hit) continue
        entries.push({
          policyId: policy.id,
          policyName: policy.name,
          policyActive: policy.active,
          ruleName: rule.name,
          groups: policy.principals.user_groups,
          workloadRoles: policy.principals.workload_roles,
          privileges: rule.privileges,
        })
      }
    }
    if (entries.length > 0) result.set(path, entries)
  }
  return result
}
```

### `utils/format.ts` — display/export value formatting

```typescript
export function labelize(key: string): string {
  return key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
}

/** Renders an ISO timestamp (e.g. a System Log `published` field) in the
 * viewer's local timezone, falling back to the raw string for anything
 * that doesn't parse as a date rather than showing "Invalid Date". */
export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return '—'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  return d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })
}

/** Renders a value for on-screen display — empty/null/undefined become an
 * em dash so a field reads as "known to be empty" rather than looking
 * broken. Use `cellValue` instead for exports, where a plain empty string
 * is more useful for downstream processing. */
export function displayValue(value: unknown): string {
  if (value === null || value === undefined || value === '') return '—'
  if (Array.isArray(value) && value.length === 0) return '—'
  return cellValue(value)
}

/** Renders a value as plain text with no placeholder for empty — the
 * export-friendly counterpart to displayValue. */
export function cellValue(value: unknown): string {
  if (value === null || value === undefined) return ''
  if (typeof value === 'boolean') return value ? 'Yes' : 'No'
  if (Array.isArray(value)) return value.map(v => cellValue(v)).join(', ')
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}
```

---

## 14. `frontend/src/hooks/*.ts`

### `hooks/useToast.ts` — minimal global toast bus (no context provider needed)

```typescript
import { useState, useEffect, useCallback } from 'react'

export interface ToastMessage {
  id: string
  title: string
  description?: string
  variant?: 'default' | 'success' | 'error'
}

type Listener = (msg: ToastMessage) => void
const listeners: Set<Listener> = new Set()

export function toast(msg: Omit<ToastMessage, 'id'>) {
  const message: ToastMessage = { ...msg, id: String(Date.now()) }
  listeners.forEach(l => l(message))
}

export function useToastMessages() {
  const [messages, setMessages] = useState<ToastMessage[]>([])

  useEffect(() => {
    const listener: Listener = (msg) => setMessages(prev => [...prev, msg])
    listeners.add(listener)
    return () => { listeners.delete(listener) }
  }, [])

  const dismiss = useCallback((id: string) => {
    setMessages(prev => prev.filter(m => m.id !== id))
  }, [])

  return { messages, dismiss }
}
```

### `hooks/useAccessBootstrapJob.ts` — polls the background Access Explorer bootstrap job

```typescript
import { useCallback, useEffect, useRef, useState } from 'react'
import { fetchAccessBootstrapResult, fetchAccessBootstrapStatus, startAccessBootstrap } from '../api/client'
import type { BootstrapStepEvent } from '../api/client'
import type { AccessModel } from '../types'

const POLL_INTERVAL_MS = 1000

export type JobPhase = 'idle' | 'starting' | 'running' | 'done' | 'error'

interface JobState {
  phase: JobPhase
  stepDefs: [string, string][]
  events: BootstrapStepEvent[]
  error: string | null
  result: AccessModel | null
}

const INITIAL_STATE: JobState = { phase: 'idle', stepDefs: [], events: [], error: null, result: null }

/** Drives the background bootstrap job: POST /start, poll /status every
 * second, fetch /result once done. Exposes enough for a UI to show real
 * step-by-step progress (not just a spinner) and a Retry that restarts
 * cleanly from scratch — simplest correct recovery, given steps build on
 * each other so resuming mid-way isn't worth the complexity. */
export function useAccessBootstrapJob() {
  const [state, setState] = useState<JobState>(INITIAL_STATE)
  const pollHandle = useRef<number | null>(null)

  const stopPolling = useCallback(() => {
    if (pollHandle.current !== null) {
      window.clearInterval(pollHandle.current)
      pollHandle.current = null
    }
  }, [])

  const poll = useCallback(() => {
    fetchAccessBootstrapStatus()
      .then(status => {
        setState(s => ({ ...s, events: status.steps, error: status.error }))
        if (status.status === 'done') {
          stopPolling()
          return fetchAccessBootstrapResult().then(result => setState(s => ({ ...s, phase: 'done', result })))
        }
        if (status.status === 'error') {
          stopPolling()
          setState(s => ({ ...s, phase: 'error' }))
        }
      })
      .catch(err => {
        stopPolling()
        setState(s => ({ ...s, phase: 'error', error: err instanceof Error ? err.message : String(err) }))
      })
  }, [stopPolling])

  const start = useCallback(() => {
    stopPolling()
    setState({ phase: 'starting', stepDefs: [], events: [], error: null, result: null })
    startAccessBootstrap()
      .then(resp => {
        setState(s => ({ ...s, phase: 'running', stepDefs: resp.steps ?? [] }))
        pollHandle.current = window.setInterval(poll, POLL_INTERVAL_MS)
        poll()
      })
      .catch(err => {
        setState(s => ({ ...s, phase: 'error', error: err instanceof Error ? err.message : String(err) }))
      })
  }, [poll, stopPolling])

  useEffect(() => stopPolling, [stopPolling])

  return { ...state, start }
}
```

### `hooks/useLoadExistingFolders.ts` — loads a project's existing OPA folders into the tree editor

```typescript
import { useMutation } from '@tanstack/react-query'
import { fetchExistingFolders } from '../api/client'
import type { FolderNode } from '../types'
import { treeFromRows } from '../utils/tree'

/** Shared fetch+convert logic for loading a project's existing (flat) folder
 * list into the tree editor. OPA exposes no parent/child linkage on read, so
 * every existing folder loads as a root-level node — see module docstring
 * fact #2 in create_secret_folders.py for why.
 *
 * onLoad's second argument maps each row's path to its real OPA folder_id
 * (rows without one are omitted) — the caller needs this to know which
 * folders can have a security policy assigned. */
export function useLoadExistingFolders(onLoad: (nodes: FolderNode[], folderIdByPath: Map<string, string>) => void) {
  return useMutation({
    mutationFn: (vars: { resourceGroupId: string; projectId: string }) =>
      fetchExistingFolders(vars.resourceGroupId, vars.projectId),
    onSuccess: (data) => {
      const folderIdByPath = new Map(
        data.rows.filter(r => r.folder_id).map(r => [r.path, r.folder_id as string])
      )
      onLoad(treeFromRows(data.rows), folderIdByPath)
    },
  })
}
```

### `hooks/useCreateGroup.ts` — shared "create in Okta, push into OPA" mutation

```typescript
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { createGroup } from '../api/client'
import type { OpaGroup } from '../types'
import { toast } from './useToast'

/** Shared "create in Okta, push into OPA" mutation used anywhere a group
 * picker offers a "New Group" affordance — group CRUD intentionally always
 * flows through Okta (see create_secret_folders.py's OPA_APP_CATALOG_NAME
 * comment), never OPA's own local-group endpoint.
 *
 * onCreated only fires once the group is confirmed visible in OPA (i.e.
 * push has propagated) — if it hasn't yet, the caller sees a toast telling
 * them to refresh shortly instead. */
export function useCreateGroup(onCreated: (group: OpaGroup) => void) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (vars: { name: string; description: string }) =>
      createGroup(vars.name.trim(), vars.description.trim()),
    onSuccess: (resp) => {
      queryClient.invalidateQueries({ queryKey: ['groups'] })
      if (resp.visible_in_opa && resp.group) {
        toast({ title: `Group '${resp.group.name}' created and pushed from Okta`, variant: 'success' })
        onCreated(resp.group)
      } else {
        toast({
          title: 'Created in Okta, still propagating',
          description: resp.message ?? 'Refresh the group list in a few seconds.',
          variant: 'default',
        })
      }
    },
    onError: (err: Error) => toast({ title: 'Could not create group', description: err.message, variant: 'error' }),
  })
}
```

---
## 15. `frontend/src/components/*.tsx` (part 1 of 3 — shared primitives)

### `ToastProvider.tsx`

```tsx
import * as Toast from '@radix-ui/react-toast'
import { X } from 'lucide-react'
import { useToastMessages, type ToastMessage } from '../hooks/useToast'

export function ToastProvider() {
  const { messages, dismiss } = useToastMessages()

  return (
    <Toast.Provider swipeDirection="right" duration={3500}>
      {messages.map(m => (
        <ToastItem key={m.id} message={m} onDismiss={() => dismiss(m.id)} />
      ))}
      <Toast.Viewport className="fixed bottom-4 right-4 flex flex-col gap-2 z-[9999] w-80 max-w-[calc(100vw-2rem)]" />
    </Toast.Provider>
  )
}

function ToastItem({ message: m, onDismiss }: { message: ToastMessage; onDismiss: () => void }) {
  const borderColor = m.variant === 'error' ? 'border-loss/40' : m.variant === 'success' ? 'border-win/40' : 'border-border'
  const titleColor  = m.variant === 'error' ? 'text-loss' : m.variant === 'success' ? 'text-win' : 'text-text'

  return (
    <Toast.Root
      open
      onOpenChange={open => { if (!open) onDismiss() }}
      className={`bg-bg-elevated border ${borderColor} rounded-lg shadow-xl px-4 py-3 flex items-start gap-3
        data-[state=open]:animate-[slide-in-from-right_0.2s_ease-out]
        data-[state=closed]:animate-[slide-out-to-right_0.15s_ease-in]`}
    >
      <div className="flex-1 min-w-0">
        <Toast.Title className={`text-sm font-medium ${titleColor}`}>{m.title}</Toast.Title>
        {m.description && (
          <Toast.Description className="text-xs text-text-faint mt-0.5">{m.description}</Toast.Description>
        )}
      </div>
      <Toast.Close asChild>
        <button className="text-text-faint hover:text-text-dim transition-colors shrink-0 mt-0.5">
          <X size={13} />
        </button>
      </Toast.Close>
    </Toast.Root>
  )
}
```

### `Select.tsx` — Radix Select wrapper used by every dropdown in the app

```tsx
import * as RadixSelect from '@radix-ui/react-select'
import { Check, ChevronDown } from 'lucide-react'

export interface SelectOption {
  value: string
  label: string
}

interface SelectProps {
  value?: string
  onValueChange: (value: string) => void
  options: SelectOption[]
  placeholder: string
  disabled?: boolean
  loading?: boolean
}

export function Select({ value, onValueChange, options, placeholder, disabled, loading }: SelectProps) {
  return (
    <RadixSelect.Root value={value} onValueChange={onValueChange} disabled={disabled || loading}>
      <RadixSelect.Trigger
        className="text-input inline-flex items-center justify-between gap-2 min-w-56 disabled:opacity-40 disabled:cursor-default"
      >
        <RadixSelect.Value placeholder={loading ? 'Loading…' : placeholder} />
        <RadixSelect.Icon>
          <ChevronDown size={14} className="text-text-faint" />
        </RadixSelect.Icon>
      </RadixSelect.Trigger>
      <RadixSelect.Portal>
        <RadixSelect.Content className="dropdown z-50" position="popper" sideOffset={4}>
          <RadixSelect.Viewport className="p-1 max-h-72">
            {options.length === 0 && (
              <div className="px-3 py-2 text-xs text-text-faint">No options</div>
            )}
            {options.map(opt => (
              <RadixSelect.Item
                key={opt.value}
                value={opt.value}
                className="text-sm text-text-dim rounded-md px-2 py-1.5 pl-7 relative cursor-pointer outline-none
                  data-[highlighted]:bg-bg-hover data-[highlighted]:text-text"
              >
                <RadixSelect.ItemIndicator className="absolute left-2 top-1/2 -translate-y-1/2">
                  <Check size={13} className="text-accent" />
                </RadixSelect.ItemIndicator>
                <RadixSelect.ItemText>{opt.label}</RadixSelect.ItemText>
              </RadixSelect.Item>
            ))}
          </RadixSelect.Viewport>
        </RadixSelect.Content>
      </RadixSelect.Portal>
    </RadixSelect.Root>
  )
}
```

### `StatusBadge.tsx`

```tsx
interface Props {
  label: string
  variant: 'neutral' | 'exists' | 'new' | 'created' | 'error'
}

const VARIANT_CLASSES: Record<Props['variant'], string> = {
  neutral: 'bg-bg-hover text-text-faint border-border',
  exists: 'bg-accent-dim text-accent border-accent/40',
  new: 'bg-bg-hover text-text-dim border-border',
  created: 'bg-win/10 text-win border-win/40',
  error: 'bg-loss/10 text-loss border-loss/40',
}

export function StatusBadge({ label, variant }: Props) {
  return (
    <span className={`text-[0.6875rem] font-medium px-1.5 py-0.5 rounded border ${VARIANT_CLASSES[variant]} whitespace-nowrap`}>
      {label}
    </span>
  )
}
```

### `TabBar.tsx`

```tsx
export interface Tab {
  value: string
  label: string
}

interface Props {
  tabs: Tab[]
  value: string
  onChange: (value: string) => void
}

export function TabBar({ tabs, value, onChange }: Props) {
  return (
    <div role="tablist" className="flex gap-1 border-b border-border">
      {tabs.map(tab => {
        const isActive = tab.value === value
        return (
          <button
            key={tab.value}
            type="button"
            role="tab"
            aria-selected={isActive}
            onClick={() => onChange(tab.value)}
            className={`px-3 py-2 text-sm font-medium border-b-2 -mb-px transition-colors ${
              isActive
                ? 'text-text border-accent'
                : 'text-text-faint border-transparent hover:text-text-dim'
            }`}
          >
            {tab.label}
          </button>
        )
      })}
    </div>
  )
}
```

### `KeyValueGrid.tsx` — renders every key of an object generically (new API fields show up automatically)

```tsx
import { displayValue, labelize } from '../utils/format'

interface Props {
  /** Rendered in insertion order — pass a pre-sorted/pre-filtered record. */
  data: Record<string, unknown>
}

/** Renders every key in `data` as a label/value pair. Used where the goal
 * is showing *everything* available about an object (e.g. a Project) —
 * new fields the API starts returning show up automatically. */
export function KeyValueGrid({ data }: Props) {
  const entries = Object.entries(data)
  return (
    <dl className="grid grid-cols-2 gap-x-4 gap-y-2">
      {entries.map(([key, value]) => (
        <div key={key} className="flex flex-col gap-0.5">
          <dt className="section-label">{labelize(key)}</dt>
          <dd className="text-sm text-text-dim break-words">{displayValue(value)}</dd>
        </div>
      ))}
    </dl>
  )
}
```

### `ExportButtons.tsx`

```tsx
import { Download } from 'lucide-react'
import type { ExportSection } from '../utils/export'
import { exportSections } from '../utils/export'

interface Props {
  sections: ExportSection[]
  filenameBase: string
}

export function ExportButtons({ sections, filenameBase }: Props) {
  const hasData = sections.some(s => s.rows.length > 0)
  return (
    <div className="flex items-center gap-1.5">
      <button
        type="button"
        className="btn-secondary !px-2 text-xs"
        disabled={!hasData}
        onClick={() => exportSections(sections, 'csv', filenameBase)}
        title="Export as CSV"
      >
        <Download size={12} /> CSV
      </button>
      <button
        type="button"
        className="btn-secondary !px-2 text-xs"
        disabled={!hasData}
        onClick={() => exportSections(sections, 'md', filenameBase)}
        title="Export as Markdown"
      >
        <Download size={12} /> MD
      </button>
    </div>
  )
}
```

### `AboutDialog.tsx`

```tsx
import * as Dialog from '@radix-ui/react-dialog'
import { Info, X } from 'lucide-react'

export function AboutDialog() {
  return (
    <Dialog.Root>
      <Dialog.Trigger asChild>
        <button type="button" className="btn-secondary !px-2" title="About / disclaimer">
          <Info size={14} />
        </button>
      </Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/60 z-40" />
        <Dialog.Content className="card fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[26rem] p-5">
          <div className="flex items-center justify-between mb-3">
            <Dialog.Title className="text-sm font-semibold text-text">About OPA Secrets Wizard</Dialog.Title>
            <Dialog.Close asChild>
              <button type="button" className="text-text-faint hover:text-text-dim">
                <X size={16} />
              </button>
            </Dialog.Close>
          </div>
          <div className="flex flex-col gap-3 text-xs text-text-dim leading-relaxed">
            <p>
              An unofficial, community tool for building and managing Okta Privileged
              Access (OPA) secret folders, resource groups, projects, groups, and
              security policies.
            </p>
            <div className="card p-3 bg-bg-hover border-warn text-text-dim">
              <p className="font-medium text-text mb-1">No warranty</p>
              <p>
                This tool is provided <strong>as-is, with no warranty of any kind</strong>,
                express or implied — including no warranty of merchantability, fitness
                for a particular purpose, or non-infringement. It makes real API calls
                that create, modify, and delete real objects in your OPA and Okta
                tenants. <strong>You are solely responsible for reviewing what it does
                before running it, especially against a production environment, and you
                assume all risk of using it.</strong> It is not an official Okta product
                and comes with no support commitment.
              </p>
            </div>
            <p className="text-text-faint">
              Licensed under MIT. Feedback and issues are welcome via the project's
              GitHub repository.
            </p>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
```

---
## 15. `frontend/src/components/*.tsx` (part 2 of 3 — Folder Builder tab)

### `CsvFileBar.tsx`

```tsx
import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Download, Save } from 'lucide-react'
import { fetchCsv, saveCsv } from '../api/client'
import { useCsvFiles } from '../api/hooks'
import { toast } from '../hooks/useToast'
import type { FolderNode } from '../types'
import { flattenTree, treeFromRows } from '../utils/tree'
import { Select } from './Select'

interface Props {
  nodes: FolderNode[]
  onLoad: (nodes: FolderNode[]) => void
}

export function CsvFileBar({ nodes, onLoad }: Props) {
  const { data: files } = useCsvFiles()
  const [loadFile, setLoadFile] = useState<string | undefined>(undefined)
  const [saveFile, setSaveFile] = useState('folders_template.csv')
  const queryClient = useQueryClient()

  const loadMutation = useMutation({
    mutationFn: (file: string) => fetchCsv(file),
    onSuccess: (data, file) => {
      onLoad(treeFromRows(data.rows))
      setSaveFile(file)
      toast({ title: `Loaded ${file}`, description: `${data.rows.length} row(s)`, variant: 'success' })
    },
    onError: (err: Error) => toast({ title: 'Load failed', description: err.message, variant: 'error' }),
  })

  const saveMutation = useMutation({
    mutationFn: () => saveCsv(saveFile, flattenTree(nodes)),
    onSuccess: (data) => {
      toast({ title: `Saved ${data.file}`, description: `${data.row_count} row(s)`, variant: 'success' })
      queryClient.invalidateQueries({ queryKey: ['csv_files'] })
    },
    onError: (err: Error) => toast({ title: 'Save failed', description: err.message, variant: 'error' }),
  })

  return (
    <div className="card p-3 flex flex-wrap items-end gap-4">
      <div className="flex flex-col gap-1">
        <span className="section-label">Load existing CSV</span>
        <div className="flex gap-2">
          <Select
            value={loadFile}
            onValueChange={setLoadFile}
            placeholder="Choose a file"
            options={(files ?? []).map(f => ({ value: f, label: f }))}
          />
          <button
            type="button"
            className="btn-secondary"
            disabled={!loadFile || loadMutation.isPending}
            onClick={() => loadFile && loadMutation.mutate(loadFile)}
          >
            <Download size={13} /> Load
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-1">
        <span className="section-label">Save tree to CSV</span>
        <div className="flex gap-2">
          <input
            value={saveFile}
            onChange={e => setSaveFile(e.target.value)}
            placeholder="filename.csv"
            className="text-input w-48"
          />
          <button
            type="button"
            className="btn-secondary"
            disabled={!saveFile.trim() || saveMutation.isPending}
            onClick={() => saveMutation.mutate()}
          >
            <Save size={13} /> Save
          </button>
        </div>
      </div>
    </div>
  )
}
```

### `ActionBar.tsx` — Preview (dry-run) / Create Folders (with confirm dialog)

```tsx
import { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import * as AlertDialog from '@radix-ui/react-alert-dialog'
import { Eye, FolderPlus } from 'lucide-react'
import { execute, preview } from '../api/client'
import { toast } from '../hooks/useToast'
import type { ExecuteResponse, FolderNode, PreviewResponse, Project, ResourceGroup } from '../types'
import { countNodes, flattenTree } from '../utils/tree'

interface Props {
  nodes: FolderNode[]
  resourceGroup: ResourceGroup | undefined
  project: Project | undefined
  onPreviewResult: (resp: PreviewResponse) => void
  onExecuteResult: (resp: ExecuteResponse) => void
}

export function ActionBar({ nodes, resourceGroup, project, onPreviewResult, onExecuteResult }: Props) {
  const [confirmOpen, setConfirmOpen] = useState(false)
  const ready = !!resourceGroup && !!project && nodes.length > 0

  const previewMutation = useMutation({
    mutationFn: () => preview(resourceGroup!.id, project!.id, flattenTree(nodes)),
    onSuccess: (resp) => {
      onPreviewResult(resp)
      toast({ title: 'Preview ready', description: `${resp.tree.length} folder(s) planned`, variant: 'default' })
    },
    onError: (err: Error) => toast({ title: 'Preview failed', description: err.message, variant: 'error' }),
  })

  const executeMutation = useMutation({
    mutationFn: () => execute(resourceGroup!.id, project!.id, flattenTree(nodes)),
    onSuccess: (resp) => {
      onExecuteResult(resp)
      const created = resp.results.filter(r => r.status === 'created').length
      const errors = resp.results.filter(r => r.status === 'error').length
      toast({
        title: 'Execute complete',
        description: `Created ${created}, errors ${errors}`,
        variant: errors > 0 ? 'error' : 'success',
      })
    },
    onError: (err: Error) => toast({ title: 'Execute failed', description: err.message, variant: 'error' }),
    onSettled: () => setConfirmOpen(false),
  })

  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        className="btn-secondary"
        disabled={!ready || previewMutation.isPending}
        onClick={() => previewMutation.mutate()}
      >
        <Eye size={13} /> {previewMutation.isPending ? 'Previewing…' : 'Preview (dry-run)'}
      </button>

      <AlertDialog.Root open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialog.Trigger asChild>
          <button type="button" className="btn-primary" disabled={!ready}>
            <FolderPlus size={13} /> Create Folders
          </button>
        </AlertDialog.Trigger>
        <AlertDialog.Portal>
          <AlertDialog.Overlay className="fixed inset-0 bg-black/60 z-40" />
          <AlertDialog.Content className="card fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-96 p-5">
            <AlertDialog.Title className="text-sm font-semibold text-text">Create folders in OPA?</AlertDialog.Title>
            <AlertDialog.Description className="text-xs text-text-faint mt-2 leading-relaxed">
              This will create up to <strong className="text-text-dim">{countNodes(nodes)}</strong> folder(s) in project{' '}
              <strong className="text-text-dim">{project?.name}</strong> under resource group{' '}
              <strong className="text-text-dim">{resourceGroup?.name}</strong>. Folders that already exist are skipped.
              This action calls the real OPA API and cannot be undone from this dashboard.
            </AlertDialog.Description>
            <div className="flex justify-end gap-2 mt-4">
              <AlertDialog.Cancel asChild>
                <button type="button" className="btn-secondary">Cancel</button>
              </AlertDialog.Cancel>
              <button
                type="button"
                className="btn-primary"
                disabled={executeMutation.isPending}
                onClick={() => executeMutation.mutate()}
              >
                {executeMutation.isPending ? 'Creating…' : 'Yes, create folders'}
              </button>
            </div>
          </AlertDialog.Content>
        </AlertDialog.Portal>
      </AlertDialog.Root>
    </div>
  )
}
```

### `ResultsPanel.tsx`

```tsx
import type { ExecuteResponse, PreviewResponse } from '../types'

interface Props {
  preview: PreviewResponse | null
  execute: ExecuteResponse | null
}

export function ResultsPanel({ preview, execute }: Props) {
  const collisions = execute?.collisions ?? preview?.collisions ?? {}
  const collisionEntries = Object.entries(collisions)
  const invalidNames = preview?.invalid_names ?? []

  if (collisionEntries.length === 0 && invalidNames.length === 0 && !execute) return null

  return (
    <div className="flex flex-col gap-2">
      {invalidNames.length > 0 && (
        <div className="card p-3 border-loss/40 text-xs text-loss">
          <div className="font-medium mb-1">Invalid folder name(s):</div>
          {invalidNames.map(n => (
            <div key={n.path}>"{n.name}" (from {n.path})</div>
          ))}
        </div>
      )}
      {collisionEntries.length > 0 && (
        <div className="card p-3 border-warn/40 text-xs text-warn">
          <div className="font-medium mb-1">Name collisions — OPA requires unique folder names per project:</div>
          {collisionEntries.map(([name, paths]) => (
            <div key={name}>"{name}" used at: {paths.join(', ')}</div>
          ))}
        </div>
      )}
      {execute && (
        <div className="card p-3 text-xs text-text-dim">
          Results written to <span className="text-accent">{execute.output_file}</span> ({execute.results.length} row(s))
        </div>
      )}
    </div>
  )
}
```

### `EnvironmentForm.tsx`

```tsx
import { useEffect, useState, type ChangeEvent } from 'react'
import type { Environment, EnvironmentFormValues } from '../types'

interface Props {
  initial?: Environment
  submitLabel: string
  onSubmit: (values: EnvironmentFormValues) => void
  isSubmitting: boolean
  errorMessage?: string
}

const EMPTY: EnvironmentFormValues = {
  name: '', base_domain: '', team_name: '', key_id: '', key_secret: '', okta_url: '', okta_api_token: '',
}

export function EnvironmentForm({ initial, submitLabel, onSubmit, isSubmitting, errorMessage }: Props) {
  const [values, setValues] = useState<EnvironmentFormValues>(
    initial ? { ...EMPTY, ...initial, key_secret: '', okta_api_token: '' } : EMPTY
  )

  useEffect(() => {
    setValues(initial ? { ...EMPTY, ...initial, key_secret: '', okta_api_token: '' } : EMPTY)
  }, [initial])

  const isEditing = !!initial
  const set = (field: keyof EnvironmentFormValues) => (e: ChangeEvent<HTMLInputElement>) =>
    setValues(v => ({ ...v, [field]: e.target.value }))

  const canSubmit = values.name.trim() && values.base_domain.trim() && values.team_name.trim() && values.key_id.trim()
    && (isEditing || values.key_secret.trim())

  return (
    <form
      className="flex flex-col gap-3"
      onSubmit={e => { e.preventDefault(); onSubmit(values) }}
    >
      <div className="flex flex-col gap-1">
        <span className="section-label">Label</span>
        <input
          value={values.name}
          onChange={set('name')}
          disabled={isEditing}
          placeholder="dev / uat / prod"
          className="text-input disabled:opacity-60"
        />
      </div>
      <div className="flex flex-col gap-1">
        <span className="section-label">Base Domain</span>
        <input
          value={values.base_domain}
          onChange={set('base_domain')}
          placeholder="yourorg.pam.okta.com"
          className="text-input"
        />
      </div>
      <div className="flex flex-col gap-1">
        <span className="section-label">Team Name</span>
        <input value={values.team_name} onChange={set('team_name')} placeholder="yourteam-pam" className="text-input" />
      </div>
      <div className="flex flex-col gap-1">
        <span className="section-label">Key ID</span>
        <input value={values.key_id} onChange={set('key_id')} placeholder="service user API key ID" className="text-input" />
      </div>
      <div className="flex flex-col gap-1">
        <span className="section-label">Key Secret</span>
        <input
          type="password"
          value={values.key_secret}
          onChange={set('key_secret')}
          placeholder={isEditing ? 'leave blank to keep existing' : 'service user API key secret'}
          className="text-input"
        />
      </div>

      <div className="border-t border-border-sub pt-3 mt-1">
        <span className="section-label">Okta (optional — only needed to create new groups)</span>
      </div>
      <div className="flex flex-col gap-1">
        <span className="section-label">Okta URL</span>
        <input
          value={values.okta_url}
          onChange={set('okta_url')}
          placeholder="https://yourorg.okta.com"
          className="text-input"
        />
      </div>
      <div className="flex flex-col gap-1">
        <span className="section-label">Okta API Token</span>
        <input
          type="password"
          value={values.okta_api_token}
          onChange={set('okta_api_token')}
          placeholder={isEditing ? 'leave blank to keep existing' : 'Okta API token'}
          className="text-input"
        />
      </div>

      {errorMessage && <div className="text-xs text-loss">{errorMessage}</div>}

      <button type="submit" className="btn-primary self-start" disabled={!canSubmit || isSubmitting}>
        {isSubmitting ? 'Connecting…' : submitLabel}
      </button>
    </form>
  )
}
```

### `EnvironmentSetup.tsx` — full-screen first-boot flow (no environment configured yet)

```tsx
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { saveEnvironment } from '../api/client'
import { toast } from '../hooks/useToast'
import type { ApiErrorBody, EnvironmentFormValues } from '../types'
import { EnvironmentForm } from './EnvironmentForm'

export function EnvironmentSetup() {
  const queryClient = useQueryClient()

  const mutation = useMutation({
    mutationFn: (values: EnvironmentFormValues) => saveEnvironment(values),
    onSuccess: (data) => {
      toast({ title: `Connected to '${data.active}'`, variant: 'success' })
      queryClient.invalidateQueries({ queryKey: ['environments'] })
    },
    onError: (err: Error) => toast({ title: 'Could not connect', description: err.message, variant: 'error' }),
  })

  const apiError = (mutation.error as (Error & { body?: ApiErrorBody }) | null)?.body?.error

  return (
    <div className="max-w-md mx-auto px-6 py-16 flex flex-col gap-5">
      <header>
        <h1 className="text-lg font-semibold text-text">Connect to Okta Privileged Access</h1>
        <p className="text-xs text-text-faint mt-1">
          No environment is configured yet. Enter your OPA service-user credentials to get started — you can add
          more environments (e.g. dev / uat / prod) later from the gear menu.
        </p>
      </header>
      <div className="card p-4">
        <EnvironmentForm
          submitLabel="Save & Connect"
          isSubmitting={mutation.isPending}
          errorMessage={apiError}
          onSubmit={values => mutation.mutate(values)}
        />
      </div>
    </div>
  )
}
```

### `EnvironmentManagerDialog.tsx` — gear-icon dialog: list/activate/edit/delete saved environments

```tsx
import { useState } from 'react'
import * as Dialog from '@radix-ui/react-dialog'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Pencil, Plus, Settings, Trash2, X } from 'lucide-react'
import { activateEnvironment, deleteEnvironment, saveEnvironment } from '../api/client'
import { toast } from '../hooks/useToast'
import type { ApiErrorBody, Environment, EnvironmentFormValues, EnvironmentsResponse } from '../types'
import { EnvironmentForm } from './EnvironmentForm'
import { StatusBadge } from './StatusBadge'

interface Props {
  data: EnvironmentsResponse | undefined
}

export function EnvironmentManagerDialog({ data }: Props) {
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Environment | 'new' | null>(null)
  const [confirmingDelete, setConfirmingDelete] = useState<string | null>(null)
  const queryClient = useQueryClient()

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: ['environments'] })
    queryClient.invalidateQueries({ queryKey: ['resource_groups'] })
  }

  const saveMutation = useMutation({
    mutationFn: (values: EnvironmentFormValues) => saveEnvironment(values),
    onSuccess: (resp) => {
      toast({ title: `Connected to '${resp.active}'`, variant: 'success' })
      setEditing(null)
      invalidateAll()
    },
    onError: (err: Error) => toast({ title: 'Could not connect', description: err.message, variant: 'error' }),
  })

  const activateMutation = useMutation({
    mutationFn: (name: string) => activateEnvironment(name),
    onSuccess: (resp) => {
      toast({ title: `Switched to '${resp.active}'`, variant: 'success' })
      invalidateAll()
    },
    onError: (err: Error) => toast({ title: 'Could not activate', description: err.message, variant: 'error' }),
  })

  const deleteMutation = useMutation({
    mutationFn: (name: string) => deleteEnvironment(name),
    onSuccess: (_resp, name) => {
      toast({ title: `Deleted '${name}'`, variant: 'default' })
      setConfirmingDelete(null)
      invalidateAll()
    },
    onError: (err: Error) => toast({ title: 'Could not delete', description: err.message, variant: 'error' }),
  })

  const saveApiError = (saveMutation.error as (Error & { body?: ApiErrorBody }) | null)?.body?.error

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <Dialog.Trigger asChild>
        <button type="button" className="btn-secondary !px-2" title="Manage environments">
          <Settings size={14} />
        </button>
      </Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/60 z-40" />
        <Dialog.Content className="card fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[30rem] max-h-[85vh] overflow-y-auto p-5">
          <div className="flex items-center justify-between mb-3">
            <Dialog.Title className="text-sm font-semibold text-text">Environments</Dialog.Title>
            <Dialog.Close asChild>
              <button type="button" className="text-text-faint hover:text-text-dim">
                <X size={16} />
              </button>
            </Dialog.Close>
          </div>

          <div className="flex flex-col gap-2 mb-4">
            {(data?.environments ?? []).length === 0 && (
              <div className="text-xs text-text-faint">No environments saved yet.</div>
            )}
            {(data?.environments ?? []).map(env => (
              <div key={env.name} className="card p-2.5 flex flex-col gap-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-text">{env.name}</span>
                  {data?.active === env.name && <StatusBadge label="active" variant="exists" />}
                  <div className="flex-1" />
                  {data?.active !== env.name && (
                    <button
                      type="button"
                      className="btn-secondary !py-0.5 !px-2 text-xs"
                      disabled={activateMutation.isPending}
                      onClick={() => activateMutation.mutate(env.name)}
                    >
                      Activate
                    </button>
                  )}
                  <button
                    type="button"
                    className="btn-secondary !px-1.5 !py-1"
                    title="Edit"
                    onClick={() => setEditing(env)}
                  >
                    <Pencil size={12} />
                  </button>
                  <button
                    type="button"
                    className="btn-secondary !px-1.5 !py-1 hover:!text-loss"
                    title="Delete"
                    onClick={() => setConfirmingDelete(env.name)}
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
                <div className="text-[0.6875rem] text-text-faint">
                  {env.base_domain} · team {env.team_name} · key {env.key_id.slice(0, 8)}…
                  {env.has_okta_token ? ' · Okta connected' : ' · no Okta token (can\'t create groups)'}
                </div>
                {confirmingDelete === env.name && (
                  <div className="flex items-center gap-2 text-xs text-loss">
                    Delete "{env.name}"?
                    <button
                      type="button"
                      className="btn-danger !py-0.5 !px-2"
                      disabled={deleteMutation.isPending}
                      onClick={() => deleteMutation.mutate(env.name)}
                    >
                      Yes, delete
                    </button>
                    <button type="button" className="btn-secondary !py-0.5 !px-2" onClick={() => setConfirmingDelete(null)}>
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>

          {editing === null ? (
            <button type="button" className="btn-secondary self-start" onClick={() => setEditing('new')}>
              <Plus size={13} /> Add environment
            </button>
          ) : (
            <div className="card p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="section-label">{editing === 'new' ? 'New environment' : `Edit '${editing.name}'`}</span>
                <button type="button" className="text-text-faint hover:text-text-dim" onClick={() => setEditing(null)}>
                  <X size={14} />
                </button>
              </div>
              <EnvironmentForm
                initial={editing === 'new' ? undefined : editing}
                submitLabel={editing === 'new' ? 'Save & Connect' : 'Save & Reconnect'}
                isSubmitting={saveMutation.isPending}
                errorMessage={saveApiError}
                onSubmit={values => saveMutation.mutate(values)}
              />
            </div>
          )}
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
```

### `GroupCreateForm.tsx` — presentational "create in Okta" form (shared by GroupPicker + AssignAccessDialog)

```tsx
import { useState } from 'react'
import type { UseMutationResult } from '@tanstack/react-query'
import type { CreateGroupResponse } from '../types'

interface Props {
  mutation: UseMutationResult<CreateGroupResponse, Error, { name: string; description: string }>
  onCancel: () => void
  label?: string
}

/** Presentational "create group in Okta" form shared by GroupPicker and
 * AssignAccessDialog. Owns its own name/description input state since
 * that's purely local UI state — the actual create logic lives in
 * useCreateGroup, which callers pass in as `mutation`. */
export function GroupCreateForm({ mutation, onCancel, label = 'New group (created in Okta, pushed into OPA)' }: Props) {
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')

  return (
    <div className="card p-3 flex flex-col gap-2">
      <span className="section-label">{label}</span>
      <input
        value={name}
        onChange={e => setName(e.target.value)}
        placeholder="group name"
        className="text-input"
      />
      <input
        value={description}
        onChange={e => setDescription(e.target.value)}
        placeholder="description (optional)"
        className="text-input"
      />
      <div className="flex gap-2">
        <button
          type="button"
          className="btn-primary"
          disabled={!name.trim() || mutation.isPending}
          onClick={() => mutation.mutate({ name, description })}
        >
          {mutation.isPending ? 'Creating…' : 'Create & Push'}
        </button>
        <button type="button" className="btn-secondary" onClick={onCancel} disabled={mutation.isPending}>
          Cancel
        </button>
      </div>
    </div>
  )
}
```

### `GroupPicker.tsx`

```tsx
import { useState } from 'react'
import { Plus, RefreshCw } from 'lucide-react'
import { useGroups } from '../api/hooks'
import { useCreateGroup } from '../hooks/useCreateGroup'
import { GroupCreateForm } from './GroupCreateForm'
import { Select } from './Select'

interface Props {
  value: string | undefined
  onChange: (groupId: string) => void
}

export function GroupPicker({ value, onChange }: Props) {
  const { data: groups, isLoading, refetch, isFetching } = useGroups()
  const [creating, setCreating] = useState(false)

  const createMutation = useCreateGroup(group => {
    onChange(group.id)
    setCreating(false)
  })

  if (creating) {
    return <GroupCreateForm mutation={createMutation} onCancel={() => setCreating(false)} />
  }

  return (
    <div className="flex flex-col gap-1">
      <span className="section-label">Group (required — grants access to the new resource group)</span>
      <div className="flex gap-2">
        <Select
          value={value}
          onValueChange={onChange}
          loading={isLoading}
          placeholder="Select a group"
          options={(groups ?? []).map(g => ({ value: g.id, label: g.name }))}
        />
        <button type="button" className="btn-secondary !px-2" title="Refresh groups" onClick={() => refetch()}>
          <RefreshCw size={13} className={isFetching ? 'animate-spin' : ''} />
        </button>
        <button type="button" className="btn-secondary" onClick={() => setCreating(true)}>
          <Plus size={13} /> New Group
        </button>
      </div>
    </div>
  )
}
```

### `ResourceGroupSelect.tsx`

```tsx
import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { createResourceGroup } from '../api/client'
import { useResourceGroups } from '../api/hooks'
import { toast } from '../hooks/useToast'
import { GroupPicker } from './GroupPicker'
import { Select } from './Select'

const NEW_SENTINEL = '__new__'

interface Props {
  value: string | undefined
  onChange: (id: string) => void
}

export function ResourceGroupSelect({ value, onChange }: Props) {
  const { data, isLoading, isError } = useResourceGroups()
  const [creating, setCreating] = useState(false)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [groupId, setGroupId] = useState<string | undefined>(undefined)
  const queryClient = useQueryClient()

  const createMutation = useMutation({
    mutationFn: () => createResourceGroup(name.trim(), description.trim(), groupId ? [groupId] : []),
    onSuccess: (resp) => {
      toast({ title: `Resource group '${resp.resource_group.name}' created`, variant: 'success' })
      queryClient.invalidateQueries({ queryKey: ['resource_groups'] })
      onChange(resp.resource_group.id)
      setCreating(false)
      setName('')
      setDescription('')
      setGroupId(undefined)
    },
    onError: (err: Error) => toast({ title: 'Could not create resource group', description: err.message, variant: 'error' }),
  })

  const handleSelect = (selected: string) => {
    if (selected === NEW_SENTINEL) {
      setCreating(true)
      return
    }
    onChange(selected)
  }

  if (creating) {
    return (
      <div className="card p-3 flex flex-col gap-2 min-w-72">
        <span className="section-label">New resource group</span>
        <input value={name} onChange={e => setName(e.target.value)} placeholder="resource group name" className="text-input" />
        <input
          value={description}
          onChange={e => setDescription(e.target.value)}
          placeholder="description (optional)"
          className="text-input"
        />
        <GroupPicker value={groupId} onChange={setGroupId} />
        <div className="flex gap-2">
          <button
            type="button"
            className="btn-primary"
            disabled={!name.trim() || !groupId || createMutation.isPending}
            onClick={() => createMutation.mutate()}
          >
            {createMutation.isPending ? 'Creating…' : 'Create'}
          </button>
          <button type="button" className="btn-secondary" onClick={() => setCreating(false)}>
            Cancel
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-1">
      <span className="section-label">Resource Group</span>
      <Select
        value={value}
        onValueChange={handleSelect}
        loading={isLoading}
        placeholder={isError ? 'Failed to load' : 'Select a resource group'}
        options={[
          ...(data ?? []).map(rg => ({ value: rg.id, label: rg.name })),
          { value: NEW_SENTINEL, label: '+ Create new resource group' },
        ]}
      />
    </div>
  )
}
```

### `ProjectSelect.tsx`

```tsx
import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { createProject } from '../api/client'
import { useProjects } from '../api/hooks'
import { toast } from '../hooks/useToast'
import { Select } from './Select'

const NEW_SENTINEL = '__new__'

interface Props {
  resourceGroupId: string | undefined
  value: string | undefined
  onChange: (id: string) => void
}

export function ProjectSelect({ resourceGroupId, value, onChange }: Props) {
  const { data, isLoading, isError } = useProjects(resourceGroupId)
  const [creating, setCreating] = useState(false)
  const [name, setName] = useState('')
  const queryClient = useQueryClient()

  const createMutation = useMutation({
    mutationFn: () => createProject(resourceGroupId!, name.trim()),
    onSuccess: (resp) => {
      toast({ title: `Project '${resp.project.name}' created`, variant: 'success' })
      queryClient.invalidateQueries({ queryKey: ['projects', resourceGroupId] })
      onChange(resp.project.id)
      setCreating(false)
      setName('')
    },
    onError: (err: Error) => toast({ title: 'Could not create project', description: err.message, variant: 'error' }),
  })

  const handleSelect = (selected: string) => {
    if (selected === NEW_SENTINEL) {
      setCreating(true)
      return
    }
    onChange(selected)
  }

  if (creating) {
    return (
      <div className="card p-3 flex flex-col gap-2 min-w-72">
        <span className="section-label">New project</span>
        <input value={name} onChange={e => setName(e.target.value)} placeholder="project name" className="text-input" />
        <div className="flex gap-2">
          <button
            type="button"
            className="btn-primary"
            disabled={!name.trim() || createMutation.isPending}
            onClick={() => createMutation.mutate()}
          >
            {createMutation.isPending ? 'Creating…' : 'Create'}
          </button>
          <button type="button" className="btn-secondary" onClick={() => setCreating(false)}>
            Cancel
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-1">
      <span className="section-label">Project</span>
      <Select
        value={value}
        onValueChange={handleSelect}
        loading={isLoading}
        disabled={!resourceGroupId}
        placeholder={
          !resourceGroupId ? 'Pick a resource group first' : isError ? 'Failed to load' : 'Select a project'
        }
        options={[
          ...(data ?? []).map(p => ({ value: p.id, label: p.name })),
          { value: NEW_SENTINEL, label: '+ Create new project' },
        ]}
      />
    </div>
  )
}
```

### `LoadExistingStructureButton.tsx`

```tsx
import { useState } from 'react'
import { Download } from 'lucide-react'
import { useLoadExistingFolders } from '../hooks/useLoadExistingFolders'
import { toast } from '../hooks/useToast'
import type { FolderNode } from '../types'

interface Props {
  resourceGroupId: string | undefined
  projectId: string | undefined
  hasUnsavedNodes: boolean
  onLoad: (nodes: FolderNode[], folderIdByPath: Map<string, string>) => void
}

export function LoadExistingStructureButton({ resourceGroupId, projectId, hasUnsavedNodes, onLoad }: Props) {
  const [confirming, setConfirming] = useState(false)

  const loadMutation = useLoadExistingFolders((nodes, folderIdByPath) => {
    setConfirming(false)
    if (nodes.length === 0) {
      toast({ title: 'No existing folders found in this project', variant: 'default' })
    } else {
      toast({
        title: 'Loaded existing folder(s) from this project',
        description: 'OPA only exposes a flat list (no parent/child info) — these appear as root-level; add subfolders under them as needed.',
        variant: 'success',
      })
    }
    onLoad(nodes, folderIdByPath)
  })

  const disabled = !resourceGroupId || !projectId || loadMutation.isPending

  const doLoad = () =>
    loadMutation.mutate(
      { resourceGroupId: resourceGroupId!, projectId: projectId! },
      { onError: (err: Error) => toast({ title: 'Could not load existing structure', description: err.message, variant: 'error' }) }
    )

  const handleClick = () => {
    if (hasUnsavedNodes && !confirming) {
      setConfirming(true)
      return
    }
    doLoad()
  }

  if (confirming) {
    return (
      <div className="flex items-center gap-2 text-xs text-warn">
        Replace the current tree with what's already in this project?
        <button type="button" className="btn-primary !py-0.5 !px-2" onClick={doLoad}>
          Yes, load it
        </button>
        <button type="button" className="btn-secondary !py-0.5 !px-2" onClick={() => setConfirming(false)}>
          Cancel
        </button>
      </div>
    )
  }

  return (
    <button type="button" className="btn-secondary" disabled={disabled} onClick={handleClick}>
      <Download size={13} /> {loadMutation.isPending ? 'Loading…' : 'Load Current Structure'}
    </button>
  )
}
```

### `FolderAccessBadge.tsx`

```tsx
import { Lock } from 'lucide-react'
import type { FolderAccessEntry } from '../types'

interface Props {
  entries: FolderAccessEntry[] | undefined
  /** True until the folder has a real OPA ID (not yet created, or the
   * tree was edited since the last Load/Preview/Execute). */
  disabled: boolean
  onClick: () => void
}

export function FolderAccessBadge({ entries, disabled, onClick }: Props) {
  if (disabled) {
    return <span className="text-[0.6875rem] text-text-faint">—</span>
  }

  const groupNames = [...new Set((entries ?? []).flatMap(e => e.groups.map(g => g.name)))]
  const label =
    entries && entries.length > 0
      ? `${entries.length} polic${entries.length === 1 ? 'y' : 'ies'}${groupNames.length ? ` · ${groupNames.slice(0, 2).join(', ')}${groupNames.length > 2 ? '…' : ''}` : ''}`
      : 'No policy'

  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center gap-1 text-[0.6875rem] text-text-faint hover:text-text-dim transition-colors whitespace-nowrap"
      title="Assign access"
    >
      <Lock size={11} />
      {label}
    </button>
  )
}
```

### `FolderNodeRow.tsx` — recursive tree row (name/description inputs, delete-with-confirm, access badge)

```tsx
import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Plus, Trash2 } from 'lucide-react'
import { deleteFolder } from '../api/client'
import { toast } from '../hooks/useToast'
import type { FolderAccessEntry, FolderNode } from '../types'
import { isValidName } from '../utils/validate'
import { FolderAccessBadge } from './FolderAccessBadge'
import { StatusBadge } from './StatusBadge'

export interface StatusInfo {
  label: string
  variant: 'neutral' | 'exists' | 'new' | 'created' | 'error'
  errorMessage?: string
}

interface Props {
  node: FolderNode
  parentPath: string[]
  statusByPath: Map<string, StatusInfo>
  collisionNames: Set<string>
  folderIdByPath: Map<string, string>
  accessByPath: Map<string, FolderAccessEntry[]>
  resourceGroupId: string | undefined
  projectId: string | undefined
  onAddChild: (parentId: string) => void
  onDelete: (id: string) => void
  onUpdate: (id: string, patch: Partial<Pick<FolderNode, 'name' | 'description'>>) => void
  onAssignAccess: (path: string, folderId: string, folderName: string) => void
}

export function FolderNodeRow({
  node,
  parentPath,
  statusByPath,
  collisionNames,
  folderIdByPath,
  accessByPath,
  resourceGroupId,
  projectId,
  onAddChild,
  onDelete,
  onUpdate,
  onAssignAccess,
}: Props) {
  const [confirmingDelete, setConfirmingDelete] = useState(false)
  const queryClient = useQueryClient()
  const fullPath = [...parentPath, node.name]
  const fullPathKey = fullPath.join('/')
  const status = statusByPath.get(fullPathKey)
  const nameInvalid = node.name.length > 0 && !isValidName(node.name)
  const hasCollision = collisionNames.has(node.name)
  const folderId = folderIdByPath.get(fullPathKey)

  const deleteMutation = useMutation({
    mutationFn: () => deleteFolder(resourceGroupId!, projectId!, folderId!),
    onSuccess: () => {
      toast({ title: `Deleted "${node.name}" from OPA`, variant: 'default' })
      setConfirmingDelete(false)
      queryClient.invalidateQueries({ queryKey: ['security_policies', resourceGroupId] })
      onDelete(node.id)
    },
    onError: (err: Error) => {
      toast({ title: `Could not delete "${node.name}"`, description: err.message, variant: 'error' })
      setConfirmingDelete(false)
    },
  })

  const handleDeleteClick = () => {
    if (!folderId) {
      // Never created in OPA yet — just remove it from the local tree.
      onDelete(node.id)
      return
    }
    setConfirmingDelete(true)
  }

  return (
    <div className="flex flex-col">
      <div className="flex items-center gap-2 py-1" style={{ paddingLeft: `${parentPath.length * 1.5}rem` }}>
        <input
          value={node.name}
          onChange={e => onUpdate(node.id, { name: e.target.value })}
          placeholder="folder-name"
          className={`text-input w-40 ${nameInvalid ? 'border-loss' : hasCollision ? 'border-warn' : ''}`}
        />
        <input
          value={node.description}
          onChange={e => onUpdate(node.id, { description: e.target.value })}
          placeholder="description (optional)"
          className="text-input flex-1 min-w-0"
        />
        {status && <StatusBadge label={status.label} variant={status.variant} />}
        <FolderAccessBadge
          entries={accessByPath.get(fullPathKey)}
          disabled={!folderId}
          onClick={() => folderId && onAssignAccess(fullPathKey, folderId, node.name)}
        />
        <button
          type="button"
          onClick={() => onAddChild(node.id)}
          title="Add subfolder"
          className="btn-secondary !px-1.5 !py-1"
        >
          <Plus size={13} />
        </button>
        <button
          type="button"
          onClick={handleDeleteClick}
          title={folderId ? 'Delete from OPA' : 'Remove'}
          className="btn-secondary !px-1.5 !py-1 hover:!text-loss"
        >
          <Trash2 size={13} />
        </button>
      </div>

      {confirmingDelete && (
        <div
          className="flex items-center gap-2 text-xs text-loss py-1"
          style={{ paddingLeft: `${parentPath.length * 1.5 + 0.25}rem` }}
        >
          Delete "{node.name}" from OPA? This can't be undone.
          <button
            type="button"
            className="btn-danger !py-0.5 !px-2"
            disabled={deleteMutation.isPending}
            onClick={() => deleteMutation.mutate()}
          >
            {deleteMutation.isPending ? 'Deleting…' : 'Yes, delete'}
          </button>
          <button
            type="button"
            className="btn-secondary !py-0.5 !px-2"
            disabled={deleteMutation.isPending}
            onClick={() => setConfirmingDelete(false)}
          >
            Cancel
          </button>
        </div>
      )}

      {nameInvalid && (
        <div className="text-[0.6875rem] text-loss" style={{ paddingLeft: `${parentPath.length * 1.5 + 0.25}rem` }}>
          Only letters, digits, "." "_" "-" are allowed — no spaces.
        </div>
      )}
      {!nameInvalid && hasCollision && (
        <div className="text-[0.6875rem] text-warn" style={{ paddingLeft: `${parentPath.length * 1.5 + 0.25}rem` }}>
          "{node.name}" is used elsewhere in this tree — OPA requires unique names per project.
        </div>
      )}
      {status?.variant === 'error' && status.errorMessage && (
        <div className="text-[0.6875rem] text-loss" style={{ paddingLeft: `${parentPath.length * 1.5 + 0.25}rem` }}>
          {status.errorMessage}
        </div>
      )}

      {node.children.map(child => (
        <FolderNodeRow
          key={child.id}
          node={child}
          parentPath={fullPath}
          statusByPath={statusByPath}
          collisionNames={collisionNames}
          folderIdByPath={folderIdByPath}
          accessByPath={accessByPath}
          resourceGroupId={resourceGroupId}
          projectId={projectId}
          onAddChild={onAddChild}
          onDelete={onDelete}
          onUpdate={onUpdate}
          onAssignAccess={onAssignAccess}
        />
      ))}
    </div>
  )
}
```

### `FolderTree.tsx`

```tsx
import { Plus } from 'lucide-react'
import type { FolderAccessEntry, FolderNode } from '../types'
import { addChild, newNode, removeNode, updateNode } from '../utils/tree'
import { FolderNodeRow, type StatusInfo } from './FolderNodeRow'

interface Props {
  nodes: FolderNode[]
  onChange: (nodes: FolderNode[]) => void
  statusByPath: Map<string, StatusInfo>
  collisionNames: Set<string>
  folderIdByPath: Map<string, string>
  accessByPath: Map<string, FolderAccessEntry[]>
  resourceGroupId: string | undefined
  projectId: string | undefined
  onAssignAccess: (path: string, folderId: string, folderName: string) => void
}

export function FolderTree({
  nodes,
  onChange,
  statusByPath,
  collisionNames,
  folderIdByPath,
  accessByPath,
  resourceGroupId,
  projectId,
  onAssignAccess,
}: Props) {
  const handleAddRoot = () => onChange(addChild(nodes, null, newNode()))
  const handleAddChild = (parentId: string) => onChange(addChild(nodes, parentId, newNode()))
  const handleDelete = (id: string) => onChange(removeNode(nodes, id))
  const handleUpdate = (id: string, patch: Partial<Pick<FolderNode, 'name' | 'description'>>) =>
    onChange(updateNode(nodes, id, patch))

  return (
    <div className="card p-3 flex flex-col gap-1">
      {nodes.length === 0 && (
        <div className="text-sm text-text-faint py-6 text-center">No folders yet — add a root folder to start.</div>
      )}
      {nodes.map(node => (
        <FolderNodeRow
          key={node.id}
          node={node}
          parentPath={[]}
          statusByPath={statusByPath}
          collisionNames={collisionNames}
          folderIdByPath={folderIdByPath}
          accessByPath={accessByPath}
          resourceGroupId={resourceGroupId}
          projectId={projectId}
          onAddChild={handleAddChild}
          onDelete={handleDelete}
          onUpdate={handleUpdate}
          onAssignAccess={onAssignAccess}
        />
      ))}
      <button type="button" onClick={handleAddRoot} className="btn-secondary self-start mt-2">
        <Plus size={13} /> Add root folder
      </button>
    </div>
  )
}
```

### `AssignAccessDialog.tsx` — attach a secret_folder security-policy rule to a real OPA folder

```tsx
import { useMemo, useState } from 'react'
import * as Dialog from '@radix-ui/react-dialog'
import { useMutation } from '@tanstack/react-query'
import { AlertTriangle, Plus, X } from 'lucide-react'
import { assignFolderPolicy } from '../api/client'
import { useGroups, useResourceGroupSecurityPolicies, useWorkloadRoles } from '../api/hooks'
import { useCreateGroup } from '../hooks/useCreateGroup'
import { toast } from '../hooks/useToast'
import type { ApiErrorBody, FolderSecurityPolicy, NamedRef } from '../types'
import { GroupCreateForm } from './GroupCreateForm'
import { Select } from './Select'

const PRIVILEGE_GROUPS: { label: string; fields: { key: string; label: string }[] }[] = [
  { label: 'Access', fields: [{ key: 'list', label: 'List contents' }] },
  {
    label: 'Secrets',
    fields: [
      { key: 'secret_create', label: 'Create' },
      { key: 'secret_update', label: 'Update' },
      { key: 'secret_delete', label: 'Delete' },
      { key: 'secret_reveal', label: 'Reveal' },
    ],
  },
  {
    label: 'Folders',
    fields: [
      { key: 'folder_create', label: 'Create' },
      { key: 'folder_update', label: 'Update' },
      { key: 'folder_delete', label: 'Delete' },
    ],
  },
]

function MultiSelect({
  options,
  selectedIds,
  onToggle,
  emptyText,
}: {
  options: NamedRef[]
  selectedIds: Set<string>
  onToggle: (id: string) => void
  emptyText: string
}) {
  return (
    <div className="border border-border rounded-md max-h-32 overflow-y-auto p-1.5 flex flex-col gap-0.5">
      {options.length === 0 && <span className="text-xs text-text-faint px-1 py-1">{emptyText}</span>}
      {options.map(opt => (
        <label key={opt.id} className="flex items-center gap-2 text-sm text-text-dim px-1 py-0.5 rounded hover:bg-bg-hover cursor-pointer">
          <input type="checkbox" checked={selectedIds.has(opt.id)} onChange={() => onToggle(opt.id)} />
          {opt.name}
        </label>
      ))}
    </div>
  )
}

interface Props {
  open: boolean
  onOpenChange: (open: boolean) => void
  resourceGroupId: string
  projectId: string
  folderId: string
  folderName: string
  onSaved: (policy: FolderSecurityPolicy) => void
}

export function AssignAccessDialog({ open, onOpenChange, resourceGroupId, projectId, folderId, folderName, onSaved }: Props) {
  const [mode, setMode] = useState<'existing' | 'new'>('existing')
  const [policyId, setPolicyId] = useState<string | undefined>(undefined)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [groupIds, setGroupIds] = useState<Set<string>>(new Set())
  const [creatingGroup, setCreatingGroup] = useState(false)
  const [workloadRoleIds, setWorkloadRoleIds] = useState<Set<string>>(new Set())
  const [privileges, setPrivileges] = useState<Record<string, boolean>>({})
  const [requireMfa, setRequireMfa] = useState(false)
  const [mfaReauthSeconds, setMfaReauthSeconds] = useState(1800)
  const [mfaAcrValues, setMfaAcrValues] = useState('urn:okta:loa:2fa:any')

  const { data: policies } = useResourceGroupSecurityPolicies(resourceGroupId, open)
  const { data: allGroups } = useGroups(open)
  const { data: workloadRoles } = useWorkloadRoles(open)
  const groups = (allGroups ?? []).filter(g => g.name !== 'everyone')

  const selectedPolicy = policies?.find(p => p.id === policyId)

  const toggleGroup = (id: string) =>
    setGroupIds(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  const toggleWorkloadRole = (id: string) =>
    setWorkloadRoleIds(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  const togglePrivilege = (key: string) => setPrivileges(prev => ({ ...prev, [key]: !prev[key] }))

  const createGroupMutation = useCreateGroup(group => {
    setGroupIds(prev => new Set(prev).add(group.id))
    setCreatingGroup(false)
  })

  // Blast-radius warning: principals apply to the WHOLE policy, so adding
  // a group/role that isn't already a principal grants it every other
  // rule already in that policy too — not just this folder.
  const blastRadius = useMemo(() => {
    if (mode !== 'existing' || !selectedPolicy) return null
    const existingGroupIds = new Set(selectedPolicy.principals.user_groups.map(g => g.id))
    const existingRoleIds = new Set(selectedPolicy.principals.workload_roles.map(r => r.id))
    const newGroups = [...groupIds].filter(id => !existingGroupIds.has(id))
    const newRoles = [...workloadRoleIds].filter(id => !existingRoleIds.has(id))
    if (newGroups.length === 0 && newRoles.length === 0) return null
    const otherRules = selectedPolicy.rules.filter(
      r => !r.targets.some(t => t.kind === 'resolved' && t.id === folderId)
    )
    if (otherRules.length === 0) return null
    return { newGroupNames: groups.filter(g => newGroups.includes(g.id)).map(g => g.name), otherRuleCount: otherRules.length }
  }, [mode, selectedPolicy, groupIds, workloadRoleIds, folderId, groups])

  const mutation = useMutation({
    mutationFn: () => {
      const group_refs: NamedRef[] = groups.filter(g => groupIds.has(g.id)).map(g => ({ id: g.id, name: g.name }))
      const workload_role_refs: NamedRef[] = (workloadRoles ?? [])
        .filter(w => workloadRoleIds.has(w.id))
        .map(w => ({ id: w.id, name: w.name }))
      return assignFolderPolicy(resourceGroupId, projectId, folderId, {
        mode,
        policy_id: mode === 'existing' ? policyId : undefined,
        name: mode === 'new' ? name.trim() : undefined,
        description: mode === 'new' ? description.trim() : undefined,
        folder_name: folderName,
        group_refs,
        workload_role_refs,
        privileges,
        mfa: requireMfa ? { reauth_seconds: mfaReauthSeconds, acr_values: mfaAcrValues } : null,
      })
    },
    onSuccess: (resp) => {
      toast({ title: `Access saved for '${folderName}'`, variant: 'success' })
      onSaved(resp.policy)
      onOpenChange(false)
    },
    onError: (err: Error & { body?: ApiErrorBody }) =>
      toast({ title: 'Could not save access', description: err.body?.error ?? err.message, variant: 'error' }),
  })

  const canSave =
    (mode === 'existing' ? !!policyId : name.trim().length > 0) &&
    (groupIds.size > 0 || workloadRoleIds.size > 0) &&
    Object.values(privileges).some(Boolean)

  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/60 z-40" />
        <Dialog.Content className="card fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[34rem] max-h-[85vh] overflow-y-auto p-5">
          <div className="flex items-center justify-between mb-3">
            <Dialog.Title className="text-sm font-semibold text-text">Assign access — {folderName}</Dialog.Title>
            <Dialog.Close asChild>
              <button type="button" className="text-text-faint hover:text-text-dim">
                <X size={16} />
              </button>
            </Dialog.Close>
          </div>

          <div className="flex flex-col gap-4">
            <div className="flex gap-4">
              <label className="flex items-center gap-1.5 text-sm text-text-dim cursor-pointer">
                <input type="radio" checked={mode === 'existing'} onChange={() => setMode('existing')} />
                Use existing policy
              </label>
              <label className="flex items-center gap-1.5 text-sm text-text-dim cursor-pointer">
                <input type="radio" checked={mode === 'new'} onChange={() => setMode('new')} />
                Create new policy
              </label>
            </div>

            {mode === 'existing' ? (
              <div className="flex flex-col gap-1">
                <span className="section-label">Policy (scoped to this resource group)</span>
                <Select
                  value={policyId}
                  onValueChange={setPolicyId}
                  placeholder="Select a policy"
                  options={(policies ?? []).map(p => ({ value: p.id, label: p.name }))}
                />
              </div>
            ) : (
              <>
                <div className="flex flex-col gap-1">
                  <span className="section-label">Name</span>
                  <input value={name} onChange={e => setName(e.target.value)} className="text-input" placeholder="Policy name" />
                </div>
                <div className="flex flex-col gap-1">
                  <span className="section-label">Description (optional)</span>
                  <input value={description} onChange={e => setDescription(e.target.value)} className="text-input" />
                </div>
              </>
            )}

            <div className="flex flex-col gap-1">
              <div className="flex items-center justify-between">
                <span className="section-label">Group(s)</span>
                {!creatingGroup && (
                  <button type="button" className="btn-secondary !py-0.5 !px-2 text-xs" onClick={() => setCreatingGroup(true)}>
                    <Plus size={12} /> New Group
                  </button>
                )}
              </div>
              <MultiSelect options={groups} selectedIds={groupIds} onToggle={toggleGroup} emptyText="No groups found" />
              {creatingGroup && (
                <GroupCreateForm mutation={createGroupMutation} onCancel={() => setCreatingGroup(false)} />
              )}
            </div>

            <div className="flex flex-col gap-1">
              <span className="section-label">Workload role(s) (service identities, optional)</span>
              <MultiSelect
                options={workloadRoles ?? []}
                selectedIds={workloadRoleIds}
                onToggle={toggleWorkloadRole}
                emptyText="No workload roles defined for this team"
              />
            </div>

            {blastRadius && (
              <div className="flex items-start gap-2 text-xs text-warn bg-warn/10 border border-warn/40 rounded-md p-2">
                <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                <span>
                  {blastRadius.newGroupNames.join(', ')} {blastRadius.newGroupNames.length === 1 ? 'is' : 'are'} not
                  currently a principal on this policy. Adding {blastRadius.newGroupNames.length === 1 ? 'it' : 'them'}{' '}
                  will also grant access to {blastRadius.otherRuleCount} other rule
                  {blastRadius.otherRuleCount === 1 ? '' : 's'} already in this policy — principals apply policy-wide,
                  not per-rule.
                </span>
              </div>
            )}

            <div className="flex flex-col gap-2">
              <span className="section-label">Privileges</span>
              {PRIVILEGE_GROUPS.map(group => (
                <div key={group.label} className="flex flex-col gap-1">
                  <span className="text-xs text-text-faint">{group.label}</span>
                  <div className="flex flex-wrap gap-3">
                    {group.fields.map(f => (
                      <label key={f.key} className="flex items-center gap-1.5 text-sm text-text-dim cursor-pointer">
                        <input type="checkbox" checked={!!privileges[f.key]} onChange={() => togglePrivilege(f.key)} />
                        {f.label}
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-col gap-2">
              <label className="flex items-center gap-1.5 text-sm text-text-dim cursor-pointer">
                <input type="checkbox" checked={requireMfa} onChange={e => setRequireMfa(e.target.checked)} />
                Require MFA
              </label>
              {requireMfa && (
                <div className="flex gap-3 pl-6">
                  <div className="flex flex-col gap-1">
                    <span className="text-xs text-text-faint">Re-auth every (seconds, 0 = once per session)</span>
                    <input
                      type="number"
                      min={0}
                      value={mfaReauthSeconds}
                      onChange={e => setMfaReauthSeconds(Number(e.target.value))}
                      className="text-input w-32"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-xs text-text-faint">ACR values</span>
                    <input value={mfaAcrValues} onChange={e => setMfaAcrValues(e.target.value)} className="text-input" />
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 mt-2">
              <Dialog.Close asChild>
                <button type="button" className="btn-secondary">
                  Cancel
                </button>
              </Dialog.Close>
              <button type="button" className="btn-primary" disabled={!canSave || mutation.isPending} onClick={() => mutation.mutate()}>
                {mutation.isPending ? 'Saving…' : 'Save'}
              </button>
            </div>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
```

### `FolderBuilder.tsx` — top-level Folder Builder tab, wires all of the above together

```tsx
import { useMemo, useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { useResourceGroups, useProjects, useResourceGroupSecurityPolicies } from '../api/hooks'
import { resolveFolderAccess } from '../utils/folderAccess'
import { ActionBar } from './ActionBar'
import { AssignAccessDialog } from './AssignAccessDialog'
import { CsvFileBar } from './CsvFileBar'
import { FolderTree } from './FolderTree'
import type { StatusInfo } from './FolderNodeRow'
import { LoadExistingStructureButton } from './LoadExistingStructureButton'
import { ResourceGroupSelect } from './ResourceGroupSelect'
import { ProjectSelect } from './ProjectSelect'
import { ResultsPanel } from './ResultsPanel'
import type { ExecuteResponse, FolderNode, PreviewResponse } from '../types'

export function FolderBuilder() {
  const [resourceGroupId, setResourceGroupId] = useState<string | undefined>(undefined)
  const [projectId, setProjectId] = useState<string | undefined>(undefined)
  const [nodes, setNodes] = useState<FolderNode[]>([])
  const [previewResp, setPreviewResp] = useState<PreviewResponse | null>(null)
  const [executeResp, setExecuteResp] = useState<ExecuteResponse | null>(null)
  // Real OPA folder IDs are the one thing this component tracks by path
  // rather than storing on FolderNode itself -- an edit can shift what a
  // path even refers to, so any tree edit clears this and requires a
  // fresh Load/Preview/Execute before "Assign access" is offered again
  // for that folder. Preview/Execute results (merged in below) always
  // win over a stale load, since they're more recent.
  const [loadedFolderIds, setLoadedFolderIds] = useState<Map<string, string>>(new Map())
  const [assigning, setAssigning] = useState<{ path: string; folderId: string; folderName: string } | null>(null)

  const queryClient = useQueryClient()
  const { data: resourceGroups } = useResourceGroups(true)
  const { data: projects } = useProjects(resourceGroupId, true)
  const { data: securityPolicies } = useResourceGroupSecurityPolicies(resourceGroupId, true)

  const resourceGroup = resourceGroups?.find(rg => rg.id === resourceGroupId)
  const project = projects?.find(p => p.id === projectId)

  const clearResults = () => { setPreviewResp(null); setExecuteResp(null) }

  const handleNodesChange = (next: FolderNode[]) => { setNodes(next); clearResults(); setLoadedFolderIds(new Map()) }
  const handleLoadExisting = (next: FolderNode[], folderIdByPath: Map<string, string>) => {
    setNodes(next)
    clearResults()
    setLoadedFolderIds(folderIdByPath)
  }
  const handleResourceGroupChange = (id: string) => { setResourceGroupId(id); setProjectId(undefined); clearResults() }
  const handleProjectChange = (id: string) => { setProjectId(id); clearResults() }

  const folderIdByPath = useMemo(() => {
    const map = new Map(loadedFolderIds)
    if (previewResp) {
      for (const t of previewResp.tree) if (t.folder_id) map.set(t.path, t.folder_id)
    }
    if (executeResp) {
      for (const r of executeResp.results) if (r.folder_id) map.set(r.path, r.folder_id)
    }
    return map
  }, [loadedFolderIds, previewResp, executeResp])

  const statusByPath = useMemo(() => {
    const map = new Map<string, StatusInfo>()
    if (executeResp) {
      for (const r of executeResp.results) {
        if (r.status === 'created') map.set(r.path, { label: 'created', variant: 'created' })
        else if (r.status === 'skipped_exists') map.set(r.path, { label: 'exists', variant: 'exists' })
        else map.set(r.path, { label: 'error', variant: 'error', errorMessage: r.error_message })
      }
    } else if (previewResp) {
      for (const t of previewResp.tree) {
        map.set(t.path, t.exists ? { label: 'exists', variant: 'exists' } : { label: 'will create', variant: 'new' })
      }
    }
    return map
  }, [previewResp, executeResp])

  const collisionNames = useMemo(() => {
    const source = executeResp?.collisions ?? previewResp?.collisions ?? {}
    return new Set(Object.keys(source))
  }, [previewResp, executeResp])

  const accessByPath = useMemo(
    () => resolveFolderAccess(securityPolicies ?? [], folderIdByPath),
    [securityPolicies, folderIdByPath]
  )

  const handleAssignAccess = (path: string, folderId: string, folderName: string) =>
    setAssigning({ path, folderId, folderName })

  const handleAccessSaved = () => {
    queryClient.invalidateQueries({ queryKey: ['security_policies', resourceGroupId] })
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="card p-3 flex flex-wrap items-end gap-4">
        <ResourceGroupSelect value={resourceGroupId} onChange={handleResourceGroupChange} />
        <ProjectSelect resourceGroupId={resourceGroupId} value={projectId} onChange={handleProjectChange} />
        <LoadExistingStructureButton
          resourceGroupId={resourceGroupId}
          projectId={projectId}
          hasUnsavedNodes={nodes.length > 0}
          onLoad={handleLoadExisting}
        />
      </div>

      <CsvFileBar nodes={nodes} onLoad={handleNodesChange} />

      <FolderTree
        nodes={nodes}
        onChange={handleNodesChange}
        statusByPath={statusByPath}
        collisionNames={collisionNames}
        folderIdByPath={folderIdByPath}
        accessByPath={accessByPath}
        resourceGroupId={resourceGroupId}
        projectId={projectId}
        onAssignAccess={handleAssignAccess}
      />

      <ResultsPanel preview={previewResp} execute={executeResp} />

      <ActionBar
        nodes={nodes}
        resourceGroup={resourceGroup}
        project={project}
        onPreviewResult={setPreviewResp}
        onExecuteResult={setExecuteResp}
      />

      {assigning && resourceGroupId && projectId && (
        <AssignAccessDialog
          open
          onOpenChange={open => !open && setAssigning(null)}
          resourceGroupId={resourceGroupId}
          projectId={projectId}
          folderId={assigning.folderId}
          folderName={assigning.folderName}
          onSaved={handleAccessSaved}
        />
      )}
    </div>
  )
}
```

---
## 15. `frontend/src/components/*.tsx` (part 3 of 3 — Access Explorer tab)

### `BootstrapProgressPanel.tsx` — real step-by-step progress for the (slow) Access Explorer bootstrap job

```tsx
import { Check, CircleDashed, Loader2, X } from 'lucide-react'
import type { BootstrapStepEvent } from '../api/client'
import type { JobPhase } from '../hooks/useAccessBootstrapJob'

interface StepDisplay {
  key: string
  label: string
  status: 'pending' | 'active' | 'done' | 'error'
  detail?: string
}

/** Steps run strictly in order, so at most one step is ever "started but
 * not done" at a time — when the job errors, that's the one that failed;
 * everything after it never started. */
function deriveSteps(stepDefs: [string, string][], events: BootstrapStepEvent[], phase: JobPhase): StepDisplay[] {
  return stepDefs.map(([key, label]) => {
    const keyEvents = events.filter(e => e.key === key)
    const doneEvent = keyEvents.find(e => e.status === 'done')
    if (doneEvent) return { key, label, status: 'done', detail: doneEvent.detail ?? undefined }

    const started = keyEvents.some(e => e.status === 'start')
    if (started) {
      const latest = [...keyEvents].reverse()[0]
      if (phase === 'error') return { key, label, status: 'error', detail: latest.detail ?? undefined }
      return { key, label, status: 'active', detail: latest.detail ?? undefined }
    }
    return { key, label, status: 'pending' }
  })
}

function StepIcon({ status }: { status: StepDisplay['status'] }) {
  if (status === 'done') return <Check size={14} className="text-win shrink-0" />
  if (status === 'active') return <Loader2 size={14} className="text-accent animate-spin shrink-0" />
  if (status === 'error') return <X size={14} className="text-loss shrink-0" />
  return <CircleDashed size={14} className="text-text-faint shrink-0" />
}

interface Props {
  phase: JobPhase
  stepDefs: [string, string][]
  events: BootstrapStepEvent[]
  error: string | null
  onRetry: () => void
  /** "fullpage" replaces the whole tab content (first load). "bottom" is a
   * compact panel meant to sit at the bottom of the screen while the
   * previous result stays visible underneath (refresh). */
  variant: 'fullpage' | 'bottom'
}

export function BootstrapProgressPanel({ phase, stepDefs, events, error, onRetry, variant }: Props) {
  const steps = deriveSteps(stepDefs, events, phase)

  const body = (
    <div className="flex flex-col gap-2">
      {phase === 'starting' && <p className="text-sm text-text-dim">Starting…</p>}
      {steps.map(step => (
        <div key={step.key} className="flex items-center gap-2 text-sm">
          <StepIcon status={step.status} />
          <span className={step.status === 'pending' ? 'text-text-faint' : 'text-text-dim'}>{step.label}</span>
          {step.detail && <span className="text-xs text-text-faint">— {step.detail}</span>}
        </div>
      ))}
      {phase === 'error' && (
        <div className="flex items-center gap-3 mt-1">
          <p className="text-sm text-loss">{error ?? 'Something went wrong.'}</p>
          <button type="button" className="btn-secondary shrink-0" onClick={onRetry}>
            Retry
          </button>
        </div>
      )}
    </div>
  )

  if (variant === 'bottom') {
    return (
      <div className="fixed bottom-4 right-4 left-4 sm:left-auto sm:w-96 card p-3 shadow-xl z-40 flex flex-col gap-2 max-h-64 overflow-y-auto">
        <span className="section-label">
          {phase === 'error' ? 'Refresh failed' : 'Refreshing access data…'}
        </span>
        {body}
      </div>
    )
  }

  return (
    <div className="card p-6 flex flex-col gap-3">
      <p className="text-sm text-text-dim text-center">
        Scanning every resource group, project, policy, group, and user across your tenant…
      </p>
      {body}
    </div>
  )
}
```

### `PolicyRuleCard.tsx` — renders one policy rule (targets, privileges, conditions, optional per-user "last accessed")

```tsx
import { useState, type ReactNode } from 'react'
import { ChevronDown, ChevronUp } from 'lucide-react'
import type { PolicyRule, PolicyRuleResolution, ResourceAccessInfo } from '../types'
import { describeCondition } from '../utils/policy'
import { formatDateTime } from '../utils/format'

interface Props {
  rule: PolicyRule
  /** Shown when this card appears outside its own policy's detail view
   * (e.g. in the Project/User/Group tabs, where rules from many different
   * policies are listed together) so it's clear which policy granted it. */
  policyName?: string
  /** Only meaningful for resolved resolutions -- see UsersTab, the only
   * current caller that passes this. Omitted everywhere else (Projects/
   * Policies/Groups tabs), since "last accessed by whom" only makes sense
   * once a specific user is in scope. Keyed by resolution.id. */
  accessInfoByResourceId?: Map<string, ResourceAccessInfo>
}

// Resource kinds with a verified, working System Log mapping -- see
// create_secret_folders.py's RESOURCE_ACCESS_EVENT_TYPES. Kept in sync
// with UsersTab's TRACKABLE_KINDS (the only current caller that populates
// accessInfoByResourceId for these kinds).
const TRACKABLE_KINDS = new Set([
  'secret',
  'individual_server_account',
  'individual_managed_saas_app_account',
  'individual_unmanaged_saas_app_account',
  'individual_okta_account',
])

function Tag({ children }: { children: ReactNode }) {
  return (
    <span className="text-[0.6875rem] font-medium px-1.5 py-0.5 rounded border bg-bg-hover text-text-dim border-border whitespace-nowrap">
      {children}
    </span>
  )
}

function ResourceAccessSummary({ info }: { info: ResourceAccessInfo }) {
  const [expanded, setExpanded] = useState(false)

  if (!info.supported) {
    return <span className="text-text-faint italic">access tracking not available for this resource type</span>
  }
  if (info.events.length === 0) {
    return <span className="text-text-faint">not accessed (or not within the last 90 days)</span>
  }

  const [latest, ...rest] = info.events
  return (
    <span className="inline-flex flex-col gap-0.5">
      <span className="inline-flex items-center gap-1">
        <span>
          last accessed {formatDateTime(latest.published)}
          {latest.request_id && <> · request <code className="text-[0.625rem]">{latest.request_id}</code></>}
        </span>
        {rest.length > 0 && (
          <button
            type="button"
            onClick={() => setExpanded(e => !e)}
            className="text-text-faint hover:text-text-dim"
            title={expanded ? 'Hide earlier accesses' : `Show ${rest.length} earlier access(es)`}
          >
            {expanded ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
          </button>
        )}
      </span>
      {expanded && rest.map((e, i) => (
        <span key={i} className="pl-3 text-text-faint">
          {formatDateTime(e.published)}
          {e.request_id && <> · request <code className="text-[0.625rem]">{e.request_id}</code></>}
        </span>
      ))}
    </span>
  )
}

function FolderAccessSummary({
  childSecrets,
  accessInfoByResourceId,
}: {
  childSecrets: { id: string; name: string }[]
  accessInfoByResourceId: Map<string, ResourceAccessInfo>
}) {
  const [expanded, setExpanded] = useState(false)
  return (
    <span className="inline-flex flex-col gap-0.5">
      <button
        type="button"
        onClick={() => setExpanded(e => !e)}
        className="inline-flex items-center gap-1 text-text-faint hover:text-text-dim"
        title={expanded ? 'Hide secrets' : `Show ${childSecrets.length} secret(s) in this folder`}
      >
        {childSecrets.length} secret{childSecrets.length === 1 ? '' : 's'} in this folder
        {expanded ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
      </button>
      {expanded &&
        childSecrets.map(secret => {
          const info = accessInfoByResourceId.get(secret.id)
          return (
            <div key={secret.id} className="flex items-baseline gap-1.5 pl-3">
              <span className="text-text-dim shrink-0">{secret.name}:</span>
              {info ? <ResourceAccessSummary info={info} /> : <span className="text-text-faint">loading…</span>}
            </div>
          )
        })}
    </span>
  )
}

export function PolicyRuleCard({ rule, policyName, accessInfoByResourceId }: Props) {
  // Narrowed to TRACKABLE_KINDS (not every resolved resource) because
  // that's all UsersTab ever queries access info for -- including anything
  // else here would show a permanent "loading…" for resource kinds nobody
  // asked about, rather than nothing.
  const trackableTargets = rule.resolutions.filter(
    (r): r is PolicyRuleResolution & { kind: 'resolved' } => r.kind === 'resolved' && TRACKABLE_KINDS.has(r.resource_kind)
  )
  // Folder grants have no access event of their own (see
  // create_secret_folders.py's RESOURCE_ACCESS_EVENT_TYPES), but roll up
  // per-secret access for whatever's actually inside the folder. Skipped
  // when empty -- an empty folder has nothing to report.
  const trackableFolders = rule.resolutions.filter(
    (r): r is PolicyRuleResolution & { kind: 'resolved' } =>
      r.kind === 'resolved' && r.resource_kind === 'secret_folder' && (r.child_secrets?.length ?? 0) > 0
  )
  return (
    <div className="card p-3 flex flex-col gap-2">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-text">{rule.name}</span>
          <Tag>{rule.resource_type_label}</Tag>
        </div>
        {policyName && <span className="text-xs text-text-faint">via {policyName}</span>}
      </div>

      <div className="flex flex-col gap-1">
        <span className="section-label">Applies to</span>
        <div className="flex flex-wrap gap-1.5">
          {rule.resolutions.map((res, i) =>
            res.kind === 'resolved' ? (
              <Tag key={i}>
                {res.name}
                {res.project_name ? ` — ${res.project_name}` : ' (project unknown)'}
              </Tag>
            ) : (
              <span key={i} className="text-xs text-text-faint italic">
                {res.description}
              </span>
            )
          )}
        </div>
      </div>

      {accessInfoByResourceId && (trackableTargets.length > 0 || trackableFolders.length > 0) && (
        <div className="flex flex-col gap-1">
          <span className="section-label">Last accessed (System Log, last 90 days)</span>
          <div className="flex flex-col gap-1 text-[0.6875rem]">
            {trackableTargets.map((res, i) => {
              const info = accessInfoByResourceId.get(res.access_tracking_id ?? res.id)
              return (
                <div key={`s-${i}`} className="flex items-baseline gap-1.5">
                  <span className="text-text-dim shrink-0">{res.name}:</span>
                  {info ? <ResourceAccessSummary info={info} /> : <span className="text-text-faint">loading…</span>}
                </div>
              )
            })}
            {trackableFolders.map((res, i) => (
              <div key={`f-${i}`} className="flex items-baseline gap-1.5">
                <span className="text-text-dim shrink-0">{res.name}:</span>
                <FolderAccessSummary childSecrets={res.child_secrets!} accessInfoByResourceId={accessInfoByResourceId} />
              </div>
            ))}
          </div>
        </div>
      )}

      {rule.privileges.length > 0 && (
        <div className="flex flex-col gap-1">
          <span className="section-label">Privileges</span>
          <div className="flex flex-wrap gap-1.5">
            {rule.privileges.map((p, i) => (
              <Tag key={i}>
                {p.privilege_type}
                {p.flags.length > 0 ? `: ${p.flags.join(', ')}` : ''}
              </Tag>
            ))}
          </div>
        </div>
      )}

      {rule.conditions.length > 0 && (
        <div className="flex flex-col gap-1">
          <span className="section-label">Conditions</span>
          <div className="flex flex-wrap gap-1.5">
            {rule.conditions.map((c, i) => (
              <Tag key={i}>{describeCondition(c)}</Tag>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
```

### `AccessExplorer.tsx` — top-level tab: runs the bootstrap job, hosts the 5 sub-tabs

```tsx
import { useEffect, useRef, useState } from 'react'
import { RefreshCw } from 'lucide-react'
import { useAccessBootstrapJob } from '../hooks/useAccessBootstrapJob'
import type { AccessModel } from '../types'
import { BootstrapProgressPanel } from './BootstrapProgressPanel'
import { GroupsTab } from './GroupsTab'
import { PoliciesTab } from './PoliciesTab'
import { ProjectsTab } from './ProjectsTab'
import { ResourceGroupsTab } from './ResourceGroupsTab'
import { TabBar } from './TabBar'
import { UsersTab } from './UsersTab'
import { ExportButtons } from './ExportButtons'
import { accessModelExportSections } from '../utils/exportSections'

const SUB_TABS = [
  { value: 'resource_groups', label: 'Resource Groups' },
  { value: 'projects', label: 'Projects' },
  { value: 'policies', label: 'Policies' },
  { value: 'users', label: 'Users' },
  { value: 'groups', label: 'Groups' },
]

export function AccessExplorer() {
  const [subTab, setSubTab] = useState('resource_groups')
  const job = useAccessBootstrapJob()
  const startedOnce = useRef(false)
  // The last successfully loaded model stays visible during a refresh
  // (job.result briefly clears while the new job runs) so a Refresh
  // doesn't blank the screen while its own progress panel shows at the
  // bottom.
  const [displayedModel, setDisplayedModel] = useState<AccessModel | null>(null)

  useEffect(() => {
    if (!startedOnce.current) {
      startedOnce.current = true
      job.start()
    }
  }, [job])

  useEffect(() => {
    if (job.phase === 'done' && job.result) setDisplayedModel(job.result)
  }, [job.phase, job.result])

  const isRefreshing = displayedModel !== null && job.phase !== 'done'

  if (!displayedModel) {
    return (
      <BootstrapProgressPanel
        phase={job.phase}
        stepDefs={job.stepDefs}
        events={job.events}
        error={job.error}
        onRetry={job.start}
        variant="fullpage"
      />
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <TabBar tabs={SUB_TABS} value={subTab} onChange={setSubTab} />
        <div className="flex items-center gap-2">
          <ExportButtons sections={accessModelExportSections(displayedModel)} filenameBase="opa-access-explorer-all" />
          <button type="button" className="btn-secondary shrink-0" onClick={job.start} disabled={isRefreshing}>
            <RefreshCw size={13} className={isRefreshing ? 'animate-spin' : ''} />
            {isRefreshing ? 'Refreshing…' : 'Refresh'}
          </button>
        </div>
      </div>

      {subTab === 'resource_groups' && <ResourceGroupsTab model={displayedModel} />}
      {subTab === 'projects' && <ProjectsTab model={displayedModel} />}
      {subTab === 'policies' && <PoliciesTab model={displayedModel} />}
      {subTab === 'users' && <UsersTab model={displayedModel} />}
      {subTab === 'groups' && <GroupsTab model={displayedModel} />}

      {isRefreshing && (
        <BootstrapProgressPanel
          phase={job.phase}
          stepDefs={job.stepDefs}
          events={job.events}
          error={job.error}
          onRetry={job.start}
          variant="bottom"
        />
      )}
    </div>
  )
}
```

### `ResourceGroupsTab.tsx`

```tsx
import { useMemo, useState } from 'react'
import type { AccessModel } from '../types'
import type { ExportSection } from '../utils/export'
import { grantRows } from '../utils/exportSections'
import { policiesForResourceGroup } from '../utils/policy'
import { ExportButtons } from './ExportButtons'
import { PolicyRuleCard } from './PolicyRuleCard'
import { Select } from './Select'

interface Props {
  model: AccessModel
}

export function ResourceGroupsTab({ model }: Props) {
  const [rgId, setRgId] = useState<string | undefined>(undefined)
  const rg = model.resource_groups.find(r => r.id === rgId)

  const projects = useMemo(() => model.projects.filter(p => p.resource_group_id === rgId), [model.projects, rgId])
  const policies = useMemo(() => (rgId ? policiesForResourceGroup(model.policies, rgId) : []), [model.policies, rgId])

  const accessGroups = useMemo(() => {
    const seen = new Map<string, string>()
    for (const p of policies) {
      for (const g of p.principals.user_groups) seen.set(g.id, g.name)
    }
    return [...seen.values()]
  }, [policies])

  const resourceTypes = useMemo(() => {
    const seen = new Set<string>()
    for (const p of policies) for (const r of p.rules) seen.add(r.resource_type_label)
    return [...seen]
  }, [policies])

  const exportSectionsForRg: ExportSection[] = useMemo(() => {
    if (!rg) return []
    return [
      {
        title: `Resource Group: ${rg.name}`,
        rows: [
          {
            Description: rg.description ?? '',
            'Delegated Admin Groups': (rg.delegated_resource_admin_groups ?? []).map(g => g.name).join(', '),
          },
        ],
      },
      {
        title: 'Projects',
        rows: projects.map(p => ({
          Project: p.name,
          'Active Resources': typeof p.active_resource_count === 'number' ? String(p.active_resource_count) : '',
          'Stale Resources': typeof p.stale_resource_count === 'number' ? String(p.stale_resource_count) : '',
        })),
      },
      { title: 'Policies & Rules', rows: grantRows(policies.flatMap(policy => policy.rules.map(rule => ({ policy, rule })))) },
    ]
  }, [rg, projects, policies])

  return (
    <div className="flex flex-col gap-4">
      <div className="card p-3 flex items-end justify-between gap-4">
        <div className="flex flex-col gap-1">
          <span className="section-label">Resource group</span>
          <Select
            value={rgId}
            onValueChange={setRgId}
            placeholder="Select a resource group"
            options={model.resource_groups.map(r => ({ value: r.id, label: r.name }))}
          />
        </div>
        {rg && <ExportButtons sections={exportSectionsForRg} filenameBase={`opa-resource-group-${rg.name}`} />}
      </div>

      {rg && (
        <>
          <div className="card p-3 flex flex-col gap-3">
            {rg.description && <p className="text-sm text-text-dim">{rg.description}</p>}

            <div className="flex flex-col gap-1">
              <span className="section-label">Delegated admin group(s)</span>
              {rg.delegated_resource_admin_groups?.length ? (
                <div className="flex flex-wrap gap-1.5">
                  {rg.delegated_resource_admin_groups.map(g => (
                    <span key={g.id} className="text-xs text-text-dim bg-bg-hover border border-border rounded px-1.5 py-0.5">
                      {g.name}
                    </span>
                  ))}
                </div>
              ) : (
                <span className="text-xs text-text-faint">None</span>
              )}
            </div>

            <div className="flex flex-col gap-1">
              <span className="section-label">Who has access (via policies scoped here)</span>
              {accessGroups.length ? (
                <div className="flex flex-wrap gap-1.5">
                  {accessGroups.map(name => (
                    <span key={name} className="text-xs text-text-dim bg-bg-hover border border-border rounded px-1.5 py-0.5">
                      {name}
                    </span>
                  ))}
                </div>
              ) : (
                <span className="text-xs text-text-faint">No policies grant access via a group here</span>
              )}
            </div>

            <div className="flex flex-col gap-1">
              <span className="section-label">Resource types covered</span>
              {resourceTypes.length ? (
                <div className="flex flex-wrap gap-1.5">
                  {resourceTypes.map(t => (
                    <span key={t} className="text-xs text-text-dim bg-bg-hover border border-border rounded px-1.5 py-0.5">
                      {t}
                    </span>
                  ))}
                </div>
              ) : (
                <span className="text-xs text-text-faint">None</span>
              )}
            </div>
          </div>

          <div className="card p-3 flex flex-col gap-2">
            <span className="section-label">Projects ({projects.length})</span>
            {projects.length === 0 && <span className="text-xs text-text-faint">No projects in this resource group</span>}
            {projects.map(p => (
              <div key={p.id} className="flex items-center justify-between text-sm">
                <span className="text-text-dim">{p.name}</span>
                <span className="text-xs text-text-faint">
                  {typeof p.active_resource_count === 'number' ? `${p.active_resource_count} active` : ''}
                  {typeof p.stale_resource_count === 'number' && p.stale_resource_count > 0
                    ? ` · ${p.stale_resource_count} stale`
                    : ''}
                </span>
              </div>
            ))}
          </div>

          <div className="flex flex-col gap-2">
            <span className="section-label">Policies scoped to this resource group ({policies.length})</span>
            {policies.length === 0 && <span className="text-xs text-text-faint">None</span>}
            {policies.map(policy => (
              <div key={policy.id} className="flex flex-col gap-2">
                {policy.rules.map((rule, i) => (
                  <PolicyRuleCard key={i} rule={rule} policyName={policy.name} />
                ))}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
```

### `ProjectsTab.tsx`

```tsx
import { useMemo, useState } from 'react'
import type { AccessModel } from '../types'
import type { ExportSection } from '../utils/export'
import { grantRows, projectFieldRows } from '../utils/exportSections'
import { rulesGrantedForProject } from '../utils/policy'
import { ExportButtons } from './ExportButtons'
import { KeyValueGrid } from './KeyValueGrid'
import { PolicyRuleCard } from './PolicyRuleCard'
import { Select } from './Select'

interface Props {
  model: AccessModel
}

export function ProjectsTab({ model }: Props) {
  const [rgId, setRgId] = useState<string | undefined>(undefined)
  const [projectId, setProjectId] = useState<string | undefined>(undefined)

  const projectsInRg = useMemo(() => model.projects.filter(p => p.resource_group_id === rgId), [model.projects, rgId])
  const project = model.projects.find(p => p.id === projectId)
  const rg = model.resource_groups.find(r => r.id === rgId)

  const grants = useMemo(() => (projectId ? rulesGrantedForProject(model.policies, projectId) : []), [model.policies, projectId])

  const exportSectionsForProject: ExportSection[] = useMemo(() => {
    if (!project) return []
    return [
      { title: `Project: ${project.name}`, rows: projectFieldRows(project) },
      { title: 'Policies Granting Access', rows: grantRows(grants) },
    ]
  }, [project, grants])

  const handleRgChange = (id: string) => {
    setRgId(id)
    setProjectId(undefined)
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="card p-3 flex flex-wrap items-end gap-4">
        <div className="flex flex-col gap-1">
          <span className="section-label">Resource group</span>
          <Select
            value={rgId}
            onValueChange={handleRgChange}
            placeholder="Select a resource group"
            options={model.resource_groups.map(r => ({ value: r.id, label: r.name }))}
          />
        </div>
        <div className="flex flex-col gap-1">
          <span className="section-label">Project</span>
          <Select
            value={projectId}
            onValueChange={setProjectId}
            disabled={!rgId}
            placeholder="Select a project"
            options={projectsInRg.map(p => ({ value: p.id, label: p.name }))}
          />
        </div>
      </div>

      {project && (
        <>
          <div className="card p-3 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-text">{project.name}</span>
              <div className="flex items-center gap-2">
                <span className="text-xs text-text-faint">{rg?.name}</span>
                <ExportButtons sections={exportSectionsForProject} filenameBase={`opa-project-${project.name}`} />
              </div>
            </div>
            <KeyValueGrid data={project} />
          </div>

          <div className="flex flex-col gap-2">
            <span className="section-label">Policies granting access to this project ({grants.length})</span>
            {grants.length === 0 && (
              <span className="text-xs text-text-faint">
                No policy resolves a specific resource in this project. (Resource-group-wide rules — server labels,
                Active Directory, database selectors — may still apply; check the Resource Groups tab for {rg?.name}.)
              </span>
            )}
            {grants.map(({ policy, rule }, i) => (
              <PolicyRuleCard key={`${policy.id}-${i}`} rule={rule} policyName={policy.name} />
            ))}
          </div>
        </>
      )}
    </div>
  )
}
```

### `PoliciesTab.tsx`

```tsx
import { useMemo, useState } from 'react'
import type { AccessModel } from '../types'
import type { ExportSection } from '../utils/export'
import { grantRows, policySummaryRows } from '../utils/exportSections'
import { ExportButtons } from './ExportButtons'
import { PolicyRuleCard } from './PolicyRuleCard'

interface Props {
  model: AccessModel
}

export function PoliciesTab({ model }: Props) {
  const [policyId, setPolicyId] = useState<string | undefined>(undefined)

  const scoped = useMemo(
    () => model.policies.filter(p => p.resource_group).sort((a, b) => a.name.localeCompare(b.name)),
    [model.policies]
  )
  const teamWide = useMemo(
    () => model.policies.filter(p => !p.resource_group).sort((a, b) => a.name.localeCompare(b.name)),
    [model.policies]
  )
  const policy = model.policies.find(p => p.id === policyId)

  const exportSectionsForView: ExportSection[] = useMemo(() => {
    if (!policy) return [{ title: 'Policies', rows: policySummaryRows(model.policies) }]
    return [
      {
        title: `Policy: ${policy.name}`,
        rows: [
          {
            Description: policy.description ?? '',
            Active: policy.active ? 'Yes' : 'No',
            'Resource Group': policy.resource_group?.name ?? 'Team-wide',
            'Principal Groups': policy.principals.user_groups.map(g => g.name).join(', '),
            'Workload Roles': policy.principals.workload_roles.map(w => w.name).join(', '),
          },
        ],
      },
      { title: 'Rules', rows: grantRows(policy.rules.map(rule => ({ policy, rule }))) },
    ]
  }, [policy, model.policies])

  return (
    <div className="flex flex-col gap-3">
      <div className="flex justify-end">
        <ExportButtons
          sections={exportSectionsForView}
          filenameBase={policy ? `opa-policy-${policy.name}` : 'opa-policies'}
        />
      </div>
      <div className="flex gap-4">
      <div className="card p-2 flex flex-col gap-1 w-64 shrink-0 max-h-[70vh] overflow-y-auto">
        <span className="section-label px-1 py-1">Scoped to a resource group ({scoped.length})</span>
        {scoped.map(p => (
          <button
            key={p.id}
            type="button"
            onClick={() => setPolicyId(p.id)}
            className={`text-left text-sm rounded px-2 py-1.5 transition-colors ${
              p.id === policyId ? 'bg-accent-dim text-text' : 'text-text-dim hover:bg-bg-hover'
            }`}
          >
            {p.name}
            {!p.active && <span className="text-text-faint text-xs"> (inactive)</span>}
          </button>
        ))}

        {teamWide.length > 0 && (
          <>
            <span className="section-label px-1 py-1 mt-2">Team-wide ({teamWide.length})</span>
            {teamWide.map(p => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPolicyId(p.id)}
                className={`text-left text-sm rounded px-2 py-1.5 transition-colors ${
                  p.id === policyId ? 'bg-accent-dim text-text' : 'text-text-dim hover:bg-bg-hover'
                }`}
              >
                {p.name}
                {!p.active && <span className="text-text-faint text-xs"> (inactive)</span>}
              </button>
            ))}
          </>
        )}
      </div>

      <div className="flex-1 flex flex-col gap-3">
        {!policy && <span className="text-sm text-text-faint">Select a policy to see its detail.</span>}
        {policy && (
          <>
            <div className="card p-3 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-text">{policy.name}</span>
                <span className="text-xs text-text-faint">
                  {policy.resource_group ? policy.resource_group.name : 'Team-wide'} · {policy.active ? 'Active' : 'Inactive'}
                </span>
              </div>
              {policy.description && <p className="text-sm text-text-dim">{policy.description}</p>}

              <div className="flex flex-col gap-1">
                <span className="section-label">Principals</span>
                <div className="flex flex-wrap gap-1.5">
                  {policy.principals.user_groups.map(g => (
                    <span key={g.id} className="text-xs text-text-dim bg-bg-hover border border-border rounded px-1.5 py-0.5">
                      {g.name}
                    </span>
                  ))}
                  {policy.principals.workload_roles.map(w => (
                    <span key={w.id} className="text-xs text-text-dim bg-bg-hover border border-border rounded px-1.5 py-0.5">
                      {w.name} (workload role)
                    </span>
                  ))}
                  {policy.principals.user_groups.length === 0 && policy.principals.workload_roles.length === 0 && (
                    <span className="text-xs text-text-faint">None</span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              {policy.rules.map((rule, i) => (
                <PolicyRuleCard key={i} rule={rule} />
              ))}
            </div>
          </>
        )}
      </div>
      </div>
    </div>
  )
}
```

### `GroupsTab.tsx`

```tsx
import { useMemo, useState } from 'react'
import type { AccessModel } from '../types'
import type { ExportSection } from '../utils/export'
import { grantRows } from '../utils/exportSections'
import { rulesGrantedToGroupIds } from '../utils/policy'
import { ExportButtons } from './ExportButtons'
import { PolicyRuleCard } from './PolicyRuleCard'
import { Select } from './Select'

interface Props {
  model: AccessModel
}

export function GroupsTab({ model }: Props) {
  const [groupId, setGroupId] = useState<string | undefined>(undefined)
  const group = model.groups.find(g => g.id === groupId)

  const members = useMemo(
    () => model.users.filter(u => u.groups.some(g => g.id === groupId)),
    [model.users, groupId]
  )
  const grants = useMemo(
    () => (groupId ? rulesGrantedToGroupIds(model.policies, new Set([groupId])) : []),
    [model.policies, groupId]
  )

  const exportSectionsForGroup: ExportSection[] = useMemo(() => {
    if (!group) return []
    return [
      {
        title: `Group: ${group.name}`,
        rows: [{ Roles: group.roles.join(', '), Members: members.map(u => u.details?.full_name || u.name).join(', ') }],
      },
      { title: 'Access Granted', rows: grantRows(grants) },
    ]
  }, [group, members, grants])

  return (
    <div className="flex flex-col gap-4">
      <div className="card p-3 flex flex-col gap-1">
        <span className="section-label">Group</span>
        <Select
          value={groupId}
          onValueChange={setGroupId}
          placeholder="Select a group"
          options={model.groups.map(g => ({ value: g.id, label: g.name }))}
        />
      </div>

      {group && (
        <>
          <div className="card p-3 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-text">{group.name}</span>
              <ExportButtons sections={exportSectionsForGroup} filenameBase={`opa-group-${group.name}`} />
            </div>
            <div className="flex flex-col gap-1">
              <span className="section-label">RBAC role(s) (team-level admin roles, not resource access)</span>
              <div className="flex flex-wrap gap-1.5">
                {group.roles.map(r => (
                  <span key={r} className="text-xs text-text-dim bg-bg-hover border border-border rounded px-1.5 py-0.5">
                    {r}
                  </span>
                ))}
                {group.roles.length === 0 && <span className="text-xs text-text-faint">None</span>}
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <span className="section-label">Members ({members.length})</span>
              <div className="flex flex-wrap gap-1.5">
                {members.map(u => (
                  <span key={u.id} className="text-xs text-text-dim bg-bg-hover border border-border rounded px-1.5 py-0.5">
                    {u.details?.full_name || u.name}
                  </span>
                ))}
                {members.length === 0 && <span className="text-xs text-text-faint">None found among fetched users</span>}
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <span className="section-label">Everything this group grants access to ({grants.length})</span>
            {grants.length === 0 && <span className="text-xs text-text-faint">No policy names this group as a principal.</span>}
            {grants.map(({ policy, rule }, i) => (
              <PolicyRuleCard key={`${policy.id}-${i}`} rule={rule} policyName={policy.name} />
            ))}
          </div>
        </>
      )}
    </div>
  )
}
```

### `UsersTab.tsx` — the one tab that queries per-user "last accessed" (System Log) on selection

```tsx
import { useMemo, useState } from 'react'
import { useUserResourceAccess } from '../api/hooks'
import type { AccessModel, ResourceAccessInfo } from '../types'
import type { ExportSection } from '../utils/export'
import { grantRows } from '../utils/exportSections'
import { rulesGrantedToGroupIds } from '../utils/policy'
import { ExportButtons } from './ExportButtons'
import { PolicyRuleCard } from './PolicyRuleCard'
import { Select } from './Select'

interface Props {
  model: AccessModel
}

// Resource kinds with a verified, working System Log mapping -- see
// create_secret_folders.py's RESOURCE_ACCESS_EVENT_TYPES.
const TRACKABLE_KINDS = new Set([
  'secret',
  'individual_server_account',
  'individual_managed_saas_app_account',
  'individual_unmanaged_saas_app_account',
  'individual_okta_account',
])

export function UsersTab({ model }: Props) {
  const [userId, setUserId] = useState<string | undefined>(undefined)
  const user = model.users.find(u => u.id === userId)

  const groupIds = useMemo(() => new Set(user?.groups.map(g => g.id) ?? []), [user])
  const grants = useMemo(() => (user ? rulesGrantedToGroupIds(model.policies, groupIds) : []), [model.policies, groupIds, user])

  // Only resource_kinds with a verified, working System Log mapping (see
  // create_secret_folders.py's RESOURCE_ACCESS_EVENT_TYPES) are queried
  // here; everything else is left out entirely, since there's nothing
  // useful to fetch for them yet. secret_folder grants have no event of
  // their own (folder browsing isn't logged, and reveals reference the
  // secret's id, never the folder's), but expand to their child_secrets --
  // queried here as plain "secret" resources so PolicyRuleCard can roll
  // the results back up under the folder. SaaS/Okta account kinds are
  // queried by access_tracking_id (their OPA-internal id), not the
  // displayed id (the Okta-side identifier, never logged as a target) --
  // see that field's comment in types/index.ts.
  const trackedResources = useMemo(() => {
    const seen = new Map<string, { resource_kind: string; resource_id: string }>()
    for (const { rule } of grants) {
      for (const res of rule.resolutions) {
        if (res.kind !== 'resolved') continue
        if (TRACKABLE_KINDS.has(res.resource_kind)) {
          const resourceId = res.access_tracking_id ?? res.id
          seen.set(resourceId, { resource_kind: res.resource_kind, resource_id: resourceId })
        } else if (res.resource_kind === 'secret_folder') {
          for (const child of res.child_secrets ?? []) {
            seen.set(child.id, { resource_kind: 'secret', resource_id: child.id })
          }
        }
      }
    }
    return [...seen.values()]
  }, [grants])

  const { data: accessResults } = useUserResourceAccess(user?.id, trackedResources)
  const accessInfoByResourceId = useMemo(() => {
    const map = new Map<string, ResourceAccessInfo>()
    if (accessResults) {
      for (const [resourceId, info] of Object.entries(accessResults)) map.set(resourceId, info)
    }
    return map
  }, [accessResults])

  const exportSectionsForUser: ExportSection[] = useMemo(() => {
    if (!user) return []
    return [
      {
        title: `User: ${user.details?.full_name || user.name}`,
        rows: [
          {
            Email: user.details?.email ?? '',
            Status: user.status ?? '',
            Groups: user.groups.map(g => g.name).join(', '),
          },
        ],
      },
      { title: 'Access Granted', rows: grantRows(grants) },
    ]
  }, [user, grants])

  return (
    <div className="flex flex-col gap-4">
      <div className="card p-3 flex flex-col gap-1">
        <span className="section-label">User</span>
        <Select
          value={userId}
          onValueChange={setUserId}
          placeholder="Select a user"
          options={model.users.map(u => ({ value: u.id, label: u.details?.full_name || u.name }))}
        />
      </div>

      {user && (
        <>
          <div className="card p-3 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-text">{user.details?.full_name || user.name}</span>
              <div className="flex items-center gap-2">
                <span className="text-xs text-text-faint">{user.status}</span>
                <ExportButtons sections={exportSectionsForUser} filenameBase={`opa-user-${user.name}`} />
              </div>
            </div>
            {user.details?.email && <span className="text-xs text-text-faint">{user.details.email}</span>}

            <div className="flex flex-col gap-1">
              <span className="section-label">Groups ({user.groups.length})</span>
              <div className="flex flex-wrap gap-1.5">
                {user.groups.map(g => (
                  <span key={g.id} className="text-xs text-text-dim bg-bg-hover border border-border rounded px-1.5 py-0.5">
                    {g.name}
                  </span>
                ))}
                {user.groups.length === 0 && <span className="text-xs text-text-faint">None</span>}
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <span className="section-label">Everything this user has access to (via their groups) ({grants.length})</span>
            {grants.length === 0 && <span className="text-xs text-text-faint">No policy grants access via this user's groups.</span>}
            {grants.map(({ policy, rule }, i) => (
              <PolicyRuleCard
                key={`${policy.id}-${i}`}
                rule={rule}
                policyName={policy.name}
                accessInfoByResourceId={accessInfoByResourceId}
              />
            ))}
          </div>
        </>
      )}
    </div>
  )
}
```

---
## 16. `frontend/src/main.tsx`

```tsx
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import './index.css'
import App from './App.tsx'
import { ToastProvider } from './components/ToastProvider.tsx'

const queryClient = new QueryClient()

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
      <ToastProvider />
    </QueryClientProvider>
  </StrictMode>,
)
```

---

## 17. `frontend/src/App.tsx`

```tsx
import { useState } from 'react'
import { useEnvironments } from './api/hooks'
import { AboutDialog } from './components/AboutDialog'
import { AccessExplorer } from './components/AccessExplorer'
import { EnvironmentManagerDialog } from './components/EnvironmentManagerDialog'
import { EnvironmentSetup } from './components/EnvironmentSetup'
import { FolderBuilder } from './components/FolderBuilder'
import { TabBar } from './components/TabBar'

const TABS = [
  { value: 'builder', label: 'Folder Builder' },
  { value: 'access', label: 'Access Explorer' },
]

export default function App() {
  const [activeTab, setActiveTab] = useState('builder')
  const { data: environments, isLoading: environmentsLoading } = useEnvironments()
  const isConfigured = !!environments?.active

  if (environmentsLoading) {
    return <div className="px-6 py-16 text-center text-sm text-text-faint">Loading…</div>
  }

  if (!isConfigured) {
    return (
      <div className="max-w-4xl mx-auto px-6 py-8">
        <EnvironmentSetup />
      </div>
    )
  }

  return (
    <div className="px-6 py-8 flex flex-col gap-5">
      <div className="max-w-4xl mx-auto w-full flex flex-col gap-5">
        <header className="flex items-start justify-between">
          <div>
            <h1 className="text-lg font-semibold text-text">OPA Secrets Wizard</h1>
            <p className="text-xs text-text-faint mt-1">
              {activeTab === 'builder'
                ? 'Pick or create a resource group and project, build the folder tree, then preview and create.'
                : 'Explore who has access to what, across resource groups, projects, policies, users, and groups.'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-text-faint">
              Connected: <span className="text-text-dim font-medium">{environments?.active}</span>
            </span>
            <AboutDialog />
            <EnvironmentManagerDialog data={environments} />
          </div>
        </header>

        <TabBar tabs={TABS} value={activeTab} onChange={setActiveTab} />
      </div>

      {activeTab === 'builder' ? (
        <div className="max-w-4xl mx-auto w-full">
          <FolderBuilder />
        </div>
      ) : (
        <div className="max-w-6xl mx-auto w-full">
          <AccessExplorer />
        </div>
      )}
    </div>
  )
}
```

---

## 18. `frontend/src/index.css`

Tailwind v4 CSS-first theme (`@theme`) — dark-mode-only palette, plus a set
of `@utility` classes (`card`, `btn-primary`, `btn-secondary`, `btn-danger`,
`section-label`, `dropdown`, `text-input`) reused across every component
above instead of repeating raw utility classes everywhere.

```css
@import "tailwindcss";

@theme {
  --font-family-sans: "Inter", system-ui, sans-serif;

  /* ── Dark mode palette (default) ──────────────────── */
  --color-bg:           #09090b;
  --color-bg-elevated:  #111114;
  --color-bg-card:      #17171c;
  --color-bg-hover:     #1e1e24;
  --color-border:       #2a2a30;
  --color-border-sub:   #1f1f25;
  --color-text:         #f4f4f5;
  --color-text-dim:     #d1d1d6;
  --color-text-faint:   #7c7c86;
  --color-accent:       #1662DD;
  --color-accent-dim:   #1d3a5c;
  --color-win:          #34d399;
  --color-loss:         #f87171;
  --color-warn:         #fb923c;

  /* ── Shadow tokens ─────────────────────────────────── */
  --shadow-sm:  0 1px 3px 0 rgb(0 0 0 / 0.3), 0 1px 2px -1px rgb(0 0 0 / 0.3);
  --shadow-md:  0 4px 6px -1px rgb(0 0 0 / 0.4), 0 2px 4px -2px rgb(0 0 0 / 0.4);
  --shadow-xl:  0 20px 25px -5px rgb(0 0 0 / 0.5), 0 8px 10px -6px rgb(0 0 0 / 0.5);
}

/* ── Base reset ──────────────────────────────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; }

body {
  margin: 0;
  background-color: var(--color-bg);
  color: var(--color-text);
  font-family: var(--font-family-sans);
  -webkit-font-smoothing: antialiased;
}

#root { min-height: 100dvh; }

/* ── Design system utilities ──────────────────────────────────────────────── */

@utility card {
  background-color: var(--color-bg-card);
  border-radius: 0.5rem;
  border: 1px solid var(--color-border);
  box-shadow: var(--shadow-sm);
}

@utility btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.375rem 0.75rem;
  font-size: 0.875rem;
  font-weight: 500;
  border-radius: 0.5rem;
  background-color: var(--color-accent);
  color: #ffffff;
  border: 1px solid transparent;
  transition-property: color, background-color, border-color;
  transition-duration: 150ms;
  cursor: pointer;

  &:hover { background-color: color-mix(in srgb, var(--color-accent) 85%, black); }
  &:disabled { opacity: 0.4; cursor: default; }
}

@utility btn-secondary {
  display: inline-flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.375rem 0.75rem;
  font-size: 0.875rem;
  font-weight: 500;
  border-radius: 0.5rem;
  background-color: var(--color-bg-elevated);
  color: var(--color-text-faint);
  border: 1px solid var(--color-border);
  transition-property: color, background-color, border-color;
  transition-duration: 150ms;
  cursor: pointer;

  &:hover {
    color: var(--color-text-dim);
    border-color: color-mix(in srgb, var(--color-accent) 50%, transparent);
  }
  &:disabled { opacity: 0.4; cursor: default; }
}

@utility btn-danger {
  display: inline-flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.375rem 0.75rem;
  font-size: 0.875rem;
  font-weight: 500;
  border-radius: 0.5rem;
  background-color: var(--color-loss);
  color: #1a0505;
  border: 1px solid transparent;
  transition-property: color, background-color, border-color;
  transition-duration: 150ms;
  cursor: pointer;

  &:hover { background-color: color-mix(in srgb, var(--color-loss) 85%, black); }
  &:disabled { opacity: 0.4; cursor: default; }
}

@utility section-label {
  font-size: 0.625rem;
  font-weight: 600;
  color: var(--color-text-faint);
  text-transform: uppercase;
  letter-spacing: 0.08em;
}

@utility dropdown {
  background-color: var(--color-bg-elevated);
  border: 1px solid var(--color-border);
  border-radius: 0.5rem;
  box-shadow: var(--shadow-xl);
  overflow: hidden;
}

@utility text-input {
  background-color: var(--color-bg-elevated);
  border: 1px solid var(--color-border);
  border-radius: 0.375rem;
  padding: 0.25rem 0.5rem;
  font-size: 0.8125rem;
  color: var(--color-text);

  &::placeholder { color: var(--color-text-faint); }
  &:focus { border-color: var(--color-accent); }
}

/* ── Animations ───────────────────────────────────────────────────────────── */
@keyframes fade-in  { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: none; } }
@keyframes fade-out { from { opacity: 1; transform: none; } to { opacity: 0; transform: translateY(-4px); } }
@keyframes slide-in-from-right {
  from { transform: translateX(calc(100% + 1rem)); opacity: 0; }
  to   { transform: translateX(0); opacity: 1; }
}
@keyframes slide-out-to-right {
  from { transform: translateX(0); opacity: 1; }
  to   { transform: translateX(calc(100% + 1rem)); opacity: 0; }
}

/* ── Focus ring ───────────────────────────────────────────────────────────── */
:is(button, a, input, textarea, [role="tab"], [role="button"], [role="option"], [role="checkbox"]):focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
  border-radius: 2px;
}
```

---

## 19. `Start OPA Secrets Wizard.bat`

```bat
@echo off
where py >nul 2>nul
if %errorlevel%==0 (
    py "%~dp0launch.py" %*
) else (
    python "%~dp0launch.py" %*
)
pause
```

---

## 20. `start-wizard.sh`

```bash
#!/usr/bin/env bash
# Mac/Linux launcher -- mirrors "Start OPA Secrets Wizard.bat" for Windows.
# All real logic lives in launch.py; this just finds python3 and calls it.
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if command -v python3 &>/dev/null; then
    PYTHON=python3
elif command -v python &>/dev/null; then
    PYTHON=python
else
    echo "python3 not found on PATH. Install Python 3.8+ and try again." >&2
    exit 1
fi

exec "$PYTHON" "$DIR/launch.py" "$@"
```

---

*End of file. Every listed source path was included in full — nothing was
truncated or summarized.*

