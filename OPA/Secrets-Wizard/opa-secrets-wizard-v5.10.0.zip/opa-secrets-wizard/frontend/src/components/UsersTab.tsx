import { useMemo, useState } from 'react'
import { useUserResourceAccess } from '../api/hooks'
import type { AccessModel, ResourceAccessInfo } from '../types'
import type { ExportSection } from '../utils/export'
import { grantRows } from '../utils/exportSections'
import { rulesGrantedToGroupIds } from '../utils/policy'
import { ExportButtons } from './ExportButtons'
import { PolicyRuleCard } from './PolicyRuleCard'
import { Select } from './Select'

interface Props {
  model: AccessModel
}

// Resource kinds with a verified, working System Log mapping -- see
// create_secret_folders.py's RESOURCE_ACCESS_EVENT_TYPES.
const TRACKABLE_KINDS = new Set([
  'secret',
  'individual_server_account',
  'individual_managed_saas_app_account',
  'individual_unmanaged_saas_app_account',
  'individual_okta_account',
])

export function UsersTab({ model }: Props) {
  const [userId, setUserId] = useState<string | undefined>(undefined)
  const user = model.users.find(u => u.id === userId)

  const groupIds = useMemo(() => new Set(user?.groups.map(g => g.id) ?? []), [user])
  const grants = useMemo(() => (user ? rulesGrantedToGroupIds(model.policies, groupIds) : []), [model.policies, groupIds, user])

  // Only resource_kinds with a verified, working System Log mapping (see
  // create_secret_folders.py's RESOURCE_ACCESS_EVENT_TYPES) are queried
  // here; everything else is left out entirely, since there's nothing
  // useful to fetch for them yet. secret_folder grants have no event of
  // their own (folder browsing isn't logged, and reveals reference the
  // secret's id, never the folder's), but expand to their child_secrets --
  // queried here as plain "secret" resources so PolicyRuleCard can roll
  // the results back up under the folder. SaaS/Okta account kinds are
  // queried by access_tracking_id (their OPA-internal id), not the
  // displayed id (the Okta-side identifier, never logged as a target) --
  // see that field's comment in types/index.ts.
  const trackedResources = useMemo(() => {
    const seen = new Map<string, { resource_kind: string; resource_id: string }>()
    for (const { rule } of grants) {
      for (const res of rule.resolutions) {
        if (res.kind !== 'resolved') continue
        if (TRACKABLE_KINDS.has(res.resource_kind)) {
          const resourceId = res.access_tracking_id ?? res.id
          seen.set(resourceId, { resource_kind: res.resource_kind, resource_id: resourceId })
        } else if (res.resource_kind === 'secret_folder') {
          for (const child of res.child_secrets ?? []) {
            seen.set(child.id, { resource_kind: 'secret', resource_id: child.id })
          }
        }
      }
    }
    return [...seen.values()]
  }, [grants])

  const { data: accessResults } = useUserResourceAccess(user?.id, trackedResources)
  const accessInfoByResourceId = useMemo(() => {
    const map = new Map<string, ResourceAccessInfo>()
    if (accessResults) {
      for (const [resourceId, info] of Object.entries(accessResults)) map.set(resourceId, info)
    }
    return map
  }, [accessResults])

  const exportSectionsForUser: ExportSection[] = useMemo(() => {
    if (!user) return []
    return [
      {
        title: `User: ${user.details?.full_name || user.name}`,
        rows: [
          {
            Email: user.details?.email ?? '',
            Status: user.status ?? '',
            Groups: user.groups.map(g => g.name).join(', '),
          },
        ],
      },
      { title: 'Access Granted', rows: grantRows(grants) },
    ]
  }, [user, grants])

  return (
    <div className="flex flex-col gap-4">
      <div className="card p-3 flex flex-col gap-1">
        <span className="section-label">User</span>
        <Select
          value={userId}
          onValueChange={setUserId}
          placeholder="Select a user"
          options={model.users.map(u => ({ value: u.id, label: u.details?.full_name || u.name }))}
        />
      </div>

      {user && (
        <>
          <div className="card p-3 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-text">{user.details?.full_name || user.name}</span>
              <div className="flex items-center gap-2">
                <span className="text-xs text-text-faint">{user.status}</span>
                <ExportButtons sections={exportSectionsForUser} filenameBase={`opa-user-${user.name}`} />
              </div>
            </div>
            {user.details?.email && <span className="text-xs text-text-faint">{user.details.email}</span>}

            <div className="flex flex-col gap-1">
              <span className="section-label">Groups ({user.groups.length})</span>
              <div className="flex flex-wrap gap-1.5">
                {user.groups.map(g => (
                  <span key={g.id} className="text-xs text-text-dim bg-bg-hover border border-border rounded px-1.5 py-0.5">
                    {g.name}
                  </span>
                ))}
                {user.groups.length === 0 && <span className="text-xs text-text-faint">None</span>}
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <span className="section-label">Everything this user has access to (via their groups) ({grants.length})</span>
            {grants.length === 0 && <span className="text-xs text-text-faint">No policy grants access via this user's groups.</span>}
            {grants.map(({ policy, rule }, i) => (
              <PolicyRuleCard
                key={`${policy.id}-${i}`}
                rule={rule}
                policyName={policy.name}
                accessInfoByResourceId={accessInfoByResourceId}
              />
            ))}
          </div>
        </>
      )}
    </div>
  )
}
