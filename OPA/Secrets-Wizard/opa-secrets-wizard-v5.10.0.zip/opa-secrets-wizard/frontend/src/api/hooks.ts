import { useQuery } from '@tanstack/react-query'
import {
  fetchCsvFiles,
  fetchEnvironments,
  fetchGroups,
  fetchProjects,
  fetchResourceGroupSecurityPolicies,
  fetchResourceGroups,
  fetchUserResourceAccess,
  fetchWorkloadRoles,
} from './client'

export function useEnvironments() {
  return useQuery({
    queryKey: ['environments'],
    queryFn: fetchEnvironments,
  })
}

export function useResourceGroups(enabled = true) {
  return useQuery({
    queryKey: ['resource_groups'],
    queryFn: async () => (await fetchResourceGroups()).resource_groups,
    enabled,
  })
}

export function useProjects(resourceGroupId: string | undefined, enabled = true) {
  return useQuery({
    queryKey: ['projects', resourceGroupId],
    queryFn: async () => (await fetchProjects(resourceGroupId!)).projects,
    enabled: enabled && !!resourceGroupId,
  })
}

export function useCsvFiles() {
  return useQuery({
    queryKey: ['csv_files'],
    queryFn: async () => (await fetchCsvFiles()).files,
  })
}

export function useGroups(enabled = true) {
  return useQuery({
    queryKey: ['groups'],
    queryFn: async () => (await fetchGroups()).groups,
    enabled,
  })
}

export function useResourceGroupSecurityPolicies(resourceGroupId: string | undefined, enabled = true) {
  return useQuery({
    queryKey: ['security_policies', resourceGroupId],
    queryFn: async () => (await fetchResourceGroupSecurityPolicies(resourceGroupId!)).policies,
    enabled: enabled && !!resourceGroupId,
  })
}

export function useWorkloadRoles(enabled = true) {
  return useQuery({
    queryKey: ['workload_roles'],
    queryFn: async () => (await fetchWorkloadRoles()).workload_roles,
    enabled,
  })
}

/** Fires automatically once `userId` and `resources` are both non-empty
 * (e.g. right after selecting a user in UsersTab) -- not a manual
 * "check access" button. Kept on-demand per-user rather than folded into
 * the big Access Explorer bootstrap: fetching this for every user's every
 * resource up front would be slow and mostly wasted, since nobody looks
 * at most of it. */
export function useUserResourceAccess(
  userId: string | undefined,
  resources: { resource_kind: string; resource_id: string }[]
) {
  const resourceKey = resources.map(r => `${r.resource_kind}:${r.resource_id}`).sort().join(',')
  return useQuery({
    queryKey: ['user_resource_access', userId, resourceKey],
    queryFn: async () => (await fetchUserResourceAccess(userId!, resources)).results,
    enabled: !!userId && resources.length > 0,
  })
}
